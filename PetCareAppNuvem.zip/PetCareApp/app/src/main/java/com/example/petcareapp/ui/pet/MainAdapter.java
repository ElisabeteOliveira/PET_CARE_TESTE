package com.example.petcareapp.ui.pet;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.petcareapp.R;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.ViewHolder> {

    private final ArrayList<MainModel> mainModels;
    private final Context context;
    private final OnItemClickListener listener;

    // Interface para lidar com o clique do item
    public interface OnItemClickListener {
        void onItemClick(MainModel model);
    }

    public MainAdapter(Context context, ArrayList<MainModel> mainModels, OnItemClickListener listener) {
        this.context = context;
        this.mainModels = mainModels;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MainModel currentModel = mainModels.get(position);

        byte[] fotoBytes = currentModel.listaFotoPet;

        Glide.with(context)
                .load(fotoBytes)
                .placeholder(R.drawable.patas)
                .error(R.drawable.patas)
                .circleCrop()
                .into(holder.listaFotoPet);

        // Define o ID do pet (escondido)
        holder.listaIdPet.setText(currentModel.getListaIdPet());

        String nomePet = currentModel.getListaNomePet();
        int maxLength = 10;
        if (nomePet.length() > maxLength) {
            nomePet = nomePet.substring(0, maxLength) + "...";
        }
        holder.listaNomePet.setText(nomePet);

        // Configura o listener de clique no item inteiro
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                // Passa o modelo da posição correta para o listener
                listener.onItemClick(currentModel);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mainModels != null ? mainModels.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView listaFotoPet;
        TextView listaIdPet;
        TextView listaNomePet;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            listaFotoPet = itemView.findViewById(R.id.listaPetFoto);
            listaIdPet = itemView.findViewById(R.id.listaIdPet);
            listaNomePet = itemView.findViewById(R.id.listaNomePet);

            listaNomePet.setMaxLines(1);
            listaNomePet.setEllipsize(TextUtils.TruncateAt.END);
        }
    }
}