package com.example.petcareapp.ui.mensagem;

import androidx.recyclerview.widget.DiffUtil;
import java.util.List;

public class MensagemDiffCallback extends DiffUtil.Callback {

    private final List<MainModelMsg> oldList;
    private final List<MainModelMsg> newList;

    public MensagemDiffCallback(List<MainModelMsg> oldList, List<MainModelMsg> newList) {
        this.oldList = oldList;
        this.newList = newList;
    }

    @Override
    public int getOldListSize() { return oldList.size(); }

    @Override
    public int getNewListSize() { return newList.size(); }

    // Compara se é a MESMA mensagem (pelo ID, que é único)
    @Override
    public boolean areItemsTheSame(int oldPos, int newPos) {
        return oldList.get(oldPos).getListaMensagem() == newList.get(newPos).getListaMensagem();
    }

    // Compara se o CONTEÚDO da mensagem mudou
    @Override
    public boolean areContentsTheSame(int oldPos, int newPos) {
        return oldList.get(oldPos).equals(newList.get(newPos));
    }
}