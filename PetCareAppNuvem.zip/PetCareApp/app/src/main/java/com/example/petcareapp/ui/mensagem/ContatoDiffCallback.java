package com.example.petcareapp.ui.mensagem;

import androidx.recyclerview.widget.DiffUtil;
import java.util.List;
import java.util.Objects;

public class ContatoDiffCallback extends DiffUtil.Callback {
    private final List<MainModelContato> oldList;
    private final List<MainModelContato> newList;

    public ContatoDiffCallback(List<MainModelContato> oldList, List<MainModelContato> newList) {
        this.oldList = oldList;
        this.newList = newList;
    }

    @Override
    public int getOldListSize() { return oldList.size(); }

    @Override
    public int getNewListSize() { return newList.size(); }

    @Override
    public boolean areItemsTheSame(int oldPos, int newPos) {
        return oldList.get(oldPos).getListaIdContato().equals(newList.get(newPos).getListaIdContato());
    }

    @Override
    public boolean areContentsTheSame(int oldPos, int newPos) {
        return oldList.get(oldPos).equals(newList.get(newPos));
    }
}