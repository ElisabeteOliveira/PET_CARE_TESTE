package com.example.petcareapp.ui.admGerenciarClinica;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.example.petcareapp.ui.admGerenciarTutor.MainModelGerenciarTutor;
import com.example.petcareapp.ui.admGerenciarTutor.TutorDiffCallback;
import com.google.firebase.auth.FirebaseAuth;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link admGerenciarClinicaFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class admGerenciarClinicaFragment extends Fragment {

    // Criando um Executor e um Handler para a thread principal.
    // O Executor roda a tarefa em background.
    private ExecutorService executor;
    // Handler para postar resultados de volta na thread principal da UI
    private final Handler handler = new Handler(Looper.getMainLooper());

    String emailUsuarioAtual, nomeClicadoClinica;
    Integer idUsuarioAtual, idClinicaClicado;
    boolean imageChanged = false; // Flag para indicar se a imagem foi alterada
    Bitmap imgOriginalBitmap;
    Bitmap selectedBitmap = null;

    EditText admEmailClinica, admNomeClinica, admTelefoneClinica, etPesquisarClinica, admDescricaoClinica, admCrmvClinica, admFuncionamentoClinica;
    TextView tvAdmEmailClinica, tvAdmNomeClinica, tvAdmTelefoneClinica, tvAdmDesricaoClinica, tvAdmCrmvClinica, tvAdmFuncionamentoClinica;
    Button btAdmAlterarDadosClinica, btnAdmSelecinarFotoClinica, admDeletarClinica;
    RecyclerView listaGerenciarClinica;
    ImageView admImgClinica;
    ImageButton btVoltarAdmClinica;
    FrameLayout frameLayoutGerenciarClinica;

    ProgressBar progressBar;
    ConstraintLayout mainContentLayout;

    ArrayList<Integer> listaIdGerenciarClinica = new ArrayList<>();
    ArrayList<byte[]> listaFotoGerenciarClinica = new ArrayList<>();
    ArrayList<String> listaEmailGerenciarClinica = new ArrayList<>();
    ArrayList<String> listaNomeGerenciarClinica = new ArrayList<>();

    // Esta é a "lista mestre". Ela guarda TODOS os dados originais do banco
    private final ArrayList<MainModelGerenciarClinica> listaCompletaDeClinicas = new ArrayList<>();
    // Esta é a lista que o adapter realmente usa e exibe na tela.
    private final ArrayList<MainModelGerenciarClinica> mainModels = new ArrayList<>();

    MainAdapterGerenciarClinica mainAdapter;

    // Definindo o ActivityResultLauncher para capturar o resultado da seleção de foto
    private ActivityResultLauncher<Intent> selectPhotoLauncher;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public admGerenciarClinicaFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment admGerenciarTutorFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static admGerenciarClinicaFragment newInstance(String param1, String param2) {
        admGerenciarClinicaFragment fragment = new admGerenciarClinicaFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        // Inicializando o ActivityResultLauncher para a seleção de foto
        selectPhotoLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {

                    if (result.getResultCode() == getActivity().RESULT_OK && result.getData() != null) {
                        // Recupera o URI da imagem selecionada
                        Intent data = result.getData();
                        Uri imageUri = data.getData();

                        if (imageUri != null) {
                            // Trabalhando com o URI
                            // String imageUriString = imageUri.toString();

                            // Convertendo o URI para um Bitmap:
                            try {
                                // Converte o URI para um Bitmap
                                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), imageUri);

                                // Armazenando no ImageView ou em uma variável global
                                admImgClinica.setImageBitmap(bitmap);
                                selectedBitmap = bitmap;  // Armazenando a imagem selecionada na variável global

                                // Atualizando a variável de controle de alteração de imagem
                                imageChanged = true;

                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
        );
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_adm_gerenciar_clinica, container, false);

        admEmailClinica = view.findViewById(R.id.admEmailClinica);
        admNomeClinica = view.findViewById(R.id.admNomeClinica);
        admTelefoneClinica = view.findViewById(R.id.admTelefoneClinica);
        admDeletarClinica = view.findViewById(R.id.admDeletarClinica);
        etPesquisarClinica = view.findViewById(R.id.etPesquisarClinica);
        listaGerenciarClinica = view.findViewById(R.id.listaGerenciarClinica);
        admDescricaoClinica = view.findViewById(R.id.admDescricaoClinica);
        tvAdmEmailClinica = view.findViewById(R.id.tvAdmEmailClinica);
        tvAdmNomeClinica = view.findViewById(R.id.tvAdmNomeClinica);
        tvAdmTelefoneClinica = view.findViewById(R.id.tvAdmTelefoneClinica);
        tvAdmDesricaoClinica = view.findViewById(R.id.tvAdmDescricaoClinica);
        listaGerenciarClinica = view.findViewById(R.id.listaGerenciarClinica);
        btnAdmSelecinarFotoClinica = view.findViewById(R.id.btnAdmSelecionarFotoClinica);
        frameLayoutGerenciarClinica = view.findViewById(R.id.frameLayoutGerenciarClinica);
        admImgClinica = view.findViewById(R.id.admImgClinica);
        btAdmAlterarDadosClinica = view.findViewById(R.id.btAdmAlterarDadosClinica);
        btVoltarAdmClinica = view.findViewById(R.id.btVoltarAdmClinica);
        admCrmvClinica = view.findViewById(R.id.admCrmvClinica);
        tvAdmCrmvClinica = view.findViewById(R.id.tvAdmCrmvClinica);
        admFuncionamentoClinica = view.findViewById(R.id.admFuncionamentoClinica);
        tvAdmFuncionamentoClinica = view.findViewById(R.id.tvAdmFuncionamentoClinica);
        mainContentLayout = view.findViewById(R.id.mainContentLayout);
        progressBar = view.findViewById(R.id.progressBar);

        // Design Horizontal Layout
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.VERTICAL,false
        );
        listaGerenciarClinica.setLayoutManager(layoutManager);
        listaGerenciarClinica.setItemAnimator(new DefaultItemAnimator());

        // Inicia MainAdapter
        mainAdapter = new MainAdapterGerenciarClinica(getActivity(),mainModels);
        // Set MainAdapter para ListaTutor


        mainAdapter = new MainAdapterGerenciarClinica(getActivity(), mainModels, new MainAdapterGerenciarClinica.OnItemClickListener() {
            @Override
            public void onItemClick(MainModelGerenciarClinica model) {
                executor.execute(() -> {

                    Integer tempIdClinicaClicado = null;
                    String tempAdmEmailClinica = null;
                    byte[] tempAdmFotoClinica = null;
                    String tempAdmNomeClinica = null;
                    String tempAdmDescricaoClinica = null;
                    String tempAdmTelefoneClinica = null;
                    String tempAdmFuncionamentoClinica = null;
                    String tempAdmCrmvClinica = null;

                    Connection con = null;
                    PreparedStatement stmt = null;
                    ResultSet rs = null;

                    try {
                        // Obtenha o nome do tutor do modelo
                        idClinicaClicado = Integer.valueOf(model.getListaIdGerenciarClinica());
                        admImgClinica.setImageDrawable(null);

                        con = ConexaoMysql.conectar();
                        String sql = "SELECT * FROM adm_info_clinica WHERE id_login = ?";
                        stmt = con.prepareStatement(sql);
                        stmt.setInt(1, idClinicaClicado);
                        rs = stmt.executeQuery();

                        if (rs.next()) {
                            tempIdClinicaClicado = rs.getInt("id_login");
                            tempAdmEmailClinica = rs.getString("email");
                            tempAdmFotoClinica = rs.getBytes("foto");
                            tempAdmNomeClinica = rs.getString("nome");
                            tempAdmDescricaoClinica = rs.getString("descricao");
                            tempAdmTelefoneClinica = rs.getString("telefone");
                            tempAdmFuncionamentoClinica = rs.getString("funcionamento");
                            tempAdmCrmvClinica = rs.getString("cfmv_crmv");
                        }

                        final Integer finalIdClinicaClicado = tempIdClinicaClicado;
                        final String finalAdmEmailClinica = tempAdmEmailClinica;
                        final byte[] imgBytes = tempAdmFotoClinica;
                        final String finalAdmNomeClinica = tempAdmNomeClinica;
                        final String finalAdmDescricaoClinica = tempAdmDescricaoClinica;
                        final String finalAdmTelefoneClinica = tempAdmTelefoneClinica;
                        final String finalAdmFuncionamentoClinica = tempAdmFuncionamentoClinica;
                        final String finalAdmCrmvClinica = tempAdmCrmvClinica;

                        handler.post(() -> {
                            if (!isAdded()) return; // Segurança
                            if (imgBytes != null) {
                                Bitmap bitmap = BitmapFactory.decodeByteArray(imgBytes, 0, imgBytes.length);
                                admImgClinica.setImageBitmap(bitmap);
                            }

                            admEmailClinica.setText(finalAdmEmailClinica);
                            idClinicaClicado = finalIdClinicaClicado;
                            admNomeClinica.setText(finalAdmNomeClinica);
                            nomeClicadoClinica= finalAdmNomeClinica;
                            admDescricaoClinica.setText(finalAdmDescricaoClinica);
                            admTelefoneClinica.setText(finalAdmTelefoneClinica);
                            admFuncionamentoClinica.setText(finalAdmFuncionamentoClinica);
                            admCrmvClinica.setText(finalAdmCrmvClinica);

                            if (admImgClinica.getDrawable() == null) {
                                btnAdmSelecinarFotoClinica.setAlpha(1);
                            } else {
                                btnAdmSelecinarFotoClinica.setAlpha(0);
                            }

                            funMostrarDadosClinica();
                            admEmailClinica.setEnabled(false);
                        });

                    } catch (Exception e) {
                        throw new RuntimeException("Erro ao buscar detalhes da clínica", e);
                    } finally {
                        try {
                            if (rs != null) rs.close();
                            if (stmt != null) stmt.close();
                            if (con != null) con.close();
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    }
                });
            }
        });

        listaGerenciarClinica.setAdapter(mainAdapter);

        etPesquisarClinica.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String termoPesquisa = s.toString().trim();
                if (termoPesquisa.isEmpty()) {
                    // Se a pesquisa está vazia, mostra a lista original completa
                    updateRecyclerView(new ArrayList<>(listaCompletaDeClinicas));
                } else {
                    // Se há texto, chama a função de pesquisa
                    funPesquisarClinica(termoPesquisa);
                }
            }
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        });

        btAdmAlterarDadosClinica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAdmAlterarDadosClinica();
            }
        });

        admDeletarClinica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (idClinicaClicado == null) {
                    Toast.makeText(getActivity(), "Nenhuma clínica selecionada!", Toast.LENGTH_SHORT).show();
                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setMessage("Você tem certeza que deseja excluir a clínica " + nomeClicadoClinica + "?")
                            .setCancelable(false) // Não permite fechar o Dialog clicando fora dele
                            .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // Ação ao clicar em "Confirmar"
                                    funDeletarClinica();
                                }
                            })
                            .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // Ação ao clicar em "Cancelar"
                                }
                            });

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
            }
        });

        btVoltarAdmClinica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funEsconderDadosClinica();
            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        // Garante que o executor está ativo.
        if (executor == null || executor.isShutdown()) {
            executor = Executors.newSingleThreadExecutor();
        }

        // 1. Mostra o ProgressBar e oculta o conteúdo principal imediatamente.
        if (progressBar != null) {
            progressBar.setVisibility(VISIBLE);
        }
        if (mainContentLayout != null) {
            mainContentLayout.setVisibility(GONE);
        }

        executor.execute(() -> {
            emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT id_login FROM login WHERE email = ?;";
                stmt = con.prepareStatement(sql);
                stmt.setString(1, emailUsuarioAtual);
                rs = stmt.executeQuery();

                if (rs.next()) {
                    idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
                }

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    funEsconderDadosClinica();
                    funListaClinica();
                    etPesquisarClinica.setText(null);

                    // Finaliza o loading, mostrando o conteúdo.
                    if (progressBar != null) progressBar.setVisibility(GONE);
                    if (mainContentLayout != null) mainContentLayout.setVisibility(VISIBLE);

                });

            } catch (Exception e) {
                Log.e("STARTUP_ERROR", "Erro ao buscar ID do usuário", e);
                handler.post(() -> {
                    if (!isAdded()) return;
                    progressBar.setVisibility(GONE);
                    Toast.makeText(getContext(), "Erro ao iniciar. Tente novamente.", Toast.LENGTH_LONG).show();
                });
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    @Override
    public void onStop() {
        super.onStop();
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
        }
    }

    public void funSelecionarFoto() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        // ActivityResultLauncher para iniciar a atividade e capturar o resultado
        selectPhotoLauncher.launch(intent);
    }

    public void funListaClinica() {
        executor.execute(() -> {
            ArrayList<MainModelGerenciarClinica> tempModels = new ArrayList<>();

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT id_login, email, foto, nome FROM adm_info_clinica";
                stmt = con.prepareStatement(sql);
                rs = stmt.executeQuery();

                // Limpar as listas antes de adicionar novos dados
                listaIdGerenciarClinica.clear();
                listaEmailGerenciarClinica.clear();
                listaFotoGerenciarClinica.clear();
                listaNomeGerenciarClinica.clear();

                // Preencher as listas com dados do banco
                while (rs.next()) {
                    tempModels.add(new MainModelGerenciarClinica(
                            rs.getInt("id_login"),
                            rs.getBytes("foto"),
                            rs.getString("email"),
                            rs.getString("nome")
                    ));
                }

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    // Atualiza a lista mestre com os novos dados
                    listaCompletaDeClinicas.clear();
                    listaCompletaDeClinicas.addAll(tempModels);

                    // Exibe a lista completa na tela usando o DiffUtil
                    updateRecyclerView(new ArrayList<>(listaCompletaDeClinicas));
                });

            } catch (Exception e) {
                throw new RuntimeException(e);
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

    }

    public void updateRecyclerView(List<MainModelGerenciarClinica> novasClinica) {
        // 1. Cria o callback do DiffUtil, comparando a lista antiga com a nova
        ClinicaDiffCallback diffCallback = new ClinicaDiffCallback(this.mainModels, novasClinica);

        // 2. Calcula as diferenças (isso pode ser feito em background se a lista for enorme)
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallback);

        // 3. Atualiza a lista de dados do adapter
        this.mainModels.clear();
        this.mainModels.addAll(novasClinica);

        // 4. Envia as atualizações calculadas para o RecyclerView.
        // Ele fará as animações de forma inteligente, sem piscar!
        diffResult.dispatchUpdatesTo(mainAdapter);
    }

    // Este método é chamado quando a foto é carregada (na seleção da foto)
    public void setImgOriginal(Bitmap bitmap) {
        imgOriginalBitmap = bitmap; // Armazena a imagem original para comparação posterior
        imageChanged = true; // Marca que a imagem foi alterada
    }

    // Método para recuperar a imagem do banco de dados
    private byte[] getImgBytesFromDatabase(Integer idClinica) {
        byte[] imgBytesAtual = null;

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;


        try {
            con = ConexaoMysql.conectar();
            String sql = "SELECT foto FROM adm_info_clinica WHERE id_login = ?";
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, idClinica);
            rs = stmt.executeQuery();

            if (rs.next()) {
                imgBytesAtual = rs.getBytes("foto");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        return imgBytesAtual;
    }

    public void funPesquisarClinica(String termo) {
        ArrayList<MainModelGerenciarClinica> listaFiltrada = new ArrayList<>();
        String filtro = termo.toLowerCase().trim();

        // Itera sobre a lista mestre, que nunca muda.
        for (MainModelGerenciarClinica clinica : listaCompletaDeClinicas) {
            String nome = clinica.getListaNomeGerenciarClinica().toLowerCase();
            String email = clinica.getListaEmailGerenciarClinica().toLowerCase();

            if (nome.contains(filtro) || email.contains(filtro)) {
                listaFiltrada.add(clinica);
            }
        }
        // Usa o método padrão para atualizar a UI com a lista filtrada.
        updateRecyclerView(listaFiltrada);
    }

    public void funAdmAlterarDadosClinica() {
        executor.execute(() -> {
            String nomeClinica = admNomeClinica.getText().toString().trim();
            String telefoneClinica = admTelefoneClinica.getText().toString().trim();
            String biografiaClinica = admDescricaoClinica.getText().toString().trim();
            String crmv = admCrmvClinica.getText().toString().trim();
            String funcionamento = admFuncionamentoClinica.getText().toString().trim();

            if (nomeClinica.isEmpty()) { admNomeClinica.setError("Campo obrigatório"); return; }
            if (crmv.isEmpty()) { admCrmvClinica.setError("Campo obrigatório"); return; }

            Connection con = null;
            PreparedStatement stmt = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "UPDATE clinica SET nome = ?, descricao = ?, telefone = ?, cfmv_crmv = ?, funcionamento = ? WHERE id_clinica = ?";
                stmt = con.prepareStatement(sql);
                stmt.setString(1, nomeClinica);
                stmt.setString(2, biografiaClinica);
                stmt.setString(3, telefoneClinica);
                stmt.setString(4, crmv);
                stmt.setString(5, funcionamento);
                stmt.setInt(6, idClinicaClicado);
                stmt.executeUpdate();

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    nomeClicadoClinica = nomeClinica;
                    funListaClinica();
                    Toast.makeText(getActivity(), "Dados atualizados com sucesso!", Toast.LENGTH_SHORT).show();
                });

            } catch (Exception e) {
                throw new RuntimeException(e);
            } finally {
                try {
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    public void funDeletarClinica() {
        executor.execute(() -> {

            Connection con = null;
            PreparedStatement stmt = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "DELETE FROM login WHERE id_login = ?";
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, idClinicaClicado);
                stmt.execute();

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    funEsconderDadosClinica();
                    funListaClinica();

                    idClinicaClicado = null;
                });

            } catch (Exception e) {
                throw new RuntimeException(e);
            } finally {
                try {
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

    }

    public void funDesativarCampos() {
        admEmailClinica.setEnabled(false);
        admNomeClinica.setEnabled(false);
        admTelefoneClinica.setEnabled(false);
        admDescricaoClinica.setEnabled(false);
        admFuncionamentoClinica.setEnabled(false);
        admCrmvClinica.setEnabled(false);
    }

    public void funAtivarCampos() {
        admEmailClinica.setEnabled(true);
        admNomeClinica.setEnabled(true);
        admTelefoneClinica.setEnabled(true);
        admDescricaoClinica.setEnabled(true);
        admFuncionamentoClinica.setEnabled(true);
        admCrmvClinica.setEnabled(true);
    }

    public void funLimparCampos() {
        admEmailClinica.setText(null);
        admNomeClinica.setText(null);
        admTelefoneClinica.setText(null);
        admDescricaoClinica.setText(null);
        admFuncionamentoClinica.setText(null);
        admCrmvClinica.setText(null);
        admNomeClinica.setError(null);
        admCrmvClinica.setError(null);
    }

    public void funEsconderDadosClinica() {
        frameLayoutGerenciarClinica.setVisibility(GONE);
        btnAdmSelecinarFotoClinica.setVisibility(GONE);
        admImgClinica.setVisibility(GONE);
        tvAdmEmailClinica.setVisibility(GONE);
        admEmailClinica.setVisibility(GONE);
        tvAdmNomeClinica.setVisibility(GONE);
        admNomeClinica.setVisibility(GONE);
        tvAdmTelefoneClinica.setVisibility(GONE);
        admTelefoneClinica.setVisibility(GONE);
        tvAdmDesricaoClinica.setVisibility(GONE);
        admDescricaoClinica.setVisibility(GONE);
        btAdmAlterarDadosClinica.setVisibility(GONE);
        admDeletarClinica.setVisibility(GONE);
        btVoltarAdmClinica.setVisibility(GONE);
        tvAdmCrmvClinica.setVisibility(GONE);
        admCrmvClinica.setVisibility(GONE);
        tvAdmFuncionamentoClinica.setVisibility(GONE);
        admFuncionamentoClinica.setVisibility(GONE);
        etPesquisarClinica.setVisibility(VISIBLE);
        listaGerenciarClinica.setVisibility(VISIBLE);
    }

    public void funMostrarDadosClinica() {
        etPesquisarClinica.setVisibility(GONE);
        listaGerenciarClinica.setVisibility(GONE);
        btVoltarAdmClinica.setVisibility(VISIBLE);
        frameLayoutGerenciarClinica.setVisibility(VISIBLE);
        btnAdmSelecinarFotoClinica.setVisibility(VISIBLE);
        admImgClinica.setVisibility(VISIBLE);
        tvAdmEmailClinica.setVisibility(VISIBLE);
        admEmailClinica.setVisibility(VISIBLE);
        tvAdmNomeClinica.setVisibility(VISIBLE);
        admNomeClinica.setVisibility(VISIBLE);
        tvAdmTelefoneClinica.setVisibility(VISIBLE);
        admTelefoneClinica.setVisibility(VISIBLE);
        tvAdmDesricaoClinica.setVisibility(VISIBLE);
        admDescricaoClinica.setVisibility(VISIBLE);
        btAdmAlterarDadosClinica.setVisibility(VISIBLE);
        admDeletarClinica.setVisibility(VISIBLE);
        tvAdmCrmvClinica.setVisibility(VISIBLE);
        admCrmvClinica.setVisibility(VISIBLE);
        tvAdmFuncionamentoClinica.setVisibility(VISIBLE);
        admFuncionamentoClinica.setVisibility(VISIBLE);
        admNomeClinica.setError(null);
        admCrmvClinica.setError(null);
    }
}