package com.example.petcareapp.util;

public final class FragmentArgs {
    // Construtor privado para que a classe não possa ser instanciada
    private FragmentArgs() {}

    /** Chave para passar o ID do usuário entre fragments. */
    public static final Integer KEY_USER_ID = Integer.valueOf("USER_ID_KEY");
}