package com.example.petcareapp.ui.pet;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.google.firebase.auth.FirebaseAuth;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.text.ParseException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link petFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class petFragment extends Fragment {

    String emailUsuarioAtual, nomePetClicado;
    String ultimaEspecieSelecionada = "";
    Integer idUsuarioAtual, idPetClicado;
    Bitmap imgOriginalBitmap;
    //Bitmap selectedBitmap = null;
    private Uri selectedImageUri = null;
    boolean imageChanged = false; // Flag para indicar se a imagem foi alterada
    boolean verificarPetIsNull = false;
    boolean primeiraSelecaoSpinner = true; // Flag para ignorar primeira seleção do spinner quando ele e carregado
    boolean primeiroPet = false;
    boolean listaPetClick = false; // Flag para mostrar/esconder os botões para salvar/atualizar PET
    private boolean isReturningFromPhotoForNewPet = false;
    private ExecutorService executor;
    // Handler para postar resultados de volta na thread principal da UI
    private final Handler handler = new Handler(Looper.getMainLooper());

    EditText nomePet, especiePet, racaPet, corPet, pesoPet, descricaoPet, dtNascimentoPet;
    TextView textFiltrarEspecie, countTextDescPet, tvNomePet, tvEspeciePet, tvRacaPet, tvCorPet, tvPesoPet, tvPortePet, tvSexoPet, tvBioPet;
    Spinner portePet, sexoPet, filtrarEspecie;
    Button btAlterarPet, btSelecionarFoto,btAddNovoPet, btAddPrimeiroPet, btSalvarNovoPet, btAtualizarPet, btDeletarPet;
    ImageButton btVoltarListaPet;
    ImageView imgPet;
    RecyclerView listaPets;
    LinearLayout linearLayout4;
    ProgressBar progressBar;
    ConstraintLayout mainContentLayout;

    ArrayList<MainModel> mainModels = new ArrayList<>();

    MainAdapter mainAdapter;

    // Definindo o ActivityResultLauncher para capturar o resultado da seleção de foto
    private ActivityResultLauncher<Intent> selectPhotoLauncher;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public petFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment petFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static petFragment newInstance(String param1, String param2) {
        petFragment fragment = new petFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        selectPhotoLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    funMostrarLayoutAddPet();
                    atualizarVisibilidadeBotoesDeAcao();

                    if (result.getResultCode() == getActivity().RESULT_OK && result.getData() != null) {
                        // Apenas pegamos e guardamos a Uri da imagem
                        Uri imageUri = result.getData().getData();

                        if (imageUri != null) {
                            // Guarda a Uri na nossa nova variável de membro
                            selectedImageUri = imageUri;
                            imageChanged = true; // Marca que a imagem foi selecionada/alterada
                            btSelecionarFoto.setAlpha(0);

                            // Usa o Glide para exibir a imagem de forma eficiente
                            Glide.with(requireContext())
                                    .load(selectedImageUri)
                                    .circleCrop()
                                    .into(imgPet);
                        }
                    }
                }
        );

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_pet, container, false);

        nomePet = view.findViewById(R.id.nomePet);
        especiePet = view.findViewById(R.id.especiePet);
        racaPet = view.findViewById(R.id.racaPet);
        corPet = view.findViewById(R.id.corPet);
        pesoPet = view.findViewById(R.id.pesoPet);
        descricaoPet = view.findViewById(R.id.descricaoPet);
        portePet = view.findViewById(R.id.portePet);
        sexoPet = view.findViewById(R.id.sexoPet);
        imgPet = view.findViewById(R.id.imgFeedback);
        btSelecionarFoto = view.findViewById(R.id.btSelecionarFoto);
        btAlterarPet = view.findViewById(R.id.btAlterarPet);
        btAtualizarPet = view.findViewById(R.id.btAtualizarPet);
        btAddNovoPet = view.findViewById(R.id.btAddNovoPet);
        listaPets = view.findViewById(R.id.listaPets);
        btSalvarNovoPet = view.findViewById(R.id.btSalvarNovoPet);
        filtrarEspecie = view.findViewById(R.id.filtrarEspecie);
        textFiltrarEspecie = view.findViewById(R.id.textFiltrarEspecie);
        btAddPrimeiroPet = view.findViewById(R.id.btAddPrimeiroPet);
        linearLayout4 = view.findViewById(R.id.linearLayout4);
        btDeletarPet = view.findViewById(R.id.btDeletarPet);
        countTextDescPet = view.findViewById(R.id.countTextDescPet);
        dtNascimentoPet = view.findViewById(R.id.dtNascimentoPet);
        tvNomePet = view.findViewById(R.id.tvNomePet);
        tvCorPet = view.findViewById(R.id.tvCorPet);
        tvEspeciePet = view.findViewById(R.id.tvEspeciePet);
        tvRacaPet = view.findViewById(R.id.tvRacaPet);
        tvSexoPet = view.findViewById(R.id.tvSexoPet);
        tvPortePet = view.findViewById(R.id.tvPortePet);
        tvPesoPet = view.findViewById(R.id.tvPesoPet);
        tvBioPet = view.findViewById(R.id.tvBioPet);
        linearLayout4 = view.findViewById(R.id.linearLayout4);
        btVoltarListaPet = view.findViewById(R.id.btVoltarListaPet);
        mainContentLayout = view.findViewById(R.id.mainContentLayout);
        progressBar = view.findViewById(R.id.progressBar);

        dtNascimentoPet.addTextChangedListener(new TextWatcher() {
            private String current = "";
            private final String ddmmyyyy = "DDMMYYYY";

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().equals(current)) {
                    return; // Evita loop infinito
                }

                // Limpa o texto de tudo que não for dígito
                String clean = s.toString().replaceAll("[^\\d]", "");

                // Limita o tamanho para 8 dígitos (DDMMYYYY)
                if (clean.length() > 8) {
                    clean = clean.substring(0, 8);
                }

                StringBuilder formatted = new StringBuilder();
                int cleanLen = clean.length();
                int i = 0;

                // Constrói a string formatada
                if (cleanLen > 0) {
                    // Adiciona os dois primeiros dígitos (DD)
                    int end = Math.min(cleanLen, 2);
                    formatted.append(clean.substring(0, end));
                    i += end;

                    // Adiciona a primeira barra
                    if (cleanLen > 2) {
                        formatted.append('/');
                        end = Math.min(cleanLen, 4);
                        formatted.append(clean.substring(2, end));
                        i += (end - 2);
                    }

                    // Adiciona a segunda barra
                    if (cleanLen > 4) {
                        formatted.append('/');
                        end = Math.min(cleanLen, 8);
                        formatted.append(clean.substring(4, end));
                        i += (end - 4);
                    }
                }

                current = formatted.toString();
                dtNascimentoPet.setText(current);
                dtNascimentoPet.setSelection(current.length()); // Mantém o cursor no final
            }
        });

        // Contador de caracteres
        descricaoPet.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int currentLength = s.length();
                countTextDescPet.setText(currentLength + "/250");
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Design Horizontal Layout
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.HORIZONTAL,false
        );
        listaPets.setLayoutManager(layoutManager);
        listaPets.setItemAnimator(new DefaultItemAnimator());

        // Set MainAdapter para listaPets
        mainAdapter = new MainAdapter(getActivity(), mainModels, new MainAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(MainModel model) {
                // Define a flag listaPetClick imediatamente na UI thread, pois é uma operação rápida.
                listaPetClick = true;

                // Captura o ID do pet clicado na UI thread para ser usado na thread de background.
                final Integer clickedPetId = Integer.valueOf(model.getListaIdPet());

                // Executa a operação de banco de dados e processamento de imagem em uma thread separada.
                // Isso evita que a UI seja bloqueada durante a busca e o processamento de dados.
                executor.execute(() -> {
                    Connection con = null;
                    PreparedStatement stmt = null;
                    ResultSet rs = null;

                    // Variáveis temporárias para coletar os dados do pet na thread de background.
                    String tempNomePet = null;
                    String tempEspeciePet = null;
                    String tempRacaPet = null;
                    String tempCorPet = null;
                    String tempPesoPet = null;
                    String tempDescricaoPet = null;
                    String tempDtNascimentoPet = null;
                    byte[] tempImgPetBytes = null;
                    String tempSexo = null;
                    String tempPorte = null;
                    boolean petFoundInDb = false; // Flag para indicar se o pet foi encontrado no DB

                    try {
                        con = ConexaoMysql.conectar(); // Tenta conectar ao banco de dados
                        String sql = "SELECT * FROM pet WHERE id_pet = ?";
                        stmt = con.prepareStatement(sql);
                        stmt.setInt(1, clickedPetId);
                        rs = stmt.executeQuery(); // Executa a query

                        if (rs.next()) {
                            petFoundInDb = true; // Pet encontrado
                            // Popula as variáveis temporárias com os dados do banco.
                            tempNomePet = rs.getString("nome");
                            tempEspeciePet = rs.getString("especie");
                            tempRacaPet = rs.getString("raca");
                            tempCorPet = rs.getString("cor");
                            tempPesoPet = rs.getString("peso");
                            tempDescricaoPet = rs.getString("descricao");

                            java.sql.Date dataNascimento = rs.getDate("dt_nascimento");
                            if (dataNascimento != null) {
                                SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                                tempDtNascimentoPet = formato.format(dataNascimento);
                            }

                            tempImgPetBytes = rs.getBytes("foto");

                            tempSexo = rs.getString("sexo");
                            tempPorte = rs.getString("porte");
                        }

                        // Cria variáveis finais para serem usadas no handler.
                        final String finalNomePet = tempNomePet;
                        final String finalEspeciePet = tempEspeciePet;
                        final String finalRacaPet = tempRacaPet;
                        final String finalCorPet = tempCorPet;
                        final String finalPesoPet = tempPesoPet;
                        final String finalDescricaoPet = tempDescricaoPet;
                        final String finalDtNascimentoPet = tempDtNascimentoPet;
                        final byte[] finalImgPetBytes = tempImgPetBytes;
                        final String finalSexo = tempSexo;
                        final String finalPorte = tempPorte;
                        final boolean finalPetFoundInDb = petFoundInDb;

                        // Posta a atualização da UI para a thread principal.
                        handler.post(() -> {
                            if (!isAdded()) return; // Segurança
                            if (finalPetFoundInDb) {
                                // Atualiza o ID do pet clicado na classe (se for um membro).
                                idPetClicado = clickedPetId;
                                nomePetClicado = finalNomePet; // Atualiza o nome clicado.

                                // Define os textos nos EditTexts/TextViews.
                                nomePet.setText(finalNomePet);
                                especiePet.setText(finalEspeciePet);
                                racaPet.setText(finalRacaPet);
                                corPet.setText(finalCorPet);
                                pesoPet.setText(finalPesoPet);
                                descricaoPet.setText(finalDescricaoPet);
                                dtNascimentoPet.setText(finalDtNascimentoPet);

                                Glide.with(requireContext())
                                        .load(finalImgPetBytes)
                                        .circleCrop()
                                        .error(R.drawable.patas)       // Imagem em caso de erro ou se os bytes forem nulos
                                        .into(imgPet);

                                // Define a seleção dos Spinners (assumindo que eles estão populados corretamente
                                // e que as opções "Macho", "Fêmea", "Pequeno", "Médio", "Grande" correspondem às posições 0, 1, 2).
                                if ("Macho".equals(finalSexo) && sexoPet != null) {
                                    sexoPet.setSelection(0);
                                } else if ("Fêmea".equals(finalSexo) && sexoPet != null) {
                                    sexoPet.setSelection(1);
                                }

                                if ("Pequeno".equals(finalPorte) && portePet != null) {
                                    portePet.setSelection(0);
                                } else if ("Médio".equals(finalPorte) && portePet != null) {
                                    portePet.setSelection(1);
                                } else if ("Grande".equals(finalPorte) && portePet != null) {
                                    portePet.setSelection(2);
                                }

                                // Mostra o layout do pet e os botões de ação.
                                // Verifica a visibilidade atual antes de chamar funMostrarLayoutPet().
                                if (imgPet != null && imgPet.getVisibility() == GONE) {
                                    funMostrarLayoutPet(); // Assumindo que este método torna o layout do pet visível.
                                }

                                // Define a visibilidade dos botões.
                                atualizarVisibilidadeBotoesDeAcao();

                                if (btSelecionarFoto != null) {
                                    btSelecionarFoto.setAlpha(0); // Ajusta a opacidade do botão.
                                }

                                // Desativa os campos após preenchimento.
                                funDesativarCampos();
                            } else {
                                // Feedback se o pet não foi encontrado.
                                Toast.makeText(getContext(), "Pet não encontrado.", Toast.LENGTH_SHORT).show();
                            }
                        });

                    } catch (Exception e) {
                        Log.e("DATABASE_ERROR", "Erro ao carregar detalhes do pet", e);

                        handler.post(() -> {
                            if (!isAdded()) return; // Segurança
                            Toast.makeText(getContext(), "Erro ao carregar detalhes do pet: " + e.getMessage(), Toast.LENGTH_LONG).show();
                        });
                    } finally {
                        // Garante que os recursos do banco de dados sejam fechados, mesmo em caso de erro.
                        try {
                            if (rs != null) rs.close();
                            if (stmt != null) stmt.close();
                            if (con != null) con.close();
                        } catch (Exception e) {
                            e.printStackTrace(); // Imprime erros ao fechar recursos.
                        }
                    }
                });
            }
        });

        listaPets.setAdapter(mainAdapter);
        funDesativarCampos();

        btSelecionarFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Lógica inteligente: verifica o estado ATUAL do fragmento.
                // Se `listaPetClick` for false, significa que estamos no modo de "adicionar novo pet".
                if (!listaPetClick) {
                    isReturningFromPhotoForNewPet = true;
                } else {
                    // Se estivermos editando um pet existente, a flag não precisa ser alterada.
                    // A imagem será atualizada pela flag 'imageChanged'.
                    isReturningFromPhotoForNewPet = false;
                }

                atualizarVisibilidadeBotoesDeAcao();

                // Lança o seletor de imagens
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                intent.setType("image/*");
                selectPhotoLauncher.launch(intent);
            }
        });

        btAlterarPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAtivarCampos();
                atualizarVisibilidadeBotoesDeAcao();
            }
        });

        btAtualizarPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAtualizarPet();
            }
        });

        btAddPrimeiroPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 1. Define o estado para "adicionando novo pet".
                listaPetClick = false;
                isReturningFromPhotoForNewPet = false; // Garante que a flag está limpa ao iniciar
                idPetClicado = null;

                // 2. Prepara a UI para o formulário.
                funMostrarLayoutAddPet();
                funLimparCamposAddPet(); // Limpa e ativa os campos do formulário

                atualizarVisibilidadeBotoesDeAcao();
            }
        });

        btAddNovoPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 1. Define o estado para "adicionando novo pet".
                listaPetClick = false;
                isReturningFromPhotoForNewPet = false; // Garante que a flag está limpa ao iniciar
                idPetClicado = null;

                // 2. Prepara a UI para o formulário.
                funMostrarLayoutAddPet();
                funLimparCamposAddPet(); // Limpa e ativa os campos do formulário

                atualizarVisibilidadeBotoesDeAcao();
            }
        });

        btSalvarNovoPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funCadastrarPet();
            }
        });

        filtrarEspecie.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Ignora a primeira seleção do spinner para evitar execução indesejada ao iniciar o Fragment.
                if (primeiraSelecaoSpinner) {
                    primeiraSelecaoSpinner = false;
                    return;
                }

                String especieSelecionada = filtrarEspecie.getSelectedItem().toString();

                // Verifica se a espécie selecionada é diferente da última para evitar recargas desnecessárias.
                if (!especieSelecionada.equals(ultimaEspecieSelecionada)) {
                    ultimaEspecieSelecionada = especieSelecionada;

                    // Executa a operação de banco de dados e processamento de imagem em uma thread separada.
                    // Isso evita travamentos na interface do usuário.
                    executor.execute(() -> {
                        final ArrayList<String> tempListaIdPet = new ArrayList<>();
                        final ArrayList<String> tempListaNomePet = new ArrayList<>();
                        final ArrayList<byte[]> tempListaFotoPet = new ArrayList<>();

                        Connection con = null;
                        PreparedStatement stmt = null;
                        ResultSet rs = null;

                        try {
                            con = ConexaoMysql.conectar(); // Tenta conectar ao banco de dados
                            String sql = "SELECT id_pet, nome, foto FROM pet WHERE fk_id_tutor = ? AND especie = ?";
                            stmt = con.prepareStatement(sql);
                            // Define os parâmetros para a query SQL.
                            stmt.setInt(1, idUsuarioAtual);
                            stmt.setString(2, especieSelecionada);
                            rs = stmt.executeQuery(); // Executa a query

                            // Preenche as listas temporárias com dados do banco.
                            while (rs.next()) {
                                String petId = rs.getString("id_pet");
                                String nome = rs.getString("nome");
                                byte[] fotoBytes = rs.getBytes("foto");

                                // Adiciona os dados (com bitmap arredondado ou null) às listas temporárias.
                                tempListaIdPet.add(petId);
                                tempListaNomePet.add(nome);
                                tempListaFotoPet.add(fotoBytes);
                            }

                            // Posta a atualização da UI para a thread principal.
                            // Todas as operações que modificam a UI devem ser feitas na thread principal.
                            handler.post(() -> {
                                if (!isAdded()) return; // Segurança
                                // 1. Em vez de limpar as listas do fragment, crie uma nova lista de MainModel
                                ArrayList<MainModel> novosModelos = new ArrayList<>();
                                for (int i = 0; i < tempListaIdPet.size(); i++) {
                                    novosModelos.add(new MainModel(tempListaFotoPet.get(i), tempListaIdPet.get(i), tempListaNomePet.get(i)));
                                }

                                // 2. Chame o novo updateRecyclerView com a lista recém-criada
                                updateRecyclerView(novosModelos);
                                // Chama o método para mostrar o layout superior, se necessário.
                                funMostrarLayoutSuperior(); // Assumindo que este método ajusta a visibilidade do layout.
                            });

                        } catch (Exception e) {
                            Log.d("DATABASE_ERROR", "Erro ao filtrar pets por espécie", e);
                            // Exibe Toast de erro na UI thread se algo der errado na operação do banco de dados.

                            handler.post(() -> {
                                if (!isAdded()) return; // Segurança
                                Toast.makeText(getContext(), "Erro ao filtrar pets por espécie: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            });
                        } finally {
                            // Garante que os recursos do banco de dados sejam fechados, mesmo em caso de erro.
                            try {
                                if (rs != null) rs.close();
                                if (stmt != null) stmt.close();
                                if (con != null) con.close();
                            } catch (Exception e) {
                                e.printStackTrace(); // Imprime erros ao fechar recursos.
                            }
                        }
                    });
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Nada a fazer quando nada é selecionado.
            }
        });

        btDeletarPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setMessage("Confirme para excluir o PET " +nomePetClicado+".")
                        .setCancelable(false) // Não permite fechar o Dialog clicando fora dele
                        .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Ação ao clicar em "Confirmar"
                                funDeletarPet();
                            }
                        })
                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Ação ao clicar em "Cancelar"
                            }
                        });

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        btVoltarListaPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funPetIsNull();
                funListaPets();
            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        // Garante que o executor está ativo.
        if (executor == null || executor.isShutdown()) {
            executor = Executors.newSingleThreadExecutor();
        }

        // 1. Mostra o ProgressBar e oculta o conteúdo principal imediatamente.
        if (progressBar != null) {
            progressBar.setVisibility(VISIBLE);
        }
        if (mainContentLayout != null) {
            mainContentLayout.setVisibility(GONE);
        }

        // 2. Inicia a busca de dados em uma thread de background.
        executor.execute(() -> {
            // Bloco para obter o ID do usuário (operação de I/O)
            String emailUsuarioAtual = (FirebaseAuth.getInstance().getCurrentUser() != null)
                    ? FirebaseAuth.getInstance().getCurrentUser().getEmail()
                    : null;

            if (emailUsuarioAtual == null) {
                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    Toast.makeText(getContext(), "Erro: Usuário não autenticado.", Toast.LENGTH_SHORT).show();
                    if (progressBar != null) progressBar.setVisibility(GONE);
                    if (mainContentLayout != null) mainContentLayout.setVisibility(VISIBLE);
                });
                return;
            }

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;
            boolean userFound = false;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT id_login FROM login WHERE email = ?;";
                stmt = con.prepareStatement(sql);
                stmt.setString(1, emailUsuarioAtual);
                rs = stmt.executeQuery();

                if (rs.next()) {
                    idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
                    userFound = true;
                }

            } catch (Exception e) {
                e.printStackTrace();
                final String errorMessage = "Erro ao buscar dados do usuário: " + e.getMessage();

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    Toast.makeText(getContext(), errorMessage, Toast.LENGTH_LONG).show();
                });
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            // 3. Posta o resultado e a lógica de UI de volta para a thread principal.
            final boolean finalUserFound = userFound;
            handler.post(() -> {
                if (!isAdded()) return; // Segurança
                if (!finalUserFound) {
                    // Se o usuário do Firebase não for encontrado no seu DB, para aqui.
                    Toast.makeText(getContext(), "Usuário não encontrado no banco de dados.", Toast.LENGTH_LONG).show();
                    if (progressBar != null) progressBar.setVisibility(GONE);
                    if (mainContentLayout != null) mainContentLayout.setVisibility(VISIBLE);
                    return;
                }

                // Se o usuário foi encontrado, configura os componentes da UI.
                // Configuração dos Spinners (é rápido e seguro fazer aqui).
                List<String> portePetList = Arrays.asList("Pequeno", "Médio", "Grande");
                ArrayAdapter<String> adapterPorte = new ArrayAdapter<>(requireActivity(), R.layout.spinner_text_color, portePetList);
                adapterPorte.setDropDownViewResource(R.layout.spinner_text_color);
                if (portePet != null) {
                    portePet.setAdapter(adapterPorte);
                }

                List<String> sexoPetList = Arrays.asList("Macho", "Fêmea");
                ArrayAdapter<String> adapterSexo = new ArrayAdapter<>(requireActivity(), R.layout.spinner_text_color, sexoPetList);
                adapterSexo.setDropDownViewResource(R.layout.spinner_text_color);
                if (sexoPet != null) {
                    sexoPet.setAdapter(adapterSexo);
                }

                primeiraSelecaoSpinner = true;

                if (isReturningFromPhotoForNewPet) {
                    // CASO 1: Retornou do seletor de fotos para um NOVO pet.
                    // Ação: Apenas mostra o formulário de adição, sem recarregar a lista.
                    funMostrarLayoutAddPet(); // Mostra o formulário.
                    isReturningFromPhotoForNewPet = false; // Reseta a flag.

                    // Finaliza o loading, mostrando o conteúdo.
                    if (progressBar != null) progressBar.setVisibility(GONE);
                    if (mainContentLayout != null) mainContentLayout.setVisibility(VISIBLE);

                } else if (listaPetClick) {
                    // CASO 2: Retornou de qualquer lugar (inclusive do seletor de fotos)
                    // enquanto ESTAVA EDITANDO um pet.
                    // Ação: Apenas mostra o formulário de edição novamente.
                    funMostrarLayoutAddPet(); // Mostra o formulário de edição.
                    // Usamos a mesma função, pois ela exibe o layout do formulário.

                    // Finaliza o loading, mostrando o conteúdo.
                    if (progressBar != null) progressBar.setVisibility(GONE);
                    if (mainContentLayout != null) mainContentLayout.setVisibility(VISIBLE);

                } else {
                    // CASO 3: Início normal do fragmento (não está adicionando nem editando).
                    // Ação: Verifica se o usuário tem pets para decidir se mostra a lista ou
                    // o botão para adicionar o primeiro pet.
                    funPetIsNull(); // Este método agora será responsável por esconder o ProgressBar.
                }
            });
        });
    }

    @Override
    public void onStop() {
        super.onStop();
        if (executor != null) {
            executor.shutdown();
            //executor = null; // Força a recriação na próxima vez que onStart for chamado
        }
    }

    public static class DateValidator {

        /**
         * Verifica se a string está no formato dd/MM/yyyy e é uma data válida.
         * @param dateStr A string da data para validar.
         * @return true se a data for válida, false caso contrário.
         */
        public static boolean isValidDate(String dateStr) {
            if (dateStr == null || !dateStr.matches("\\d{2}/\\d{2}/\\d{4}")) {
                return false;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            sdf.setLenient(false); // Não aceita datas inválidas como 32/01/2025

            try {
                Date date = sdf.parse(dateStr);
                int year = Integer.parseInt(dateStr.substring(6));
                if (year < 1900 || year > 2100) {
                    return false;
                }

            } catch (ParseException | NumberFormatException e) {
                // Se a análise falhar, a data é inválida
                return false;
            }

            return true; // Se passou por tudo, a data é válida
        }
    }

    public void funCadastrarPet() {
        // 1. Captura todos os dados da UI na thread principal.
        // As validações iniciais também são feitas aqui para feedback imediato.
        final String nome = nomePet.getText().toString().trim();
        final String especie = especiePet.getText().toString().trim();
        final String raca = racaPet.getText().toString().trim();
        final String cor = corPet.getText().toString().trim();
        final String peso = pesoPet.getText().toString().trim();
        final String porte = portePet.getSelectedItem().toString();
        final String sexo = sexoPet.getSelectedItem().toString();
        final String descricao = descricaoPet.getText().toString().trim();
        final String dataStr = dtNascimentoPet.getText().toString().trim();

        // Validações de obrigatoriedade na UI thread.
        if (nome.isEmpty()){ nomePet.setError("Campo obrigatório"); return; }
        if (especie.isEmpty()){ especiePet.setError("Campo obrigatório"); return; }
        if (dataStr.isEmpty()){ dtNascimentoPet.setError("Campo obrigatório"); return; }

        // Validação de formato/consistência da data na UI thread.
        if (!petFragment.DateValidator.isValidDate(dataStr)) {
            dtNascimentoPet.setError("Data inválida");
            return;
        }

        // Executa a operação de cadastro em uma thread separada para não travar o app.
        executor.execute(() -> {
            byte[] byteArray = null;
            java.sql.Date dataSql = null;
            Connection con = null;
            PreparedStatement stmt = null;

            try {
                // Conversão da data (pode ser demorada, então no background)
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                dataSql = new java.sql.Date(sdf.parse(dataStr).getTime());

                // Processamento da imagem (também pode ser demorado, então no background)
                // Verifica se o usuário selecionou uma imagem (selectedBitmap não é null)
                // Se selectedBitmap é null, significa que nenhuma imagem foi selecionada pelo usuário.
                // A conversão agora acontece aqui, de forma segura, na thread de background.
                if (imageChanged && selectedImageUri != null) {
                    // Se uma nova imagem foi selecionada...
                    // ...convertemos a Uri para Bitmap aqui dentro.
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(
                            requireContext().getContentResolver(),
                            selectedImageUri
                    );
                    // E então comprimimos para byte[]
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                    byteArray = byteArrayOutputStream.toByteArray();
                } else {
                    // Se nenhuma imagem foi selecionada, usamos a imagem padrão.
                    Bitmap defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.patas);
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    defaultBitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                    byteArray = byteArrayOutputStream.toByteArray();
                }

                con = ConexaoMysql.conectar(); // Conecta ao banco de dados
                String sql = "INSERT INTO pet (nome, foto, descricao, especie, raca, cor, sexo, porte, peso, dt_nascimento, fk_id_tutor) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                stmt = con.prepareStatement(sql);

                stmt.setString(1, nome);
                stmt.setBytes(2, byteArray);
                stmt.setString(3, descricao);
                stmt.setString(4, especie);
                stmt.setString(5, raca);
                stmt.setString(6, cor);
                stmt.setString(7, sexo);
                stmt.setString(8, porte);

                if(!peso.isEmpty()) {
                    stmt.setDouble(9, Double.parseDouble(peso));
                } else {
                    stmt.setDouble(9, 0); // Define 0 se o peso estiver vazio
                }

                stmt.setDate(10, dataSql);
                stmt.setInt(11, idUsuarioAtual);  // id do usuário (assumindo que está populado)
                stmt.executeUpdate(); // Executa a inserção

                // Posta as atualizações da UI para a thread principal após o sucesso da operação.
                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    // Atualização UI
                    funMostrarLayoutSuperior(); // Assumindo que este método atualiza a UI
                    funListaPets();             // Assumindo que este método recarrega a lista de pets
                    funDesativarCampos();       // Assumindo que este método desativa campos
                    funFiltrarEspecie();        // Assumindo que este método atualiza o filtro de espécie
                    if (btAlterarPet != null) { // Verificação de null
                        btAlterarPet.setVisibility(GONE); // Esconde o botão de alterar
                    }

                    // --- LIMPEZA DE ESTADO ---
                    // Resetamos as flags para a próxima operação
                    imageChanged = false;
                    selectedImageUri = null; // Limpa a Uri guardada
                    isReturningFromPhotoForNewPet = false;
                    primeiraSelecaoSpinner = true;
                });

            } catch (ParseException e) {
                e.printStackTrace();
                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    dtNascimentoPet.setError("Data inválida");
                    Toast.makeText(getContext(), "Erro ao converter a data: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            } catch (Exception e) {
                Log.d("DATABASE_ERROR", "Erro ao cadastrar pet", e);
                // Exibe Toast de erro na UI thread se algo der errado na operação do banco de dados.

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    Toast.makeText(getContext(), "Erro ao cadastrar pet: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            } finally {
                // Garante que os recursos do banco de dados sejam fechados, mesmo em caso de erro.
                try {
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace(); // Imprime erros ao fechar recursos.
                }
            }
        });
    }

    public void funListaPets() {
        // Executa a operação de banco de dados e processamento de imagem em uma thread separada.
        // Isso evita travamentos na interface do usuário.
        executor.execute(() -> {
            final ArrayList<String> tempListaIdPet = new ArrayList<>();
            final ArrayList<String> tempListaNomePet = new ArrayList<>();
            final ArrayList<byte[]> tempListaFotoPet = new ArrayList<>();

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar(); // Tenta conectar ao banco de dados
                String sql = "SELECT id_pet, nome, foto FROM pet WHERE fk_id_tutor = ?";
                stmt = con.prepareStatement(sql);
                // Assumindo que 'idUsuarioAtual' é um membro da classe e já está populado.
                stmt.setInt(1, idUsuarioAtual);
                rs = stmt.executeQuery(); // Executa a query

                // Preenche as listas temporárias com dados do banco.
                while (rs.next()) {
                    String id = rs.getString("id_pet");
                    String nome = rs.getString("nome");
                    byte[] fotoBytes = rs.getBytes("foto");

                    // Adiciona os dados (com bitmap arredondado ou null) às listas temporárias.
                    tempListaIdPet.add(id);
                    tempListaNomePet.add(nome);
                    tempListaFotoPet.add(fotoBytes);
                }

                // Posta a atualização da UI para a thread principal.
                // Todas as operações que modificam a UI devem ser feitas na thread principal.
                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    // 1. Em vez de limpar as listas do fragment, crie uma nova lista de MainModel
                    ArrayList<MainModel> novosModelos = new ArrayList<>();
                    for (int i = 0; i < tempListaIdPet.size(); i++) {
                        novosModelos.add(new MainModel(tempListaFotoPet.get(i), tempListaIdPet.get(i), tempListaNomePet.get(i)));
                    }

                    // 2. Chame o novo updateRecyclerView com a lista recém-criada
                    updateRecyclerView(novosModelos);
                });

            } catch (Exception e) {
                Log.d("DATABASE_ERROR", "Erro ao carregar lista de pets", e);
                // Exibe Toast de erro na UI thread se algo der errado na operação do banco de dados.

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    Toast.makeText(getContext(), "Erro ao carregar lista de pets: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            } finally {
                // Garante que os recursos do banco de dados sejam fechados, mesmo em caso de erro.
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace(); // Imprime erros ao fechar recursos.
                }
            }
        });
    }

    public void updateRecyclerView(List<MainModel> novosPets) {
        // 1. Cria o callback do DiffUtil, comparando a lista antiga com a nova
        PetDiffCallback diffCallback = new PetDiffCallback(this.mainModels, novosPets);

        // 2. Calcula as diferenças (isso pode ser feito em background se a lista for enorme)
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallback);

        // 3. Atualiza a lista de dados do adapter
        this.mainModels.clear();
        this.mainModels.addAll(novosPets);

        // 4. Envia as atualizações calculadas para o RecyclerView.
        // Ele fará as animações de forma inteligente, sem piscar!
        diffResult.dispatchUpdatesTo(mainAdapter);
    }

    public void funFiltrarEspecie() {
        // Executa a operação de banco de dados em uma thread separada.
        // Isso evita travamentos na interface do usuário.
        executor.execute(() -> {
            final List<String> tempFiltrarEspecieList = new ArrayList<>();
            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar(); // Tenta conectar ao banco de dados
                String sql = "SELECT DISTINCT especie FROM pet WHERE fk_id_tutor = ? ORDER BY especie ASC";
                stmt = con.prepareStatement(sql);
                // Assumindo que 'idUsuarioAtual' é um membro da classe e já está populado.
                stmt.setInt(1, idUsuarioAtual);
                rs = stmt.executeQuery(); // Executa a query

                // Preenche a lista temporária com os dados do banco.
                while (rs.next()) {
                    tempFiltrarEspecieList.add(rs.getString("especie"));
                }

                // Posta a atualização da UI para a thread principal.
                // Todas as operações que modificam a UI (como setAdapter) devem ser feitas na thread principal.
                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    // Cria o ArrayAdapter e associa ao Spinner.
                    // Certifique-se de que 'filtrarEspecie' é um membro da classe e foi inicializado.
                    ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getActivity(), R.layout.spinner_text_color, tempFiltrarEspecieList);
                    adapter2.setDropDownViewResource(R.layout.spinner_text_color);
                    if (filtrarEspecie != null) { // Verificação de null para segurança
                        filtrarEspecie.setAdapter(adapter2);
                    }
                });

            } catch (Exception e) {
                Log.d("DATABASE_ERROR", "Erro ao carregar espécies para filtro", e);
                // Exibe Toast de erro na UI thread se algo der errado na operação do banco de dados.

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    Toast.makeText(getContext(), "Erro ao carregar espécies para filtro: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            } finally {
                // Garante que os recursos do banco de dados sejam fechados, mesmo em caso de erro.
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace(); // Imprime erros ao fechar recursos.
                }
            }
        });
    }

    public void funAtualizarPet() {
        // 1. Captura de dados da UI (continua igual)
        final String nome = nomePet.getText().toString().trim();
        final String especie = especiePet.getText().toString().trim();
        final String raca = racaPet.getText().toString().trim();
        final String cor = corPet.getText().toString().trim();
        final String peso = pesoPet.getText().toString().trim();
        final String porte = portePet.getSelectedItem().toString();
        final String sexo = sexoPet.getSelectedItem().toString();
        final String descricao = descricaoPet.getText().toString().trim();
        final String dataStr = dtNascimentoPet.getText().toString().trim();
        // A captura da flag `imageChanged` agora é feita dentro do executor

        // 2. Validações na UI (continuam iguais)
        if (nome.isEmpty()){ nomePet.setError("Campo obrigatório"); return; }
        if (especie.isEmpty()){ especiePet.setError("Campo obrigatório"); return; }
        if (dataStr.isEmpty()){ dtNascimentoPet.setError("Campo obrigatório"); return; }
        if (!petFragment.DateValidator.isValidDate(dataStr)) {
            dtNascimentoPet.setError("Data inválida");
            return;
        }

        // 3. Execução em background
        executor.execute(() -> {
            java.sql.Date dataSql = null;
            Connection con = null;
            PreparedStatement stmt = null;

            try {
                // Conversão da data
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                dataSql = new java.sql.Date(sdf.parse(dataStr).getTime());

                con = ConexaoMysql.conectar();
                String sql;

                if (imageChanged) {
                    // Se a imagem foi alterada, preparamos os bytes da nova imagem
                    byte[] imgBytesToUpdate = null;

                    if (selectedImageUri != null) {
                        // Converte a nova Uri para Bitmap aqui dentro, na background thread
                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(
                                requireContext().getContentResolver(),
                                selectedImageUri
                        );
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                        imgBytesToUpdate = byteArrayOutputStream.toByteArray();
                    } else {
                        // Caso raro: a imagem foi "limpa". Usamos a imagem padrão.
                        Bitmap defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.patas);
                        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                        defaultBitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                        imgBytesToUpdate = byteArrayOutputStream.toByteArray();
                    }

                    // Prepara a query para atualizar todos os campos, incluindo a foto
                    sql = "UPDATE pet SET nome=?, foto=?, descricao=?, especie=?, raca=?, cor=?, sexo=?, porte=?, peso=?, dt_nascimento=? WHERE id_pet = ?";
                    stmt = con.prepareStatement(sql);

                    stmt.setString(1, nome);
                    stmt.setBytes(2, imgBytesToUpdate); // Define a nova foto
                    stmt.setString(3, descricao);
                    stmt.setString(4, especie);
                    stmt.setString(5, raca);
                    stmt.setString(6, cor);
                    stmt.setString(7, sexo);
                    stmt.setString(8, porte);
                    if(!peso.isEmpty()) { stmt.setDouble(9, Double.parseDouble(peso)); } else { stmt.setDouble(9, 0); }
                    stmt.setDate(10, dataSql);
                    stmt.setInt(11, idPetClicado);

                } else {
                    // Se a imagem NÃO foi alterada, a query não inclui o campo da foto
                    sql = "UPDATE pet SET nome=?, descricao=?, especie=?, raca=?, cor=?, sexo=?, porte=?, peso=?, dt_nascimento=? WHERE id_pet = ?";
                    stmt = con.prepareStatement(sql);

                    stmt.setString(1, nome);
                    stmt.setString(2, descricao);
                    stmt.setString(3, especie);
                    stmt.setString(4, raca);
                    stmt.setString(5, cor);
                    stmt.setString(6, sexo);
                    stmt.setString(7, porte);
                    if(!peso.isEmpty()) { stmt.setDouble(8, Double.parseDouble(peso)); } else { stmt.setDouble(8, 0); }
                    stmt.setDate(9, dataSql);
                    stmt.setInt(10, idPetClicado);
                }

                stmt.executeUpdate(); // Executa a atualização

                // Atualização da UI na thread principal
                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    Toast.makeText(getContext(), "Pet atualizado com sucesso!", Toast.LENGTH_SHORT).show();
                    funListaPets();
                    //funFiltrarEspecie(); Desativado para corrigir um bug visual, onde a listapet era atualizadas duas vezes após atualização do pet.
                    funDesativarCampos();

                    // --- LIMPEZA DE ESTADO ---
                    imageChanged = false;
                    selectedImageUri = null;
                    primeiraSelecaoSpinner = true;
                });

            } catch (Exception e) {
                Log.d("DATABASE_ERROR", "Erro ao atualizar pet", e);

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    Toast.makeText(getContext(), "Erro ao atualizar pet: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            } finally {
                try {
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    // Este método é chamado quando a foto é carregada (na seleção da foto)
    public void setImgOriginal(Bitmap bitmap) {
        imgOriginalBitmap = bitmap; // Armazena a imagem original para comparação posterior
        imageChanged = true; // Marca que a imagem foi alterada
    }

    // Método para recuperar a imagem do banco de dados
    private byte[] getImgBytesFromDatabase(String idPet) {
        byte[] imgBytesAtual = null;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT foto FROM pet WHERE id_pet = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, idPet);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                imgBytesAtual = rs.getBytes("foto");
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return imgBytesAtual;
    }

    public void funDeletarPet() {
        // Executa a operação de exclusão no banco de dados em uma thread separada.
        // Isso evita travamentos na interface do usuário.
        executor.execute(() -> {
            Connection con = null;
            PreparedStatement stmt = null;
            try {
                con = ConexaoMysql.conectar(); // Tenta conectar ao banco de dados
                String sql = "DELETE FROM pet WHERE id_pet = ?";
                stmt = con.prepareStatement(sql);
                // Assumindo que 'idPetClicado' é um membro da classe e já está populado.
                stmt.setInt(1, idPetClicado);
                stmt.execute(); // Executa a exclusão no banco de dados

                // Posta as atualizações da UI para a thread principal após o sucesso da operação.
                // Todas as operações que modificam a UI devem ser feitas na thread principal.
                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    Toast.makeText(getContext(), "Pet excluído com sucesso!", Toast.LENGTH_SHORT).show();

                    funPetIsNull();

                    if (imgPet != null) {       // Verifica null para segurança
                        imgPet.setImageDrawable(null); // Limpa a imagem do pet
                    }
                });

            } catch (Exception e) {
                Log.d("DATABASE_ERROR", "Erro ao deletar pet", e);
                // Exibe Toast de erro na UI thread se algo der errado na operação do banco de dados.

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    Toast.makeText(getContext(), "Erro ao deletar pet: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            } finally {
                // Garante que os recursos do banco de dados sejam fechados, mesmo em caso de erro.
                try {
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace(); // Imprime erros ao fechar recursos.
                }
            }
        });
    }

    public void funPetIsNull() {
        primeiroPet = false;
        primeiraSelecaoSpinner = true; // Reseta a flag do spinner
        executor.execute(() -> {
            boolean tempVerificarPetIsNull = false;
            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT COUNT(*) FROM pet WHERE fk_id_tutor = ?";
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, idUsuarioAtual);
                rs = stmt.executeQuery();

                if (rs.next()) {
                    if (rs.getInt(1) > 0) {
                        tempVerificarPetIsNull = true;
                        primeiroPet = true;
                    }
                }

                final boolean finalVerificarPetIsNull = tempVerificarPetIsNull;
                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    verificarPetIsNull = finalVerificarPetIsNull;

                    if (verificarPetIsNull) {
                        // Se existem pets, mostra a lista de pets e oculta o formulário de adição
                        funMostrarLayoutSuperior(); // Mostra o layout da lista de pets
                        // Garante que o botão de adicionar primeiro pet esteja GONE
                        if (btAddPrimeiroPet != null) btAddPrimeiroPet.setVisibility(GONE);

                        // Se existem pets, chame funFiltrarEspecie() e funListaPets()
                        funFiltrarEspecie();
                        funListaPets();

                    } else {
                        // Se não existem pets, esconde a lista e mostra o botão para adicionar o primeiro pet
                        funEsconderLayout(); // Esconde todos os layouts de edição/lista
                        if (btAddPrimeiroPet != null) btAddPrimeiroPet.setVisibility(VISIBLE);
                    }

                    // Esconde o ProgressBar e mostra o mainContentLayout APENAS QUANDO A DECISÃO DE LAYOUT FOI FEITA
                    if (progressBar != null) progressBar.setVisibility(GONE);
                    if (mainContentLayout != null) mainContentLayout.setVisibility(VISIBLE);
                });

            } catch (Exception e) {
                e.printStackTrace();
                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    Toast.makeText(getContext(), "Erro ao verificar pets: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    // Em caso de erro, ainda garantir que o ProgressBar suma e o layout principal apareça
                    if (progressBar != null) progressBar.setVisibility(GONE);
                    if (mainContentLayout != null) mainContentLayout.setVisibility(VISIBLE);
                });
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Método centralizado para controlar a visibilidade dos botões de ação (Salvar, Atualizar, Deletar).
     * A decisão é baseada unicamente na flag 'listaPetClick'.
     */
    private void atualizarVisibilidadeBotoesDeAcao() {
        if (listaPetClick) { // Modo EDIÇÃO de um pet existente
            if (btSalvarNovoPet != null) btSalvarNovoPet.setVisibility(GONE);
            if (btAtualizarPet != null) btAtualizarPet.setVisibility(VISIBLE);
            if (btDeletarPet != null) btDeletarPet.setVisibility(VISIBLE);
        } else { // Modo ADIÇÃO de um novo pet
            if (btAtualizarPet != null) btAtualizarPet.setVisibility(GONE);
            if (btDeletarPet != null) btDeletarPet.setVisibility(GONE);
            if (btSalvarNovoPet != null) btSalvarNovoPet.setVisibility(VISIBLE);
        }
    }

    public void funAtivarCampos() {
        nomePet.setEnabled(true);
        corPet.setEnabled(true);
        pesoPet.setEnabled(true);
        especiePet.setEnabled(true);
        racaPet.setEnabled(true);
        portePet.setEnabled(true);
        sexoPet.setEnabled(true);
        descricaoPet.setEnabled(true);
        dtNascimentoPet.setEnabled(true);
        btSelecionarFoto.setEnabled(true);
        btAlterarPet.setVisibility(GONE);
    }

    public void funDesativarCampos() {
        nomePet.setEnabled(false);
        corPet.setEnabled(false);
        pesoPet.setEnabled(false);
        especiePet.setEnabled(false);
        racaPet.setEnabled(false);
        portePet.setEnabled(false);
        sexoPet.setEnabled(false);
        descricaoPet.setEnabled(false);
        dtNascimentoPet.setEnabled(false);

        // Outro metodo para desativar campos
        /*
        nomePet.setFocusable(false);
        nomePet.setFocusableInTouchMode(false); // Garante que o teclado não abre
        nomePet.setCursorVisible(false);
        nomePet.setLongClickable(false);
        */

        btSelecionarFoto.setEnabled(false);
        btAlterarPet.setVisibility(VISIBLE);

        nomePet.setError(null);
        especiePet.setError(null);
        dtNascimentoPet.setError(null);
    }

    public void funLimparCamposAddPet() {
        funAtivarCampos();
        nomePet.setText(null);
        corPet.setText(null);
        pesoPet.setText(null);
        especiePet.setText(null);
        racaPet.setText(null);
        portePet.setSelection(0);;
        sexoPet.setSelection(0);
        descricaoPet.setText(null);
        dtNascimentoPet.setText(null);

        selectedImageUri = null;  // Limpa o bitmap da operação anterior
        imageChanged = false;   // Reseta a flag de mudança de imagem
        if (imgPet != null) {
            Glide.with(requireContext())
                    .load(R.drawable.patas)
                    .circleCrop()
                    .into(imgPet);
        }

        nomePet.setError(null);
        especiePet.setError(null);
        dtNascimentoPet.setError(null);

        portePet.setEnabled(true);
        portePet.setClickable(true);

        sexoPet.setEnabled(true);
        sexoPet.setClickable(true);

        btSelecionarFoto.setEnabled(true);
        btSelecionarFoto.setAlpha(1);
        btAlterarPet.setVisibility(GONE);
    }

    public void funMostrarLayout() {
        btSelecionarFoto.setVisibility(VISIBLE);
        imgPet.setVisibility(VISIBLE);
        nomePet.setVisibility(VISIBLE);
        especiePet.setVisibility(VISIBLE);
        racaPet.setVisibility(VISIBLE);
        pesoPet.setVisibility(VISIBLE);
        sexoPet.setVisibility(VISIBLE);
        portePet.setVisibility(VISIBLE);
        corPet.setVisibility(VISIBLE);
        descricaoPet.setVisibility(VISIBLE);
        dtNascimentoPet.setVisibility(VISIBLE);
        countTextDescPet.setVisibility(VISIBLE);
        filtrarEspecie.setVisibility(VISIBLE);
        listaPets.setVisibility(VISIBLE);
        textFiltrarEspecie.setVisibility(VISIBLE);
        btAddNovoPet.setVisibility(VISIBLE);
        tvNomePet.setVisibility(VISIBLE);
        tvCorPet.setVisibility(VISIBLE);
        tvEspeciePet.setVisibility(VISIBLE);
        tvRacaPet.setVisibility(VISIBLE);
        tvSexoPet.setVisibility(VISIBLE);
        tvPortePet.setVisibility(VISIBLE);
        tvPesoPet.setVisibility(VISIBLE);
        tvBioPet.setVisibility(VISIBLE);
        btAddPrimeiroPet.setVisibility(GONE);
    }

    public void funMostrarLayoutAddPet() {
        btSelecionarFoto.setVisibility(VISIBLE);
        imgPet.setVisibility(VISIBLE);
        nomePet.setVisibility(VISIBLE);
        especiePet.setVisibility(VISIBLE);
        racaPet.setVisibility(VISIBLE);
        pesoPet.setVisibility(VISIBLE);
        sexoPet.setVisibility(VISIBLE);
        portePet.setVisibility(VISIBLE);
        corPet.setVisibility(VISIBLE);
        descricaoPet.setVisibility(VISIBLE);
        dtNascimentoPet.setVisibility(VISIBLE);
        countTextDescPet.setVisibility(VISIBLE);
        tvNomePet.setVisibility(VISIBLE);
        tvCorPet.setVisibility(VISIBLE);
        tvEspeciePet.setVisibility(VISIBLE);
        tvRacaPet.setVisibility(VISIBLE);
        tvSexoPet.setVisibility(VISIBLE);
        tvPortePet.setVisibility(VISIBLE);
        tvPesoPet.setVisibility(VISIBLE);
        tvBioPet.setVisibility(VISIBLE);
        btVoltarListaPet.setVisibility(VISIBLE);
        btAddPrimeiroPet.setVisibility(GONE);
        linearLayout4.setVisibility(GONE);
        filtrarEspecie.setVisibility(GONE);
        listaPets.setVisibility(GONE);
        textFiltrarEspecie.setVisibility(GONE);
        btAddNovoPet.setVisibility(GONE);
    }

    public void funEsconderLayout() {
        btSelecionarFoto.setVisibility(GONE);
        imgPet.setVisibility(GONE);
        nomePet.setVisibility(GONE);
        especiePet.setVisibility(GONE);
        racaPet.setVisibility(GONE);
        pesoPet.setVisibility(GONE);
        sexoPet.setVisibility(GONE);
        portePet.setVisibility(GONE);
        corPet.setVisibility(GONE);
        descricaoPet.setVisibility(GONE);
        dtNascimentoPet.setVisibility(GONE);
        countTextDescPet.setVisibility(GONE);
        btAlterarPet.setVisibility(GONE);
        filtrarEspecie.setVisibility(GONE);
        listaPets.setVisibility(GONE);
        textFiltrarEspecie.setVisibility(GONE);
        btAddNovoPet.setVisibility(GONE);
        linearLayout4.setVisibility(GONE);
        tvNomePet.setVisibility(GONE);
        tvCorPet.setVisibility(GONE);
        tvEspeciePet.setVisibility(GONE);
        tvRacaPet.setVisibility(GONE);
        tvSexoPet.setVisibility(GONE);
        tvPortePet.setVisibility(GONE);
        tvPesoPet.setVisibility(GONE);
        tvBioPet.setVisibility(GONE);
        btVoltarListaPet.setVisibility(GONE);
        btSalvarNovoPet.setVisibility(GONE);
        btDeletarPet.setVisibility(GONE);
        btAtualizarPet.setVisibility(GONE);
    }

    public void funMostrarPrimeiroLayout() {
        btSelecionarFoto.setVisibility(VISIBLE);
        imgPet.setVisibility(VISIBLE);
        nomePet.setVisibility(VISIBLE);
        especiePet.setVisibility(VISIBLE);
        racaPet.setVisibility(VISIBLE);
        pesoPet.setVisibility(VISIBLE);
        sexoPet.setVisibility(VISIBLE);
        portePet.setVisibility(VISIBLE);
        corPet.setVisibility(VISIBLE);
        descricaoPet.setVisibility(VISIBLE);
        dtNascimentoPet.setVisibility(VISIBLE);
        countTextDescPet.setVisibility(VISIBLE);
        tvNomePet.setVisibility(VISIBLE);
        tvCorPet.setVisibility(VISIBLE);
        tvEspeciePet.setVisibility(VISIBLE);
        tvRacaPet.setVisibility(VISIBLE);
        tvSexoPet.setVisibility(VISIBLE);
        tvPortePet.setVisibility(VISIBLE);
        tvPesoPet.setVisibility(VISIBLE);
        tvBioPet.setVisibility(VISIBLE);
        btAddPrimeiroPet.setVisibility(GONE);
        btAddNovoPet.setVisibility(GONE);
        textFiltrarEspecie.setVisibility(GONE);
        filtrarEspecie.setVisibility(GONE);
        btAlterarPet.setVisibility(GONE);
        btVoltarListaPet.setVisibility(GONE);

        nomePet.setEnabled(true);
        corPet.setEnabled(true);
        pesoPet.setEnabled(true);
        especiePet.setEnabled(true);
        racaPet.setEnabled(true);
        portePet.setEnabled(true);
        sexoPet.setEnabled(true);
        descricaoPet.setEnabled(true);
        dtNascimentoPet.setEnabled(true);
        btSelecionarFoto.setEnabled(true);

        nomePet.setText(null);
        corPet.setText(null);
        pesoPet.setText(null);
        especiePet.setText(null);
        racaPet.setText(null);
        portePet.setSelection(0);;
        sexoPet.setSelection(0);
        descricaoPet.setText(null);
        dtNascimentoPet.setText(null);

        idPetClicado = null;
    }

    public void funMostrarLayoutSuperior() {
        btSelecionarFoto.setVisibility(GONE);
        imgPet.setVisibility(GONE);
        nomePet.setVisibility(GONE);
        especiePet.setVisibility(GONE);
        racaPet.setVisibility(GONE);
        pesoPet.setVisibility(GONE);
        sexoPet.setVisibility(GONE);
        portePet.setVisibility(GONE);
        corPet.setVisibility(GONE);
        descricaoPet.setVisibility(GONE);
        dtNascimentoPet.setVisibility(GONE);
        countTextDescPet.setVisibility(GONE);
        btAddPrimeiroPet.setVisibility(GONE);
        btAlterarPet.setVisibility(GONE);
        tvNomePet.setVisibility(GONE);
        tvCorPet.setVisibility(GONE);
        tvEspeciePet.setVisibility(GONE);
        tvRacaPet.setVisibility(GONE);
        tvSexoPet.setVisibility(GONE);
        tvPortePet.setVisibility(GONE);
        tvPesoPet.setVisibility(GONE);
        tvBioPet.setVisibility(GONE);
        btSalvarNovoPet.setVisibility(GONE);
        btDeletarPet.setVisibility(GONE);
        btAtualizarPet.setVisibility(GONE);
        btVoltarListaPet.setVisibility(GONE);
        linearLayout4.setVisibility(VISIBLE);
        filtrarEspecie.setVisibility(VISIBLE);
        listaPets.setVisibility(VISIBLE);
        textFiltrarEspecie.setVisibility(VISIBLE);
        btAddNovoPet.setVisibility(VISIBLE);
    }

    public void funMostrarLayoutPet() {
        btVoltarListaPet.setVisibility(VISIBLE);
        btSelecionarFoto.setVisibility(VISIBLE);
        imgPet.setVisibility(VISIBLE);
        nomePet.setVisibility(VISIBLE);
        especiePet.setVisibility(VISIBLE);
        racaPet.setVisibility(VISIBLE);
        pesoPet.setVisibility(VISIBLE);
        sexoPet.setVisibility(VISIBLE);
        portePet.setVisibility(VISIBLE);
        corPet.setVisibility(VISIBLE);
        descricaoPet.setVisibility(VISIBLE);
        dtNascimentoPet.setVisibility(VISIBLE);
        countTextDescPet.setVisibility(VISIBLE);
        tvNomePet.setVisibility(VISIBLE);
        tvCorPet.setVisibility(VISIBLE);
        tvEspeciePet.setVisibility(VISIBLE);
        tvRacaPet.setVisibility(VISIBLE);
        tvSexoPet.setVisibility(VISIBLE);
        tvPortePet.setVisibility(VISIBLE);
        tvPesoPet.setVisibility(VISIBLE);
        tvBioPet.setVisibility(VISIBLE);
        listaPets.setVisibility(GONE);
        btAddPrimeiroPet.setVisibility(GONE);
        btAddNovoPet.setVisibility(GONE);
        textFiltrarEspecie.setVisibility(GONE);
        filtrarEspecie.setVisibility(GONE);
        btAlterarPet.setVisibility(GONE);
        linearLayout4.setVisibility(GONE);
    }

}