package com.example.petcareapp.ui.admGerenciarAdm;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.example.petcareapp.ui.admGerenciarClinica.MainModelGerenciarClinica;
import com.example.petcareapp.ui.pet.MainModel;
import com.example.petcareapp.ui.pet.PetDiffCallback;
import com.google.firebase.auth.FirebaseAuth;

import org.checkerframework.checker.units.qual.A;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link admGerenciarAdmFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class admGerenciarAdmFragment extends Fragment {

    // Criando um Executor e um Handler para a thread principal.
    // O Executor roda a tarefa em background.
    private ExecutorService executor;
    // Handler para postar resultados de volta na thread principal da UI
    private final Handler handler = new Handler(Looper.getMainLooper());

    String emailUsuarioAtual, nomeClicadoAdm;
    Integer idUsuarioAtual, idAdmClicado;
    boolean imageChanged = false; // Flag para indicar se a imagem foi alterada
    Bitmap imgOriginalBitmap;
    Bitmap selectedBitmap = null;

    EditText admEmailAdm, admNomeAdm, etPesquisarAdm;
    TextView tvAdmEmailAdm, tvAdmNomeAdm;
    Button btAdmAlterarDadosAdm, btnAdmSelecinarFotoAdm, admDeletarAdm;
    RecyclerView listaGerenciarAdm;
    ImageView admImgAdm;
    ImageButton btVoltarAdmAdm;
    FrameLayout frameLayoutGerenciarAdm;

    ProgressBar progressBarAdm;
    ConstraintLayout mainContentLayoutAdm;

    ArrayList<Integer> listaIdGerenciarAdm = new ArrayList<>();
    ArrayList<byte[]> listaFotoGerenciarAdm = new ArrayList<>();
    ArrayList<String> listaEmailGerenciarAdm = new ArrayList<>();
    ArrayList<String> listaNomeGerenciarAdm = new ArrayList<>();

    private final ArrayList<MainModelGerenciarAdm> listaCompletaDeAdm = new ArrayList<>();
    ArrayList<MainModelGerenciarAdm> mainModels = new ArrayList<>();
    MainAdapterGerenciarAdm mainAdapter;

    // Definindo o ActivityResultLauncher para capturar o resultado da seleção de foto
    private ActivityResultLauncher<Intent> selectPhotoLauncher;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public admGerenciarAdmFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment admGerenciarTutorFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static admGerenciarAdmFragment newInstance(String param1, String param2) {
        admGerenciarAdmFragment fragment = new admGerenciarAdmFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        // Inicializando o ActivityResultLauncher para a seleção de foto
        selectPhotoLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {

                    if (result.getResultCode() == getActivity().RESULT_OK && result.getData() != null) {
                        // Recupera o URI da imagem selecionada
                        Intent data = result.getData();
                        Uri imageUri = data.getData();

                        if (imageUri != null) {
                            // Trabalhando com o URI
                            // String imageUriString = imageUri.toString();

                            // Convertendo o URI para um Bitmap:
                            try {
                                // Converte o URI para um Bitmap
                                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), imageUri);

                                // Armazenando no ImageView ou em uma variável global
                                admImgAdm.setImageBitmap(bitmap);
                                selectedBitmap = bitmap;  // Armazenando a imagem selecionada na variável global

                                // Atualizando a variável de controle de alteração de imagem
                                imageChanged = true;

                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
        );
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_adm_gerenciar_adm, container, false);

        admEmailAdm = view.findViewById(R.id.admEmailAdm);
        admNomeAdm = view.findViewById(R.id.admNomeAdm);
        admDeletarAdm = view.findViewById(R.id.admDeletarAdm);
        etPesquisarAdm = view.findViewById(R.id.etPesquisarAdm);
        listaGerenciarAdm = view.findViewById(R.id.listaGerenciarAdm);
        tvAdmEmailAdm = view.findViewById(R.id.tvAdmEmailAdm);
        tvAdmNomeAdm = view.findViewById(R.id.tvAdmNomeAdm);
        btnAdmSelecinarFotoAdm = view.findViewById(R.id.btnAdmSelecionarFotoAdm);
        frameLayoutGerenciarAdm = view.findViewById(R.id.frameLayoutGerenciarAdm);
        admImgAdm = view.findViewById(R.id.admImgAdm);
        btAdmAlterarDadosAdm = view.findViewById(R.id.btAdmAlterarDadosAdm);
        btVoltarAdmAdm = view.findViewById(R.id.btVoltarAdmAdm);
        mainContentLayoutAdm = view.findViewById(R.id.mainContentLayoutAdm);
        progressBarAdm = view.findViewById(R.id.progressBarAdm);

        // Design Horizontal Layout
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.VERTICAL,false
        );
        listaGerenciarAdm.setLayoutManager(layoutManager);
        listaGerenciarAdm.setItemAnimator(new DefaultItemAnimator());

        // Inicia MainAdapter
        mainAdapter = new MainAdapterGerenciarAdm(getActivity(),mainModels);
        // Set MainAdapter para ListaTutor


        mainAdapter = new MainAdapterGerenciarAdm(getActivity(), mainModels, new MainAdapterGerenciarAdm.OnItemClickListener() {
            @Override
            public void onItemClick(MainModelGerenciarAdm model) {

                executor.execute(() -> {
                    Integer tempIdAdmClicado = null;
                    String tempAdmEmailAdm = null;
                    byte[] tempAdmImgAdm = null;
                    String tempAdmNomeAdm = null;

                    Connection con = null;
                    PreparedStatement stmt = null;
                    ResultSet rs = null;

                    try {
                        // Obtenha o nome do administrador do modelo
                        idAdmClicado = Integer.valueOf(model.getListaIdGerenciarAdm());
                        admImgAdm.setImageDrawable(null);

                        con = ConexaoMysql.conectar();
                        String sql = "SELECT * FROM adm_info_adm WHERE id_login = ?";
                        stmt = con.prepareStatement(sql);
                        stmt.setInt(1, idAdmClicado);
                        rs = stmt.executeQuery();

                        if (rs.next()) {
                            tempIdAdmClicado = Integer.valueOf(rs.getString("id_login"));
                            tempAdmEmailAdm = rs.getString("email");
                            tempAdmImgAdm = rs.getBytes("foto");
                            tempAdmNomeAdm = rs.getString("nome");
                        }

                        final Integer finalIdAdmClicado = tempIdAdmClicado;
                        final String finalAdmEmailAdm = tempAdmEmailAdm;
                        final byte[] finalAdmImgAdm = tempAdmImgAdm;
                        final String finalAdmNomeAdm = tempAdmNomeAdm;

                        handler.post(() -> {
                            if (!isAdded()) return; // Segurança

                            admEmailAdm.setText(finalAdmEmailAdm);
                            admNomeAdm.setText(finalAdmNomeAdm);
                            nomeClicadoAdm = finalAdmNomeAdm;

                            if (finalAdmImgAdm != null) {
                                Bitmap bitmap = BitmapFactory.decodeByteArray(finalAdmImgAdm, 0, finalAdmImgAdm.length);
                                admImgAdm.setImageBitmap(bitmap);
                            }

                            if (admImgAdm.getDrawable() == null) {
                                btnAdmSelecinarFotoAdm.setAlpha(1);
                            } else {
                                btnAdmSelecinarFotoAdm.setAlpha(0);
                            }

                            funMostrarDadosAdm();
                            admEmailAdm.setEnabled(false);
                        });

                    } catch (Exception e) {
                        throw new RuntimeException("Erro ao buscar detalhes do administrador", e);
                    } finally {
                        try {
                            if (rs != null) rs.close();
                            if (stmt != null) stmt.close();
                            if (con != null) con.close();
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    }
                });
            }
        });

        listaGerenciarAdm.setAdapter(mainAdapter);

        etPesquisarAdm.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String termoPesquisa = s.toString().trim();
                if (termoPesquisa.isEmpty()) {
                    // Se a pesquisa está vazia, mostra a lista original completa
                    updateRecyclerView(new ArrayList<>(listaCompletaDeAdm));
                } else {
                    // Se há texto, chama a função de pesquisa
                    funPesquisarAdm(termoPesquisa);
                }
            }
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        });

        btAdmAlterarDadosAdm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAdmAlterarDadosAdm();
            }
        });

        admDeletarAdm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (idAdmClicado == null) {
                    Toast.makeText(getActivity(), "Nenhum administrador selecionado!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (idAdmClicado == 1) {
                    Toast.makeText(getActivity(), "Você não tem permissão para excluir esse administrador!", Toast.LENGTH_SHORT).show();
                    return;
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setMessage("Você tem certeza que deseja excluir o administrador " + nomeClicadoAdm + "?")
                        .setCancelable(false) // Não permite fechar o Dialog clicando fora dele
                        .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Ação ao clicar em "Confirmar"
                                funDeletarAdm();
                            }
                        })
                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Ação ao clicar em "Cancelar"
                            }
                        });

                AlertDialog dialog = builder.create();
                dialog.show();
            }

        });

        btVoltarAdmAdm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funEsconderDadosAdm();
            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        // Garante que o executor está ativo.
        if (executor == null || executor.isShutdown()) {
            executor = Executors.newSingleThreadExecutor();
        }

        // 1. Mostra o ProgressBar e oculta o conteúdo principal imediatamente.
        if (progressBarAdm != null) {
            progressBarAdm.setVisibility(VISIBLE);
        }
        if (mainContentLayoutAdm != null) {
            mainContentLayoutAdm.setVisibility(GONE);
        }

        executor.execute(() -> {
            emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT id_login FROM login WHERE email = ?;";
                stmt = con.prepareStatement(sql);
                stmt.setString(1, emailUsuarioAtual);
                rs = stmt.executeQuery();

                if (rs.next()) {
                    idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
                }

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    funEsconderDadosAdm();
                    funListaAdm();
                    etPesquisarAdm.setText(null);

                    // Finaliza o loading, mostrando o conteúdo.
                    if (progressBarAdm != null) progressBarAdm.setVisibility(GONE);
                    if (mainContentLayoutAdm != null) mainContentLayoutAdm.setVisibility(VISIBLE);
                });

            } catch (Exception e) {
                Log.e("STARTUP_ERROR", "Erro ao buscar ID do usuário", e);
                handler.post(() -> {
                    if (!isAdded()) return;
                    progressBarAdm.setVisibility(GONE);
                    Toast.makeText(getContext(), "Erro ao iniciar. Tente novamente.", Toast.LENGTH_LONG).show();
                });
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    @Override
    public void onStop() {
        super.onStop();
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
        }
    }

    public void funSelecionarFoto() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        // ActivityResultLauncher para iniciar a atividade e capturar o resultado
        selectPhotoLauncher.launch(intent);
    }

    public void funListaAdm() {
        executor.execute(() -> {
            ArrayList<MainModelGerenciarAdm> tempModels = new ArrayList<>();

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT id_login, email, foto, nome FROM adm_info_adm";
                stmt = con.prepareStatement(sql);
                rs = stmt.executeQuery();

                // Limpar as listas antes de adicionar novos dados
                listaIdGerenciarAdm.clear();
                listaEmailGerenciarAdm.clear();
                listaFotoGerenciarAdm.clear();
                listaNomeGerenciarAdm.clear();

                // Preencher as listas com dados do banco
                while (rs.next()) {
                    tempModels.add(new MainModelGerenciarAdm(
                            rs.getInt("id_login"),
                            rs.getBytes("foto"),
                            rs.getString("email"),
                            rs.getString("nome")
                    ));
                }

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    // Atualiza a lista mestre com os novos dados
                    listaCompletaDeAdm.clear();
                    listaCompletaDeAdm.addAll(tempModels);

                    // Exibe a lista completa na tela usando o DiffUtil
                    updateRecyclerView(new ArrayList<>(listaCompletaDeAdm));
                });

            } catch (Exception e) {
                throw new RuntimeException(e);
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

    }

    public void updateRecyclerView(List<MainModelGerenciarAdm> novosAdm) {
        // 1. Cria o callback do DiffUtil, comparando a lista antiga com a nova
        AdmDiffCallback diffCallback = new AdmDiffCallback(this.mainModels, novosAdm);

        // 2. Calcula as diferenças (isso pode ser feito em background se a lista for enorme)
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallback);

        // 3. Atualiza a lista de dados do adapter
        this.mainModels.clear();
        this.mainModels.addAll(novosAdm);

        // 4. Envia as atualizações calculadas para o RecyclerView.
        // Ele fará as animações de forma inteligente, sem piscar!
        diffResult.dispatchUpdatesTo(mainAdapter);
    }

    // Este método é chamado quando a foto é carregada (na seleção da foto)
    public void setImgOriginal(Bitmap bitmap) {
        imgOriginalBitmap = bitmap; // Armazena a imagem original para comparação posterior
        imageChanged = true; // Marca que a imagem foi alterada
    }

    // Método para recuperar a imagem do banco de dados
    private byte[] getImgBytesFromDatabase(Integer idClinica) {
        byte[] imgBytesAtual = null;

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            con = ConexaoMysql.conectar();
            String sql = "SELECT foto FROM adm_info_clinica WHERE id_login = ?";
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, idClinica);
            rs = stmt.executeQuery();

            if (rs.next()) {
                imgBytesAtual = rs.getBytes("foto");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        return imgBytesAtual;
    }

    public void funPesquisarAdm(String termo) {
        ArrayList<MainModelGerenciarAdm> listaFiltrada = new ArrayList<>();
        String filtro = termo.toLowerCase().trim();

        // Itera sobre a lista mestre, que nunca muda.
        for (MainModelGerenciarAdm adm : listaCompletaDeAdm) {
            String nome = adm.getListaNomeGerenciarAdm().toLowerCase();
            String email = adm.getListaEmailGerenciarAdm().toLowerCase();

            if (nome.contains(filtro) || email.contains(filtro)) {
                listaFiltrada.add(adm);
            }
        }
        // Usa o método padrão para atualizar a UI com a lista filtrada.
        updateRecyclerView(listaFiltrada);
    }

    public void funAdmAlterarDadosAdm() {
        executor.execute(() -> {
            String nomeAdm = admNomeAdm.getText().toString().trim();

            if (nomeAdm.isEmpty()) { admNomeAdm.setError("Campo obrigatório"); return; }

            Connection con = null;
            PreparedStatement stmt = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "UPDATE adm SET nome = ? WHERE id_adm = ?";
                stmt = con.prepareStatement(sql);
                stmt.setString(1, nomeAdm);
                stmt.setInt(2, idAdmClicado);
                stmt.executeUpdate();

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    nomeClicadoAdm = nomeAdm;
                    funListaAdm();
                    Toast.makeText(getActivity(), "Dados atualizados com sucesso!", Toast.LENGTH_SHORT).show();
                });

            } catch (Exception e) {
                throw new RuntimeException(e);
            } finally {
                try {
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    public void funDeletarAdm() {
        executor.execute(() -> {
            Connection con = null;
            PreparedStatement stmt = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "DELETE FROM login WHERE id_login = ?";
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, idAdmClicado);
                stmt.execute();

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    funEsconderDadosAdm();
                    funListaAdm();
                    idAdmClicado = null;
                });

            } catch (Exception e) {
                throw new RuntimeException(e);
            } finally {
                try {
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    public void funDesativarCampos() {
        admEmailAdm.setEnabled(false);
        admNomeAdm.setEnabled(false);
    }

    public void funAtivarCampos() {
        admEmailAdm.setEnabled(true);
        admNomeAdm.setEnabled(true);
    }

    public void funLimparCampos() {
        admEmailAdm.setText(null);
        admNomeAdm.setText(null);
        admNomeAdm.setError(null);
    }

    public void funEsconderDadosAdm() {
        frameLayoutGerenciarAdm.setVisibility(GONE);
        btnAdmSelecinarFotoAdm.setVisibility(GONE);
        admImgAdm.setVisibility(GONE);
        tvAdmEmailAdm.setVisibility(GONE);
        admEmailAdm.setVisibility(GONE);
        tvAdmNomeAdm.setVisibility(GONE);
        admNomeAdm.setVisibility(GONE);
        btAdmAlterarDadosAdm.setVisibility(GONE);
        admDeletarAdm.setVisibility(GONE);
        btVoltarAdmAdm.setVisibility(GONE);
        etPesquisarAdm.setVisibility(VISIBLE);
        listaGerenciarAdm.setVisibility(VISIBLE);
    }

    public void funMostrarDadosAdm() {
        etPesquisarAdm.setVisibility(GONE);
        listaGerenciarAdm.setVisibility(GONE);
        btVoltarAdmAdm.setVisibility(VISIBLE);
        frameLayoutGerenciarAdm.setVisibility(VISIBLE);
        btnAdmSelecinarFotoAdm.setVisibility(VISIBLE);
        admImgAdm.setVisibility(VISIBLE);
        tvAdmEmailAdm.setVisibility(VISIBLE);
        admEmailAdm.setVisibility(VISIBLE);
        tvAdmNomeAdm.setVisibility(VISIBLE);
        admNomeAdm.setVisibility(VISIBLE);
        btAdmAlterarDadosAdm.setVisibility(VISIBLE);
        admDeletarAdm.setVisibility(VISIBLE);
        admNomeAdm.setError(null);
    }
}