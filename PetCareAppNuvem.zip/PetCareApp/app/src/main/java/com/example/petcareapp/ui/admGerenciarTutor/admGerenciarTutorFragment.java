package com.example.petcareapp.ui.admGerenciarTutor;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.example.petcareapp.ui.admGerenciarAdm.AdmDiffCallback;
import com.example.petcareapp.ui.admGerenciarAdm.MainModelGerenciarAdm;
import com.example.petcareapp.ui.admGerenciarClinica.MainModelGerenciarClinica;
import com.google.firebase.auth.FirebaseAuth;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link admGerenciarTutorFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class admGerenciarTutorFragment extends Fragment {

    // Criando um Executor e um Handler para a thread principal.
    // O Executor roda a tarefa em background.
    private ExecutorService executor;
    // Handler para postar resultados de volta na thread principal da UI
    private final Handler handler = new Handler(Looper.getMainLooper());

    String emailUsuarioAtual, nomeClicadoTutor;
    Integer idUsuarioAtual, idTutorClicado;
    boolean imageChanged = false; // Flag para indicar se a imagem foi alterada
    Bitmap imgOriginalBitmap;
    Bitmap selectedBitmap = null;

    EditText admEmailTutor, admNomeTutor, admTelefoneTutor, etPesquisarTutor, admDescricaoTutor;
    TextView tvAdmEmailTutor, tvAdmNomeTutor, tvAdmTelefoneTutor, tvAdmDesricaoTutor;
    Button btAdmAlterarDadosTutor, btnAdmSelecinarFotoTutor, admDeletarTutor;
    RecyclerView listaGerenciarTutor;
    ImageView admImgTutor;
    ImageButton btVoltarAdmTutor;
    FrameLayout frameLayoutGerenciarTutor;
    ProgressBar progressBar;
    ConstraintLayout mainContentLayout;

    // ArrayList<String> arrayListaAllTutor;
    // ArrayList<String> arrayListaFiltradaTutor;

    ArrayList<Integer> listaIdGerenciarTutor = new ArrayList<>();
    ArrayList<byte[]> listaFotoGerenciarTutor = new ArrayList<>();
    ArrayList<String> listaEmailGerenciarTutor = new ArrayList<>();
    ArrayList<String> listaNomeGerenciarTutor = new ArrayList<>();


    private final ArrayList<MainModelGerenciarTutor> listaCompletaDeTutor = new ArrayList<>();
    ArrayList<MainModelGerenciarTutor> mainModels = new ArrayList<>();
    MainAdapterGerenciarTutor mainAdapter;

    // Definindo o ActivityResultLauncher para capturar o resultado da seleção de foto
    private ActivityResultLauncher<Intent> selectPhotoLauncher;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public admGerenciarTutorFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment admGerenciarTutorFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static admGerenciarTutorFragment newInstance(String param1, String param2) {
        admGerenciarTutorFragment fragment = new admGerenciarTutorFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        // Inicializando o ActivityResultLauncher para a seleção de foto
        selectPhotoLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {

                    if (result.getResultCode() == getActivity().RESULT_OK && result.getData() != null) {
                        // Recupera o URI da imagem selecionada
                        Intent data = result.getData();
                        Uri imageUri = data.getData();

                        if (imageUri != null) {
                            // Trabalhando com o URI
                            // String imageUriString = imageUri.toString();

                            // Convertendo o URI para um Bitmap:
                            try {
                                // Converte o URI para um Bitmap
                                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), imageUri);

                                // Armazenando no ImageView ou em uma variável global
                                admImgTutor.setImageBitmap(bitmap);
                                selectedBitmap = bitmap;  // Armazenando a imagem selecionada na variável global

                                // Atualizando a variável de controle de alteração de imagem
                                imageChanged = true;

                            } catch (IOException e) {
                                Log.e("PHOTO_PICK", "Erro ao carregar imagem da galeria", e);
                            }
                        }
                    }
                }
        );
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View view = inflater.inflate(R.layout.fragment_adm_gerenciar_tutor, container, false);

       admEmailTutor = view.findViewById(R.id.admEmailTutor);
       admNomeTutor = view.findViewById(R.id.admNomeTutor);
       admTelefoneTutor = view.findViewById(R.id.admTelefoneTutor);
       admDeletarTutor = view.findViewById(R.id.admDeletarTutor);
       etPesquisarTutor = view.findViewById(R.id.etPesquisarTutor);
       listaGerenciarTutor = view.findViewById(R.id.listaGerenciarTutor);
       admDescricaoTutor = view.findViewById(R.id.admDescricaoTutor);
       tvAdmEmailTutor = view.findViewById(R.id.tvAdmEmailTutor);
       tvAdmNomeTutor = view.findViewById(R.id.tvAdmNomeTutor);
       tvAdmTelefoneTutor = view.findViewById(R.id.tvAdmTelefoneTutor);
       tvAdmDesricaoTutor = view.findViewById(R.id.tvAdmDescricaoTutor);
       listaGerenciarTutor = view.findViewById(R.id.listaGerenciarTutor);
       btnAdmSelecinarFotoTutor = view.findViewById(R.id.btnAdmSelecionarFotoTutor);
       frameLayoutGerenciarTutor = view.findViewById(R.id.frameLayoutGerenciarTutor);
       admImgTutor = view.findViewById(R.id.admImgTutor);
       btAdmAlterarDadosTutor = view.findViewById(R.id.btAdmAlterarDadosTutor);
       btVoltarAdmTutor = view.findViewById(R.id.btVoltarAdmTutor);
       mainContentLayout = view.findViewById(R.id.mainContentLayout);
       progressBar = view.findViewById(R.id.progressBar);

        // Design Horizontal Layout
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.VERTICAL,false
        );
        listaGerenciarTutor.setLayoutManager(layoutManager);
        listaGerenciarTutor.setItemAnimator(new DefaultItemAnimator());

        // Inicia MainAdapter
        mainAdapter = new MainAdapterGerenciarTutor(getActivity(),mainModels);
        // Set MainAdapter para ListaTutor

        mainAdapter = new MainAdapterGerenciarTutor(getActivity(), mainModels, new MainAdapterGerenciarTutor.OnItemClickListener() {
            @Override
            public void onItemClick(MainModelGerenciarTutor model) {

                executor.execute(() -> {
                    Integer tempIdTutorClicado = null;
                    byte[] tempAdmFotoTutor = null;
                    String tempAdmEmailTutor = null;
                    String tempAdmNomeTutor = null;
                    String tempAdmDescricaoTutor = null;
                    String tempAdmTelefoneTutor = null;

                    Connection con = null;
                    PreparedStatement stmt = null;
                    ResultSet rs = null;

                    try {
                        // Obtenha o nome do tutor do modelo
                        idTutorClicado = Integer.valueOf(model.getListaIdGerenciarTutor());
                        admImgTutor.setImageDrawable(null);

                        con = ConexaoMysql.conectar();
                        String sql = "SELECT * FROM adm_info_tutor WHERE id_login = ?";
                        stmt = con.prepareStatement(sql);
                        stmt.setInt(1, idTutorClicado);
                        rs = stmt.executeQuery();

                        if (rs.next()) {
                            tempIdTutorClicado = rs.getInt("id_login");
                            tempAdmFotoTutor = rs.getBytes("foto");
                            tempAdmEmailTutor = rs.getString("email");
                            tempAdmNomeTutor = rs.getString("nome");
                            tempAdmDescricaoTutor = rs.getString("descricao");
                            tempAdmTelefoneTutor = rs.getString("telefone");
                        }

                        final Integer finalIdTutorClicado = tempIdTutorClicado;
                        final byte[] finalAdmFotoTutor = tempAdmFotoTutor;
                        final String finalAdmEmailTutor = tempAdmEmailTutor;
                        final String finalAdmNomeTutor = tempAdmNomeTutor;
                        final String finalAdmDescricaoTutor = tempAdmDescricaoTutor;
                        final String finalAdmTelefoneTutor = tempAdmTelefoneTutor;

                        handler.post(() -> {
                            if (!isAdded()) return; // Segurança
                            if (finalAdmFotoTutor != null) {
                                Bitmap bitmap = BitmapFactory.decodeByteArray(finalAdmFotoTutor, 0, finalAdmFotoTutor.length);
                                admImgTutor.setImageBitmap(bitmap);
                            }

                            admEmailTutor.setText(finalAdmEmailTutor);
                            admNomeTutor.setText(finalAdmNomeTutor);
                            nomeClicadoTutor= finalAdmNomeTutor;
                            admDescricaoTutor.setText(finalAdmDescricaoTutor);
                            admTelefoneTutor.setText(finalAdmTelefoneTutor);

                            if (admImgTutor.getDrawable() == null) {
                                btnAdmSelecinarFotoTutor.setAlpha(1);
                            } else {
                                btnAdmSelecinarFotoTutor.setAlpha(0);
                            }

                            funMostrarDadosTutor();
                            admEmailTutor.setEnabled(false);
                        });

                    } catch (Exception e) {
                        throw new RuntimeException("Erro ao buscar detalhes do tutor", e);
                    } finally {
                        try {
                            if (rs != null) rs.close();
                            if (stmt != null) stmt.close();
                            if (con != null) con.close();
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    }
                });
            }
        });

        listaGerenciarTutor.setAdapter(mainAdapter);

        etPesquisarTutor.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String termoPesquisa = s.toString().trim();
                if (termoPesquisa.isEmpty()) {
                    // Se a pesquisa está vazia, mostra a lista original completa
                    updateRecyclerView(new ArrayList<>(listaCompletaDeTutor));
                } else {
                    // Se há texto, chama a função de pesquisa
                    funPesquisarTutor(termoPesquisa);
                }
            }
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        });

        btAdmAlterarDadosTutor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAdmAlterarDadosTutor();
            }
        });

        admDeletarTutor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (idTutorClicado == null) {
                    Toast.makeText(getActivity(), "Nenhum tutor selecionado!", Toast.LENGTH_SHORT).show();
                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setMessage("Você tem certeza que deseja excluir o tutor " + nomeClicadoTutor + "?")
                            .setCancelable(false) // Não permite fechar o Dialog clicando fora dele
                            .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // Ação ao clicar em "Confirmar"
                                    funDeletarTutor();
                                }
                            })
                            .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // Ação ao clicar em "Cancelar"
                                }
                            });

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
            }
        });

        btVoltarAdmTutor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funEsconderDadosTutor();
            }
        });

       return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        // Garante que o executor está ativo.
        if (executor == null || executor.isShutdown()) {
            executor = Executors.newSingleThreadExecutor();
        }

        // 1. Mostra o ProgressBar e oculta o conteúdo principal imediatamente.
        if (progressBar != null) {
            progressBar.setVisibility(VISIBLE);
        }
        if (mainContentLayout != null) {
            mainContentLayout.setVisibility(GONE);
        }

        executor.execute(() -> {
            emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT id_login FROM login WHERE email = ?;";
                stmt = con.prepareStatement(sql);
                stmt.setString(1, emailUsuarioAtual);
                rs = stmt.executeQuery();

                if (rs.next()) {
                    idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
                }

                handler.post(() -> {
                    //  sempre verifica se o fragmento ainda está ativo com if (!isAdded()) return;
                    if (!isAdded()) return;

                    funEsconderDadosTutor();
                    funListaTutor();
                    etPesquisarTutor.setText(null);

                    // Finaliza o loading, mostrando o conteúdo.
                    if (progressBar != null) progressBar.setVisibility(GONE);
                    if (mainContentLayout != null) mainContentLayout.setVisibility(VISIBLE);
                });

            } catch (Exception e) {
                Log.e("STARTUP_ERROR", "Erro ao buscar ID do usuário", e);
                handler.post(() -> {
                    if (!isAdded()) return;
                    progressBar.setVisibility(GONE);
                    Toast.makeText(getContext(), "Erro ao iniciar. Tente novamente.", Toast.LENGTH_LONG).show();
                });
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    @Override
    public void onStop() {
        super.onStop();
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
        }
    }

    public void funSelecionarFoto() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        // ActivityResultLauncher para iniciar a atividade e capturar o resultado
        selectPhotoLauncher.launch(intent);
    }

    public void funListaTutor() {
        ArrayList<MainModelGerenciarTutor> tempModels = new ArrayList<>();

        executor.execute(() -> {
            ArrayList<Integer> tempAdmIdTutor = new ArrayList<>();
            ArrayList<String> tempAdmEmailTutor = new ArrayList<>();
            ArrayList<byte[]> tempAdmFotoTutor = new ArrayList<>();
            ArrayList<String> tempAdmNomeTutor = new ArrayList<>();

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT id_login, email, foto, nome FROM adm_info_tutor";
                stmt = con.prepareStatement(sql);
                rs = stmt.executeQuery();

                // Preencher as listas com dados do banco
                while (rs.next()) {
                    tempModels.add(new MainModelGerenciarTutor(
                            rs.getInt("id_login"),
                            rs.getBytes("foto"),
                            rs.getString("email"),
                            rs.getString("nome")
                    ));
                }

            } catch (Exception e) {
                Log.e("LISTA_TUTOR", "Erro ao buscar lista de tutores", e);
                // Não trava o app, apenas mostra um erro.
                handler.post(() -> {
                    if (!isAdded()) return;
                    Toast.makeText(getContext(), "Erro ao carregar a lista de tutores.", Toast.LENGTH_SHORT).show();
                });
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

            handler.post(() -> {
                if (!isAdded()) return; // Segurança
                // Atualiza a lista mestre com os novos dados
                listaCompletaDeTutor.clear();
                listaCompletaDeTutor.addAll(tempModels);

                // Exibe a lista completa na tela usando o DiffUtil
                updateRecyclerView(new ArrayList<>(listaCompletaDeTutor));
            });
        });
    }

    public void updateRecyclerView(List<MainModelGerenciarTutor> novosTutor) {
        // 1. Cria o callback do DiffUtil, comparando a lista antiga com a nova
        TutorDiffCallback diffCallback = new TutorDiffCallback(this.mainModels, novosTutor);

        // 2. Calcula as diferenças (isso pode ser feito em background se a lista for enorme)
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallback);

        // 3. Atualiza a lista de dados do adapter
        this.mainModels.clear();
        this.mainModels.addAll(novosTutor);

        // 4. Envia as atualizações calculadas para o RecyclerView.
        // Ele fará as animações de forma inteligente, sem piscar!
        diffResult.dispatchUpdatesTo(mainAdapter);
    }

    // Este método é chamado quando a foto é carregada (na seleção da foto)
    public void setImgOriginal(Bitmap bitmap) {
        imgOriginalBitmap = bitmap; // Armazena a imagem original para comparação posterior
        imageChanged = true; // Marca que a imagem foi alterada
    }

    // Método para recuperar a imagem do banco de dados
    private byte[] getImgBytesFromDatabase(Integer idTutor) {
        byte[] imgBytesAtual = null;

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            con = ConexaoMysql.conectar();
            String sql = "SELECT foto FROM adm_info_tutor WHERE id_login = ?";
            stmt = con.prepareStatement(sql);
            stmt.setInt(1, idTutor);
            rs = stmt.executeQuery();

            if (rs.next()) {
                imgBytesAtual = rs.getBytes("foto");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        return imgBytesAtual;
    }

    public void funPesquisarTutor(String termo) {
        ArrayList<MainModelGerenciarTutor> listaFiltrada = new ArrayList<>();
        String filtro = termo.toLowerCase().trim();

        // Itera sobre a lista mestre, que nunca muda.
        for (MainModelGerenciarTutor tutor : listaCompletaDeTutor) {
            String nome = tutor.getListaNomeGerenciarTutor().toLowerCase();
            String email = tutor.getListaEmailGerenciarTutor().toLowerCase();

            if (nome.contains(filtro) || email.contains(filtro)) {
                listaFiltrada.add(tutor);
            }
        }
        // Usa o método padrão para atualizar a UI com a lista filtrada.
        updateRecyclerView(listaFiltrada);
    }

    public void funAdmAlterarDadosTutor() {

        executor.execute(() -> {
            String nomeTutor = admNomeTutor.getText().toString().trim();
            String telefoneTutor = admTelefoneTutor.getText().toString().trim();
            String biografiaTutor = admDescricaoTutor.getText().toString().trim();

            if (nomeTutor.isEmpty()) { admNomeTutor.setError("Campo obrigatório"); return; }

            Connection con = null;
            PreparedStatement stmt = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "UPDATE tutor SET nome = ?, descricao = ?, telefone = ? WHERE id_tutor = ?";
                stmt = con.prepareStatement(sql);
                stmt.setString(1, nomeTutor);
                stmt.setString(2, biografiaTutor);
                stmt.setString(3, telefoneTutor);
                stmt.setInt(4, idTutorClicado);
                stmt.executeUpdate();

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    nomeClicadoTutor = nomeTutor;
                    funListaTutor();
                    Toast.makeText(getActivity(), "Dados atualizados com sucesso!", Toast.LENGTH_SHORT).show();
                });

            } catch (Exception e) {
                throw new RuntimeException(e);
            } finally {
                try {
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    public void funDeletarTutor() {
        executor.execute(() -> {

            Connection con = null;
            PreparedStatement stmt = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "DELETE FROM login WHERE id_login = ?";
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, idTutorClicado);
                stmt.execute();

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    funEsconderDadosTutor();
                    funListaTutor();

                    idTutorClicado = null;
                });

            } catch (Exception e) {
                throw new RuntimeException(e);
            } finally {
                try {
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

    }

    public void funDesativarCampos() {
        admEmailTutor.setEnabled(false);
        admNomeTutor.setEnabled(false);
        admTelefoneTutor.setEnabled(false);
        admDescricaoTutor.setEnabled(false);
    }

    public void funAtivarCampos() {
        admEmailTutor.setEnabled(true);
        admNomeTutor.setEnabled(true);
        admTelefoneTutor.setEnabled(true);
        admDescricaoTutor.setEnabled(true);
    }

    public void funLimparCampos() {
        admEmailTutor.setText(null);
        admNomeTutor.setText(null);
        admTelefoneTutor.setText(null);
        admDescricaoTutor.setText(null);
    }

    public void funEsconderDadosTutor() {
        frameLayoutGerenciarTutor.setVisibility(GONE);
        btnAdmSelecinarFotoTutor.setVisibility(GONE);
        admImgTutor.setVisibility(GONE);
        tvAdmEmailTutor.setVisibility(GONE);
        admEmailTutor.setVisibility(GONE);
        tvAdmNomeTutor.setVisibility(GONE);
        admNomeTutor.setVisibility(GONE);
        tvAdmTelefoneTutor.setVisibility(GONE);
        admTelefoneTutor.setVisibility(GONE);
        tvAdmDesricaoTutor.setVisibility(GONE);
        admDescricaoTutor.setVisibility(GONE);
        btAdmAlterarDadosTutor.setVisibility(GONE);
        admDeletarTutor.setVisibility(GONE);
        btVoltarAdmTutor.setVisibility(GONE);
        etPesquisarTutor.setVisibility(VISIBLE);
        listaGerenciarTutor.setVisibility(VISIBLE);
    }

    public void funMostrarDadosTutor() {
        etPesquisarTutor.setVisibility(GONE);
        listaGerenciarTutor.setVisibility(GONE);
        btVoltarAdmTutor.setVisibility(VISIBLE);
        frameLayoutGerenciarTutor.setVisibility(VISIBLE);
        btnAdmSelecinarFotoTutor.setVisibility(VISIBLE);
        admImgTutor.setVisibility(VISIBLE);
        tvAdmEmailTutor.setVisibility(VISIBLE);
        admEmailTutor.setVisibility(VISIBLE);
        tvAdmNomeTutor.setVisibility(VISIBLE);
        admNomeTutor.setVisibility(VISIBLE);
        tvAdmTelefoneTutor.setVisibility(VISIBLE);
        admTelefoneTutor.setVisibility(VISIBLE);
        tvAdmDesricaoTutor.setVisibility(VISIBLE);
        admDescricaoTutor.setVisibility(VISIBLE);
        btAdmAlterarDadosTutor.setVisibility(VISIBLE);
        admDeletarTutor.setVisibility(VISIBLE);
        admNomeTutor.setError(null);
    }
}