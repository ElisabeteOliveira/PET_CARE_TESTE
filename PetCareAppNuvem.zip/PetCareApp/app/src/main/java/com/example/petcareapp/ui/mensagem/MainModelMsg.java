package com.example.petcareapp.ui.mensagem;

import java.util.Objects;

public class MainModelMsg {

    private Integer idMensagem;

    private Integer idRemetente;
    private Integer idDestinatario;
    private String nomeRemetente;
    private String listaMensagem;

    public MainModelMsg(Integer idMensagem, Integer idRemetente, Integer idDestinatario, String nomeRemetente, String listaMensagem) {
        this.idMensagem = idMensagem;
        this.idRemetente = idRemetente;
        this.idDestinatario = idDestinatario;
        this.nomeRemetente = nomeRemetente;
        this.listaMensagem = listaMensagem;
    }

    public Integer getIdMensagem() {
        return idMensagem;
    }

    public Integer getIdRemetente() {
        return idRemetente;
    }

    public Integer getIdDestinatario() {
        return idDestinatario;
    }

    public String getNomeRemetente() {
        return nomeRemetente;
    }

    public String getListaMensagem() {
        return listaMensagem;
    }

    // Ele agora compara todos os campos que existem NESTA classe.
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MainModelMsg that = (MainModelMsg) o;
        return Objects.equals(idMensagem, that.idMensagem) &&
                Objects.equals(idRemetente, that.idRemetente) &&
                Objects.equals(idDestinatario, that.idDestinatario) &&
                Objects.equals(nomeRemetente, that.nomeRemetente) &&
                Objects.equals(listaMensagem, that.listaMensagem);
    }

    // Ele agora usa os mesmos campos do equals() para gerar o hash.
    @Override
    public int hashCode() {
        return Objects.hash(idMensagem, idRemetente, idDestinatario, nomeRemetente, listaMensagem);
    }
}