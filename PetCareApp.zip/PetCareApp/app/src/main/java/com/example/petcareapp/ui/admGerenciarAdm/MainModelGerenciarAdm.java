package com.example.petcareapp.ui.admGerenciarAdm;

import android.graphics.Bitmap;

public class MainModelGerenciarAdm {
    Integer listaIdGerenciarAdm;
    Bitmap listaFotoGerenciarAdm;
    String listaEmailGerenciarAdm;
    String listaNomeGerenciarAdm;

    public MainModelGerenciarAdm(Integer listaIdGerenciarAdm, Bitmap listaFotoGerenciarAdm, String listaEmailGerenciarAdm, String listaNomeGerenciarAdm) {
        this.listaIdGerenciarAdm = listaIdGerenciarAdm;
        this.listaFotoGerenciarAdm = listaFotoGerenciarAdm;
        this.listaEmailGerenciarAdm = listaEmailGerenciarAdm;
        this.listaNomeGerenciarAdm = listaNomeGerenciarAdm;
    }

    public Integer getListaIdGerenciarAdm() {
        return listaIdGerenciarAdm;
    }
    public Bitmap getListaFotoGerenciarAdm() {
        return listaFotoGerenciarAdm;
    }
    public String getListaEmailGerenciarAdm() {
        return listaEmailGerenciarAdm;
    }
    public String getListaNomeGerenciarAdm() {
        return listaNomeGerenciarAdm;
    }

}

