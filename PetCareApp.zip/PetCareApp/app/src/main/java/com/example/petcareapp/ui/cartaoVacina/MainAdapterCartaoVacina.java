package com.example.petcareapp.ui.cartaoVacina;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petcareapp.R;

import java.util.ArrayList;

public class MainAdapterCartaoVacina extends RecyclerView.Adapter<MainAdapterCartaoVacina.ViewHolder> {

    private ArrayList<MainModelCartaoVacina> mainModels;
    private Context context;
    private OnItemClickListener listener;

    // Interface para clique no item
    public interface OnItemClickListener {
        void onItemClick(MainModelCartaoVacina model);
    }

    // Construtor com listener
    public MainAdapterCartaoVacina(Context context, ArrayList<MainModelCartaoVacina> mainModels, OnItemClickListener listener) {
        this.context = context;
        this.mainModels = mainModels;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_item_cartao_vacina, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MainModelCartaoVacina item = mainModels.get(position);

        holder.listaIdCartao.setText(item.getListaIdCartao());
        holder.listaNomeVacina.setText(item.getListaNomeVacina());
        holder.listaDtVacina.setText(item.getListaDtVacina());

        holder.listaNomeVacina.setMaxLines(1);
        holder.listaNomeVacina.setEllipsize(TextUtils.TruncateAt.END);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(item);
            } else {
                Log.e("MainAdapterCartaoVacina", "Listener is null!");
            }
        });

        // Limitar o texto do nome vacina para 15 caracteres
        String nomeVacina = mainModels.get(position).getListaNomeVacina();
        int maxLength = 15;  // Limite de caracteres
        if (nomeVacina.length() > maxLength) {
            nomeVacina = nomeVacina.substring(0, maxLength) + "...";  // Adiciona "..." se ultrapassar o limite
        }
        holder.listaNomeVacina.setText(nomeVacina);
    }

    @Override
    public int getItemCount() {
        return mainModels != null ? mainModels.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView listaIdCartao, listaNomeVacina, listaDtVacina;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            listaIdCartao = itemView.findViewById(R.id.listaIdCartao);
            listaNomeVacina = itemView.findViewById(R.id.listaNomeVacina);
            listaDtVacina = itemView.findViewById(R.id.listaDtVacina);
        }
    }
}
