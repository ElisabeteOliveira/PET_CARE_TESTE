package com.example.petcareapp.ui.campanha;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.google.firebase.auth.FirebaseAuth;


import java.sql.Connection;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link cadastrarCampanhaFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class cadastrarCampanhaFragment extends Fragment {
    ArrayList<String> dadosLista; //Onde guarda os dados
    ArrayAdapter<String> adapter1,adapter2,adapterEstado; //Adaptador para Startar os dados da lista.
    ArrayList<String> listaIdCampanha = new ArrayList<>();
    ArrayList<String> listaTituloCampanha = new ArrayList<>(), listaInicioCampanha = new ArrayList<>(),
                        listaEstadoCampanha = new ArrayList<>(); //Recicle view campanha

    ArrayList<MainModelCampanha> mainModel = new ArrayList<>();
    boolean campanhaIsNull = true; //  campanha caso exista
    boolean verificarBotoes=false, verificarMyCampanha=false,verificarAllCampanha=false;
    boolean verificarCampanhaAtual=true, primeiraCampanhaSelecionadaSpinner=true;
    Button btAlterarCamapanha, btMinhasCampanhas,btTodasCampanhas,btAtualizarCampanha,btDeletarCampanha;
    Date dataInicio,dataFim ; // Converte uma String para um objeto Date
    EditText nomeCampanha, descCampanha, inicioCampanha, fimCampanha, fonteCampanha,
            logradouroEndCampanha, numeroEndCampanha, cepEndCampanha, bairroEndCampanha,
            cidadeEndCampanha, complementoEndCampanha;
    ImageButton btVoltar,btAddNovaCampanha;
    TextView tvCampanha;
    Integer idCampanhaClicada;
    LinearLayout linearLayout;
    List<String> estadoList,filtroEstadoList;
    MainAdapterCampanha mainAdapter;
     Integer idUsuarioAtual,id_campanha_click;
    RecyclerView listaCampanha;
    Spinner estadoEndCampanha, filtroEstadoCampanha;
    String emailUsuarioAtual, dataI,dataF, tipoUserAtual, ultimaCampanhaSelecionada ="";
    String tituloCampanhaClick;
    String dataStringI = "inicio_campanha", dataStringF = "fim_campanha" ,dataFormatadaI, dataFormatadaF ;//Formatação data
    // Exemplo da data quando vem do banco de dados
    TextView endereco, tvInicioCC,tvLogradouroCC,tvFimCC,tvFonteCC,tvCepCC,tvNroCC,tvEstadoCC,tvComplementoCC,
             tvCidadeCC,tvBairroCC,tvTituloCC,tvDescricaoCC,tvFiltroEstadoCC;



    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public cadastrarCampanhaFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment cadastrarCampanhaFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static cadastrarCampanhaFragment newInstance(String param1, String param2) {
        cadastrarCampanhaFragment fragment = new cadastrarCampanhaFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @SuppressLint({"CutPasteId", "MissingInflatedId", "WrongViewCast"})
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_cadastrar_campanha, container, false);

        filtroEstadoCampanha=view.findViewById(R.id.filtroEstadoCampanha);
        nomeCampanha = view.findViewById(R.id.nomeCampanha);
        descCampanha = view.findViewById(R.id.descCampanha);
        inicioCampanha = view.findViewById(R.id.inicioCampanha);
        fimCampanha = view.findViewById(R.id.fimCampanha);
        fonteCampanha = view.findViewById(R.id.fonteCampanha);
        logradouroEndCampanha = view.findViewById(R.id.logradouroEndCampanha);
        numeroEndCampanha = view.findViewById(R.id.numeroEndCampanha);
        cepEndCampanha = view.findViewById(R.id.cepEndCampanha);
        bairroEndCampanha = view.findViewById(R.id.bairroEndCampanha);
        cidadeEndCampanha = view.findViewById(R.id.cidadeEndCampanha);
        complementoEndCampanha = view.findViewById(R.id.complementoEndCampanha);
        estadoEndCampanha = view.findViewById(R.id.estadoEndCampanha);
        endereco=view.findViewById(R.id.endereco);
        btMinhasCampanhas = view.findViewById(R.id.btMinhasCampanhas);
        btTodasCampanhas = view.findViewById(R.id.btTodasCampanhas);
        btAddNovaCampanha = view.findViewById(R.id.btAddNovaCampanha);
        btAlterarCamapanha = view.findViewById(R.id.btAlterarCampanha);
        btAtualizarCampanha=view.findViewById(R.id.btAtualizarCampanha);
        btDeletarCampanha=view.findViewById(R.id.btDeletarCampanha);
        btVoltar=view.findViewById(R.id.btVoltar);
        listaCampanha=view.findViewById(R.id.listaCampanha);
        linearLayout=view.findViewById(R.id.linearLayout);
        tvTituloCC=view.findViewById(R.id.tvTituloCC);
        tvDescricaoCC=view.findViewById(R.id.tvDescricaoCC);
        tvInicioCC=view.findViewById(R.id.tvInicioCC);
        tvFimCC=view.findViewById(R.id.tvFimCC);
        tvFonteCC=view.findViewById(R.id.tvFonteCC);
        tvLogradouroCC=view.findViewById(R.id.tvLogradouroCC);
        tvCepCC=view.findViewById(R.id.tvCepCC);
        tvNroCC=view.findViewById(R.id.tvNroCC);
        tvBairroCC=view.findViewById(R.id.tvBairroCC);
        tvCidadeCC=view.findViewById(R.id.tvCidadeCC);
        tvEstadoCC=view.findViewById(R.id.tvEstadoCC);
        tvComplementoCC=view.findViewById(R.id.tvComplementoCC);
        tvFiltroEstadoCC=view.findViewById(R.id.tvFiltroEstadoCC);
        tvCampanha=view.findViewById(R.id.tvCampanha);

        // Design Horizontal Layout Cartao Vacina
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.VERTICAL,false
        );

        listaCampanha.setLayoutManager(layoutManager);
        listaCampanha.setItemAnimator(new DefaultItemAnimator());

        // Aplica o filtro de validação
        inicioCampanha.setFilters(new InputFilter[]{ new cadastrarCampanhaFragment.DateInputFilter() });
        fimCampanha.setFilters(new InputFilter[]{ new cadastrarCampanhaFragment.DateInputFilter() });

        inicioCampanha.addTextChangedListener(new TextWatcher() {
            private boolean isUpdatingI;

            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}

            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (isUpdatingI) return;

                // Remove caracteres não numéricos
                String clean = s.toString().replaceAll("[^\\d]", "");
                if (clean.length() > 8) clean = clean.substring(0, 8);

                StringBuilder out = new StringBuilder();
                for (int i = 0; i < clean.length(); i++) {
                    out.append(clean.charAt(i));
                    if ((i == 1 || i == 3) && i != clean.length() - 1) out.append('/');
                }

                isUpdatingI = true;
                inicioCampanha.setText(out.toString());
                inicioCampanha.setSelection(out.length());
                isUpdatingI = false;
            }
        });

        fimCampanha.addTextChangedListener(new TextWatcher() {
            private boolean isUpdatingF;

            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}

            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (isUpdatingF) return;

                // Remove caracteres não numéricos
                String clean = s.toString().replaceAll("[^\\d]", "");
                if (clean.length() > 8) clean = clean.substring(0, 8);

                StringBuilder out = new StringBuilder();
                for (int i = 0; i < clean.length(); i++) {
                    out.append(clean.charAt(i));
                    if ((i == 1 || i == 3) && i != clean.length() - 1) out.append('/');
                }

                isUpdatingF = true;
                fimCampanha.setText(out.toString());
                fimCampanha.setSelection(out.length());
                isUpdatingF = false;
            }
        });

        mainAdapter = new MainAdapterCampanha(getActivity(), mainModel, new MainAdapterCampanha.OnItemClickListener() {
            @Override
            public void onItemClick(MainModelCampanha model) {
                idCampanhaClicada = Integer.valueOf(model.getListaIdCampanha());
                try {
                    Connection con = ConexaoMysql.conectar();
                    String sql = "SELECT * FROM info_campanha WHERE id_alerta_campanha = ?";
                    PreparedStatement stmt = con.prepareStatement(sql);
                    stmt.setInt(1, idCampanhaClicada);
                    ResultSet rs = stmt.executeQuery();
                    if (rs.next()) {
                        id_campanha_click= rs.getInt("id_alerta_campanha");
                        nomeCampanha.setText(rs.getString("nome_campanha"));
                        tituloCampanhaClick = rs.getString("nome_campanha");
                        descCampanha.setText(rs.getString("desc_campanha"));
                        java.util.Date dataInicio = rs.getDate("inicio_campanha");
                        if (dataInicio != null) {
                            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                            String dataFormatada = formato.format(dataInicio);
                            inicioCampanha.setText(dataFormatada);
                        }
                        java.util.Date dataFim = rs.getDate("fim_campanha");
                        if (dataFim != null) {
                            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                            String dataFormatada = formato.format(dataFim);
                            fimCampanha.setText(dataFormatada);
                        }

                        fonteCampanha.setText(rs.getString("fonte_web"));
                        cepEndCampanha.setText(rs.getString("cep"));
                        logradouroEndCampanha.setText(rs.getString("logradouro"));
                        numeroEndCampanha.setText(rs.getString("numero"));
                        complementoEndCampanha.setText(rs.getString("complemento"));
                        bairroEndCampanha.setText(rs.getString("bairro"));
                        cidadeEndCampanha.setText(rs.getString("cidade"));
                    }

                    rs.close();
                    stmt.close();
                    con.close();

                   funMostraCamposCampanha();

                   if (tipoUserAtual.equals("ADM")) {
                       btDeletarCampanha.setVisibility(VISIBLE);
                       btAlterarCamapanha.setVisibility(VISIBLE);
                    } else {
                       if (!verificarCampanhaAtual){
                           btDeletarCampanha.setVisibility(GONE);
                           btAlterarCamapanha.setVisibility(GONE);
                           btAtualizarCampanha.setVisibility(GONE);
                       }
                       else if (verificarCampanhaAtual) {
                           btDeletarCampanha.setVisibility(VISIBLE);
                           btAlterarCamapanha.setVisibility(VISIBLE);
                       }
                   }

                } catch (Exception e) {
                    e.printStackTrace();
                    // Lança uma exceção personalizada ou trata o erro conforme necessário
                    throw new RuntimeException("Erro ao buscar detalhes da vacina", e);
                }
            }
        });

        listaCampanha.setAdapter(mainAdapter);

        // Criar a lista de estadoEndCampanha
            estadoList = Arrays.asList("Acre", "Alagoas", "Amapá", "Amazonas", "Bahia", "Ceará", "Distrito Federal",
                    "Espírito Santo", "Goiás", "Maranhão", "Mato Grosso", "Mato Grosso do Sul", "Minas Gerais", "Pará", "Paraíba",
                    "Paraná", "Pernambuco", "Piauí", "Rio de Janeiro", "Rio Grande do Norte", "Rio Grande do Sul", "Rondônia",
                    "Roraima", "Santa Catarina", "São Paulo", "Sergipe", "Tocantins");

        // Criar a lista de estadoEndCampanha
            filtroEstadoList = Arrays.asList("Todas","Acre", "Alagoas", "Amapá", "Amazonas", "Bahia", "Ceará", "Distrito Federal",
                "Espírito Santo", "Goiás", "Maranhão", "Mato Grosso", "Mato Grosso do Sul", "Minas Gerais", "Pará", "Paraíba",
                "Paraná", "Pernambuco", "Piauí", "Rio de Janeiro", "Rio Grande do Norte", "Rio Grande do Sul", "Rondônia",
                "Roraima", "Santa Catarina", "São Paulo", "Sergipe", "Tocantins");

            // Criar o ArrayAdapter e associar ao Spinner
            adapter1 = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, estadoList);
            adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            estadoEndCampanha.setAdapter(adapter1);

        // Criar o ArrayAdapter e associar ao Spinner
        adapterEstado = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, filtroEstadoList);
        adapterEstado.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        filtroEstadoCampanha.setAdapter(adapterEstado);

        btAtualizarCampanha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btAtualizarCampanha.setVisibility(VISIBLE);
                funAtualizarCamapnhaCadastrada();
                funLimparCamposCadastroCamp();
                funDesativarCamposCampanhas();
                funEscondeCamposCampanha();
                funMyListaCampanha();
                btTodasCampanhas.setVisibility(GONE);
                btMinhasCampanhas.setVisibility(VISIBLE);
            }
        });

        btMinhasCampanhas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //atualizarMyListaCampanha();
                funAllListaCampanha();
                funEscondeCamposCampanha();
                btMinhasCampanhas.setVisibility(GONE);
                btTodasCampanhas.setVisibility(VISIBLE);
            }
        });

        btTodasCampanhas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funMyListaCampanha();
                funEscondeCamposCampanha();
                btTodasCampanhas.setVisibility(GONE);
                btMinhasCampanhas.setVisibility(VISIBLE);
            }
        });

        btAlterarCamapanha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAtivarCamposCampanhas();
                btAlterarCamapanha.setVisibility(GONE);
                btAtualizarCampanha.setVisibility(VISIBLE);
                btDeletarCampanha.setVisibility(VISIBLE);
            }
        });

        btAddNovaCampanha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Acrescentar condição para ficar visí somente para tutor e adm
                NavController navController = Navigation.findNavController(view);//Para fazer a navegação
                navController.navigate(R.id.nav_novaCampanha);//Navegar para outra tela
            }
        });

        btVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funEscondeCamposCampanha();
                funAllListaCampanha();
                filtroEstadoCampanha.setSelection(0);
            }
        });

        filtroEstadoCampanha.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (primeiraCampanhaSelecionadaSpinner){
                    primeiraCampanhaSelecionadaSpinner=false;   //ignora a primeira seleção
                    return;
                }

                String campanhaSelecionada = filtroEstadoCampanha.getSelectedItem().toString();

                if (campanhaSelecionada.equals("Todas")){
                    try {
                        Connection con = ConexaoMysql.conectar();
                        String sql = "SELECT id_alerta_campanha,nome_campanha,inicio_campanha, estado FROM info_campanha ORDER BY inicio_campanha DESC";
                        PreparedStatement stmt = con.prepareStatement(sql);
                        ResultSet rs = stmt.executeQuery();

                        //Limpar as listas antes de adicionar novos dados
                        listaIdCampanha.clear();
                        listaTituloCampanha.clear();
                        listaInicioCampanha.clear();
                        listaEstadoCampanha.clear();

                        // Preencher as listas com dados do banco
                        while (rs.next()){
                            String idCampanha = rs.getString("id_alerta_campanha");
                            String nome_campanha = rs.getString("nome_campanha");

                            // Formatar a data
                            java.util.Date data = rs.getDate("inicio_campanha");
                            String dataFormatada = new SimpleDateFormat("dd/MM/yyyy").format(data);

                            String estado_campanha = rs.getString("estado");

                            listaIdCampanha.add(idCampanha);
                            listaTituloCampanha.add(nome_campanha);
                            listaInicioCampanha.add(dataFormatada);
                            listaEstadoCampanha.add(estado_campanha);
                        }

                        rs.close();
                        stmt.close();
                        con.close();

                        if(!tipoUserAtual.equals("Tutor")) {
                            btMinhasCampanhas.setVisibility(GONE);
                            btTodasCampanhas.setVisibility(VISIBLE);
                        } else if (tipoUserAtual.equals("Tutor")) {
                            btMinhasCampanhas.setVisibility(GONE);
                            btTodasCampanhas.setVisibility(GONE);
                        }

                        // Atualize o RecyclerView com os dados filtrados
                        updateRecyclerView();

                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                    return;
                }

                // Verifica se a campanha selecionada é diferente da última seleção
                if (!campanhaSelecionada.equals(ultimaCampanhaSelecionada)){
                    ultimaCampanhaSelecionada = campanhaSelecionada;

                    try {
                        Connection con = ConexaoMysql.conectar();
                        String sql = "SELECT id_alerta_campanha,nome_campanha,inicio_campanha, estado FROM info_campanha WHERE estado=? ORDER BY inicio_campanha DESC";
                        PreparedStatement stmt = con.prepareStatement(sql);
                        stmt.setString(1,campanhaSelecionada);
                        ResultSet rs = stmt.executeQuery();

                        //Limpar as listas antes de adicionar novos dados
                        listaIdCampanha.clear();
                        listaTituloCampanha.clear();
                        listaInicioCampanha.clear();
                        listaEstadoCampanha.clear();

                        // Preencher as listas com dados do banco
                        while (rs.next()){
                            String idCampanha = rs.getString("id_alerta_campanha");
                            String nome_campanha = rs.getString("nome_campanha");

                            // Formatar a data
                            java.util.Date data = rs.getDate("inicio_campanha");
                            String dataFormatada = new SimpleDateFormat("dd/MM/yyyy").format(data);

                            String estado_campanha = rs.getString("estado");

                            listaIdCampanha.add(idCampanha);
                            listaTituloCampanha.add(nome_campanha);
                            listaInicioCampanha.add(dataFormatada);
                            listaEstadoCampanha.add(estado_campanha);
                        }

                        rs.close();
                        stmt.close();
                        con.close();

                        if(!tipoUserAtual.equals("Tutor")) {
                            btMinhasCampanhas.setVisibility(GONE);
                            btTodasCampanhas.setVisibility(VISIBLE);
                        } else if (tipoUserAtual.equals("Tutor")) {
                            btMinhasCampanhas.setVisibility(GONE);
                            btTodasCampanhas.setVisibility(GONE);
                        }

                        // Atualize o RecyclerView com os dados filtrados
                        updateRecyclerView();

                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        btDeletarCampanha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setMessage("Confirme para excluir a campanha "+tituloCampanhaClick+".")
                        .setCancelable(false) // Não permite fechar o Dialog clicando fora dele
                        .setPositiveButton("Confirma", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // Ação ao clicar em "Confirmar"
                                funDeletarCampanha();
                            }
                        }).setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // Ação ao clicar em "Cancelar"
                            }
                        });

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        return  view;
    }

    @Override
    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login, tipo_user FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
                tipoUserAtual = rs.getString("tipo_user");
            }

            rs.close();
            stmt.close();
            con.close();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        funDesativarCamposCampanhas();
        funEscondeCamposCampanha();
        funAllListaCampanha();
        filtroEstadoCampanha.setSelection(0);
    }

    public static class DateValidator {

        /* Verifica se a string está no formato dd/MM/yyyy e é uma data possível. */
        public static boolean isValidDate(String dateStr) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            sdf.setLenient(false);           // NÃO aceita 32/13/2025 …

            try {
                java.util.Date date = sdf.parse(dateStr);

                // Opcional: limite de ano (ajuste se quiser)
                int year = Integer.parseInt(dateStr.substring(6));
                return year >= 1900 && year <= 2100;
            } catch (ParseException | NumberFormatException e) {
                return false;
            }
        }
    }

    public class DateInputFilter implements InputFilter {

        @Override
        public CharSequence filter(CharSequence source, int start, int end,
                                   Spanned dest, int dstart, int dend) {

            // Monta como ficará o texto se aceitarmos a digitação
            StringBuilder builder = new StringBuilder(dest);
            builder.replace(dstart, dend, source.subSequence(start, end).toString());
            String result = builder.toString();

            // Remove barras para validar só os dígitos
            String digits = result.replaceAll("[^\\d]", "");

            // Limite absoluto: 8 dígitos (ddMMyyyy)
            if (digits.length() > 8) return "";

            // Validação incremental: DIA
            if (digits.length() >= 1) {
                int diaDezena = Character.getNumericValue(digits.charAt(0));
                if (diaDezena > 3) return "";
            }
            if (digits.length() >= 2) {
                int dia = Integer.parseInt(digits.substring(0, 2));
                if (dia < 1 || dia > 31) return "";
            }

            // Validação incremental: MÊS
            if (digits.length() >= 4) {
                int mes = Integer.parseInt(digits.substring(2, 4));
                if (mes < 1 || mes > 12) return "";
            }

            // Validação incremental: ANO (opcional)
            if (digits.length() == 8) {
                int ano = Integer.parseInt(digits.substring(4, 8));
                if (ano < 1900 || ano > 2100) return "";
            }

            // Tudo OK: aceita a digitação
            return null;
        }
    }

    public void funAtualizarCamapnhaCadastrada(){
        String nome = nomeCampanha.getText().toString().trim();
        String descricao = descCampanha.getText().toString().trim();
        String fonte = fonteCampanha.getText().toString().trim();
        String logradouro = logradouroEndCampanha.getText().toString().trim();
        String numero = numeroEndCampanha.getText().toString().trim();
        String complemento = complementoEndCampanha.getText().toString().trim();
        String bairro = bairroEndCampanha.getText().toString().trim();
        String cidade = cidadeEndCampanha.getText().toString().trim();
        String cep = cepEndCampanha.getText().toString().trim();
        String inicio = inicioCampanha.getText().toString().trim();
        String fim = fimCampanha.getText().toString().trim();

        if (!(nome.isEmpty()||descricao.isEmpty()||logradouro.isEmpty()||
                bairro.isEmpty()||cidade.isEmpty()||
                inicio.isEmpty()||fim.isEmpty())){
            try {
                if (dataI==null&&dataF==null){
                    Connection con = ConexaoMysql.conectar();
                    /*id_alerta_campanha, nome_campanha, desc_campanha, inicio_campanha, fim_campanha, fonte_web, fk_id_clinica*/
                    String sql ="UPDATE alerta_campanhas SET nome_campanha=?,desc_campanha=?," +
                            "fonte_web=? WHERE id_alerta_campanha=?";
                    PreparedStatement stmt = con.prepareStatement(sql);
                    stmt.setString(1,nomeCampanha.getText().toString());
                    stmt.setString(2,descCampanha.getText().toString());
                    stmt.setString(3,fonteCampanha.getText().toString());
                    stmt.setInt(4,id_campanha_click);
                    stmt.executeUpdate();

                    /*id_endereco_campanha, logradouro, numero, complemento, bairro, cidade, cep, estado, fk_id_alerta_campanhas*/
                    sql="UPDATE endereco_campanha SET logradouro=?,numero=?,complemento=?,bairro=?,cidade=?,cep=?,estado=? " +
                            "WHERE fk_id_alerta_campanhas=?";
                    /*"fk_id_alerta_campanhas=? WHERE id_endereco_campanha=?;*/
                    stmt = con.prepareStatement(sql);
                    stmt.setString(1,logradouroEndCampanha.getText().toString());
                    stmt.setString(2,numeroEndCampanha.getText().toString());
                    stmt.setString(3,complementoEndCampanha.getText().toString());
                    stmt.setString(4,bairroEndCampanha.getText().toString());
                    stmt.setString(5,cidadeEndCampanha.getText().toString());
                    stmt.setString(6,cepEndCampanha.getText().toString());
                    stmt.setString(7,estadoEndCampanha.getSelectedItem().toString());
                    stmt.setInt(8,id_campanha_click);
                    // stmt.setString(9,id_ec);

                    stmt.executeUpdate();

                    stmt.close();
                    con.close();

                    Toast.makeText(getActivity(), "Campanha atualizada", Toast.LENGTH_SHORT).show();

                }
                else {
                    Connection con = ConexaoMysql.conectar();
                    /*id_alerta_campanha, nome_campanha, desc_campanha, inicio_campanha, fim_campanha, fonte_web, fk_id_clinica*/
                    String sql ="UPDATE alerta_campanhas SET nome_campanha=?,desc_campanha=?,inicio_campanha=?,fim_campanha=?," +
                            "fonte_web=? WHERE id_alerta_campanha=?";
                    PreparedStatement stmt = con.prepareStatement(sql);
                    stmt.setString(1,nomeCampanha.getText().toString());
                    stmt.setString(2,descCampanha.getText().toString());

                    Timestamp timestampI = Timestamp.valueOf(dataI);
                    stmt.setTimestamp(3,timestampI);

                    Timestamp timestampF = Timestamp.valueOf(dataF);
                    stmt.setTimestamp(4,timestampF);

                    stmt.setString(5,fonteCampanha.getText().toString());
                    stmt.setInt(6,id_campanha_click);
                    stmt.executeUpdate();

                    /*id_endereco_campanha, logradouro, numero, complemento, bairro, cidade, cep, estado, fk_id_alerta_campanhas*/
                    sql="UPDATE endereco_campanha SET logradouro=?,numero=?,complemento=?,bairro=?,cidade=?,cep=?,estado=? " +
                            "WHERE fk_id_alerta_campanhas=?";
                    /*"fk_id_alerta_campanhas=? WHERE id_endereco_campanha=?;*/
                    stmt = con.prepareStatement(sql);
                    stmt.setString(1,logradouroEndCampanha.getText().toString());
                    stmt.setString(2,numeroEndCampanha.getText().toString());
                    stmt.setString(3,complementoEndCampanha.getText().toString());
                    stmt.setString(4,bairroEndCampanha.getText().toString());
                    stmt.setString(5,cidadeEndCampanha.getText().toString());
                    stmt.setString(6,cepEndCampanha.getText().toString());
                    stmt.setString(7,estadoEndCampanha.getSelectedItem().toString());
                    stmt.setInt(8,id_campanha_click);
                    // stmt.setString(9,id_ec);

                    stmt.executeUpdate();

                    stmt.close();
                    con.close();

                    Toast.makeText(getActivity(), "Campanha atualizada", Toast.LENGTH_SHORT).show();
                }


            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        else {
            Toast.makeText(getActivity(), "Preencha todos os campos", Toast.LENGTH_SHORT).show();
        }
    }

    public void funDeletarCampanha(){
        if (tipoUserAtual.equals("ADM")) {
            Connection con = ConexaoMysql.conectar();
            String sql = "DELETE FROM alerta_campanhas WHERE id_alerta_campanha = ?";
            try {
                PreparedStatement stmt = con.prepareStatement(sql);
                stmt.setInt(1,id_campanha_click);
                stmt.execute();

                stmt.close();
                con.close();

                funEscondeCamposCampanha();
                funAllListaCampanha();

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } else {
            Connection con = ConexaoMysql.conectar();
            String sql = "DELETE FROM alerta_campanhas WHERE id_alerta_campanha = ? AND fk_id_clinica=?";
            try {
                PreparedStatement stmt = con.prepareStatement(sql);
                stmt.setInt(1,id_campanha_click);
                stmt.setInt(2,idUsuarioAtual);
                stmt.execute();

                stmt.close();
                con.close();

                funEscondeCamposCampanha();
                funAllListaCampanha();

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void updateRecyclerView() {
        // Atualizar o adapter com os novos dados
        mainModel.clear(); // Limpar a lista antiga
        for (int i = 0; i < listaIdCampanha.size(); i++) {
            MainModelCampanha model = new MainModelCampanha(listaIdCampanha.get(i), listaTituloCampanha.get(i),
                    listaInicioCampanha.get(i), listaEstadoCampanha.get(i));
            mainModel.add(model);
        }

        // Notificar o adapter sobre a mudança nos dados
        mainAdapter.notifyDataSetChanged();
    }

    public void funAllListaCampanha() {

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM info_campanha ORDER BY inicio_campanha DESC";
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            // Limpar as listas antes de adicionar novos dados
            listaIdCampanha.clear();
            listaTituloCampanha.clear();
            listaInicioCampanha.clear();
            listaEstadoCampanha.clear();

            // Preencher as listas com dados do banco
            while (rs.next()) {
                String id = rs.getString("id_alerta_campanha");
                String nome = rs.getString("nome_campanha");

                // Formatar a data
                java.util.Date data = rs.getDate("inicio_campanha");
                String dataFormatada = new SimpleDateFormat("dd/MM/yyyy").format(data);

                String estado = rs.getString("estado");

                // Adicionar os dados nas listas
                listaIdCampanha.add(id);
                listaTituloCampanha.add(nome);
                listaInicioCampanha.add(dataFormatada);
                listaEstadoCampanha.add(estado);
            }

            // Fechar os recursos
            rs.close();
            stmt.close();
            con.close();

            verificarCampanhaAtual=false;

            //Atualizar recicle view
            updateRecyclerView();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funMyListaCampanha() {

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM info_campanha WHERE id_login = ? ORDER BY inicio_campanha DESC;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1,idUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            // Limpar as listas antes de adicionar novos dados
            listaIdCampanha.clear();
            listaTituloCampanha.clear();
            listaInicioCampanha.clear();
            listaEstadoCampanha.clear();

            // Preencher as listas com dados do banco
            while (rs.next()) {
                String id = rs.getString("id_alerta_campanha");
                String nome = rs.getString("nome_campanha");

                // Formatar a data
                java.util.Date data = rs.getDate("inicio_campanha");
                String dataFormatada = new SimpleDateFormat("dd/MM/yyyy").format(data);

                String estado = rs.getString("estado");

                // Adicionar os dados nas listas
                listaIdCampanha.add(id);
                listaTituloCampanha.add(nome);
                listaInicioCampanha.add(dataFormatada);
                listaEstadoCampanha.add(estado);
            }

            // Fechar os recursos
            rs.close();
            stmt.close();
            con.close();

            verificarCampanhaAtual=true;

            //Atualizar recicle view
            updateRecyclerView();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funLimparCamposCadastroCamp(){
        nomeCampanha.setText(null);
        descCampanha.setText(null);
        inicioCampanha.setText(null);
        fimCampanha.setText(null);
        fonteCampanha.setText(null);
        logradouroEndCampanha.setText(null);
        cepEndCampanha.setText(null);
        numeroEndCampanha.setText(null);
        bairroEndCampanha.setText(null);
        cidadeEndCampanha.setText(null);
        estadoEndCampanha.setSelection(0);
        complementoEndCampanha.setText(null);
    }

    public void funDesativarCamposCampanhas(){
        nomeCampanha.setEnabled(false);
        descCampanha.setEnabled(false);
        inicioCampanha.setEnabled(false);
        fimCampanha.setEnabled(false);
        fonteCampanha.setEnabled(false);
        logradouroEndCampanha.setEnabled(false);
        numeroEndCampanha.setEnabled(false);
        cepEndCampanha.setEnabled(false);
        bairroEndCampanha.setEnabled(false);
        cidadeEndCampanha.setEnabled(false);
        estadoEndCampanha.setEnabled(false);
        complementoEndCampanha.setEnabled(false);
        btAtualizarCampanha.setVisibility(GONE);
        btAlterarCamapanha.setVisibility(VISIBLE);
    }
    public void funAtivarCamposCampanhas(){
        nomeCampanha.setEnabled(true);
        descCampanha.setEnabled(true);
        inicioCampanha.setEnabled(true);
        fimCampanha.setEnabled(true);
        fonteCampanha.setEnabled(true);
        logradouroEndCampanha.setEnabled(true);
        numeroEndCampanha.setEnabled(true);
        cepEndCampanha.setEnabled(true);
        bairroEndCampanha.setEnabled(true);
        cidadeEndCampanha.setEnabled(true);
        estadoEndCampanha.setEnabled(true);
        complementoEndCampanha.setEnabled(true);
        btAlterarCamapanha.setVisibility(GONE);
    }

    public void funEscondeCamposCampanha(){

        if (tipoUserAtual.equals("Tutor")){
            btTodasCampanhas.setVisibility(GONE);
            btMinhasCampanhas.setVisibility(GONE);
            btAddNovaCampanha.setVisibility(GONE);
        }
        else if (!(tipoUserAtual.equals("Tutor"))){
            btTodasCampanhas.setVisibility(VISIBLE);
            btAddNovaCampanha.setVisibility(VISIBLE);
        }

        nomeCampanha.setVisibility(GONE);
        descCampanha.setVisibility(GONE);
        inicioCampanha.setVisibility(GONE);
        fimCampanha.setVisibility(GONE);
        fonteCampanha.setVisibility(GONE);
        logradouroEndCampanha.setVisibility(GONE);
        numeroEndCampanha.setVisibility(GONE);
        cepEndCampanha.setVisibility(GONE);
        bairroEndCampanha.setVisibility(GONE);
        cidadeEndCampanha.setVisibility(GONE);
        estadoEndCampanha.setVisibility(GONE);
        complementoEndCampanha.setVisibility(GONE);
        endereco.setVisibility(GONE);
        btAlterarCamapanha.setVisibility(GONE);
        btAtualizarCampanha.setVisibility(GONE);
        btDeletarCampanha.setVisibility(GONE);
        btVoltar.setVisibility(GONE);
        tvCampanha.setVisibility(GONE);
        filtroEstadoCampanha.setVisibility(VISIBLE);

        tvTituloCC.setVisibility(GONE);
        tvDescricaoCC.setVisibility(GONE);
        tvInicioCC.setVisibility(GONE);
        tvFimCC.setVisibility(GONE);
        tvFonteCC.setVisibility(GONE);
        tvLogradouroCC.setVisibility(GONE);
        tvCepCC.setVisibility(GONE);
        tvNroCC.setVisibility(GONE);
        tvBairroCC.setVisibility(GONE);
        tvCidadeCC.setVisibility(GONE);
        tvEstadoCC.setVisibility(GONE);
        tvComplementoCC.setVisibility(GONE);
        tvFiltroEstadoCC.setVisibility(VISIBLE);

        listaCampanha.setVisibility(VISIBLE);
        linearLayout.setVisibility(VISIBLE);
    }

    public void funMostraCamposCampanha(){

        listaCampanha.setVisibility(GONE);
        linearLayout.setVisibility(GONE);

        tvTituloCC.setVisibility(VISIBLE);
        tvDescricaoCC.setVisibility(VISIBLE);
        tvInicioCC.setVisibility(VISIBLE);
        tvFimCC.setVisibility(VISIBLE);
        tvFonteCC.setVisibility(VISIBLE);
        tvLogradouroCC.setVisibility(VISIBLE);
        tvCepCC.setVisibility(VISIBLE);
        tvNroCC.setVisibility(VISIBLE);
        tvBairroCC.setVisibility(VISIBLE);
        tvCidadeCC.setVisibility(VISIBLE);
        tvEstadoCC.setVisibility(VISIBLE);
        tvComplementoCC.setVisibility(VISIBLE);
        tvFiltroEstadoCC.setVisibility(GONE);
        btVoltar.setVisibility(VISIBLE);
        tvCampanha.setVisibility(VISIBLE);
        filtroEstadoCampanha.setVisibility(GONE);
        btMinhasCampanhas.setVisibility(GONE);
        btTodasCampanhas.setVisibility(GONE);
        btAddNovaCampanha.setVisibility(GONE);

        nomeCampanha.setVisibility(VISIBLE);
        descCampanha.setVisibility(VISIBLE);
        inicioCampanha.setVisibility(VISIBLE);
        fimCampanha.setVisibility(VISIBLE);
        fonteCampanha.setVisibility(VISIBLE);
        logradouroEndCampanha.setVisibility(VISIBLE);
        numeroEndCampanha.setVisibility(VISIBLE);
        cepEndCampanha.setVisibility(VISIBLE);
        bairroEndCampanha.setVisibility(VISIBLE);
        cidadeEndCampanha.setVisibility(VISIBLE);
        estadoEndCampanha.setVisibility(VISIBLE);
        complementoEndCampanha.setVisibility(VISIBLE);
        endereco.setVisibility(VISIBLE);
        btAlterarCamapanha.setVisibility(VISIBLE);
        btDeletarCampanha.setVisibility(VISIBLE);


    }

}