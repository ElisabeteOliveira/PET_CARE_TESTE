package com.example.petcareapp.ui.mensagem;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.petcareapp.R;
import com.example.petcareapp.ui.mensagem.MainModelContato;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainAdapterContato extends RecyclerView.Adapter<MainAdapterContato.ViewHolder> {
    ArrayList<MainModelContato> mainModels;
    Context context;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(MainModelContato model);
    }

    public MainAdapterContato(Context context, ArrayList<MainModelContato> mainModels, OnItemClickListener listener) {
        this.context = context;
        this.mainModels = mainModels;
        this.listener = listener;
    }

    public MainAdapterContato(FragmentActivity activity, ArrayList<MainModelContato> mainModels) {
        this.context = activity;
        this.mainModels = mainModels;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_item_contato, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MainModelContato model = mainModels.get(position);

        holder.listaIdContato.setText(model.getListaIdContato());

        byte[] fotoBytes = model.listaFotoContato; // Pega os bytes do modelo

        Glide.with(context)
                .load(fotoBytes) // Carrega os bytes diretamente
                .placeholder(R.drawable.user) // Imagem padrão enquanto carrega
                .error(R.drawable.user)       // Imagem padrão se der erro ou se os bytes forem nulos
                .circleCrop()                        // Arredonda a imagem
                .into(holder.listaFotoContato); // Seu ImageView

        // Configura o listener de clique
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(mainModels.get(position));  // Passa o item clicado para o listener
            } else {
                Log.e("MainAdapter", "Listener is null!");  // Log para ajudar a diagnosticar
            }
        });

        // Limitar o texto do nome do contato para 20 caracteres
        String nomeContato = mainModels.get(position).getListaNomeContato();
        int maxLength = 15;  // Limite de caracteres
        if (nomeContato.length() > maxLength) {
            nomeContato = nomeContato.substring(0, maxLength) + "...";  // Adiciona "..." se ultrapassar o limite
        }

        holder.listaNomeContato.setText(nomeContato);
    }

    @Override
    public int getItemCount() {
        return mainModels != null ? mainModels.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView listaIdContato;
        CircleImageView listaFotoContato;
        TextView listaNomeContato;

        @SuppressLint("WrongViewCast")
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            listaIdContato = itemView.findViewById(R.id.listaIdContato);
            listaFotoContato = itemView.findViewById(R.id.listaFotoContato);
            listaNomeContato = itemView.findViewById(R.id.listaNomeContato);
        }
    }
}
