package com.example.petcareapp.ui.admGerenciarTutor;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;

import com.example.petcareapp.ui.admGerenciarTutor.MainModelGerenciarTutor;

import java.util.List;
import java.util.Objects;

public class TutorDiffCallback extends DiffUtil.Callback {

    private final List<MainModelGerenciarTutor> oldList;
    private final List<MainModelGerenciarTutor> newList;

    public TutorDiffCallback(List<MainModelGerenciarTutor> oldList, List<MainModelGerenciarTutor> newList) {
        this.oldList = oldList;
        this.newList = newList;
    }

    @Override
    public int getOldListSize() {
        return oldList.size();
    }

    @Override
    public int getNewListSize() {
        return newList.size();
    }

    // Verifica se dois itens são o MESMO item (geralmente pelo ID)
    @Override
    public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
        return oldList.get(oldItemPosition).getListaIdGerenciarTutor().equals(newList.get(newItemPosition).getListaIdGerenciarTutor());
    }

    // Verifica se o CONTEÚDO de um item mudou (ex: nome ou foto)
    @Override
    public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
        return oldList.get(oldItemPosition).equals(newList.get(newItemPosition));
    }
}