package com.example.petcareapp.ui.admGerenciarTutor;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petcareapp.R;
import com.example.petcareapp.ui.pet.MainModel;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainAdapterGerenciarTutor extends RecyclerView.Adapter<MainAdapterGerenciarTutor.ViewHolder> {

    private ArrayList<MainModelGerenciarTutor> mainModels;
    private Context context;
    private OnItemClickListener listener;

    // Interface para clique no item
    public interface OnItemClickListener {
        void onItemClick(MainModelGerenciarTutor model);
    }

    // Construtor com listener
    public MainAdapterGerenciarTutor(Context context, ArrayList<MainModelGerenciarTutor> mainModels, OnItemClickListener listener) {
        this.context = context;
        this.mainModels = mainModels;
        this.listener = listener;
    }

    public MainAdapterGerenciarTutor(FragmentActivity activity, ArrayList<MainModelGerenciarTutor> mainModels) {
        this.context = context;
        this.mainModels = mainModels;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_item_gerenciar, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MainModelGerenciarTutor item = mainModels.get(position);

        holder.listaIdGerenciarTutor.setText(String.valueOf(item.getListaIdGerenciarTutor()));

        Bitmap foto = item.getListaFotoGerenciarTutor();
        if (foto != null) {
            holder.listaFotoGerenciarTutor.setImageBitmap(foto);
        } else {
            // Usa imagem padrão do drawable
            holder.listaFotoGerenciarTutor.setImageResource(R.drawable.user);
        }

        holder.listaEmailGerenciarTutor.setText(item.getListaEmailGerenciarTutor());
        holder.listaNomeGerenciarTutor.setText(item.getListaNomeGerenciarTutor());

        holder.listaEmailGerenciarTutor.setMaxLines(1);
        holder.listaEmailGerenciarTutor.setEllipsize(TextUtils.TruncateAt.END);

        holder.listaNomeGerenciarTutor.setMaxLines(1);
        holder.listaNomeGerenciarTutor.setEllipsize(TextUtils.TruncateAt.END);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(item);
            } else {
                Log.e("MainAdapterLista", "Listener is null!");
            }
        });

        // Limitar o texto do email para 25 caracteres
        String emailTutor = mainModels.get(position).getListaEmailGerenciarTutor();
        int maxLength = 25;  // Limite de caracteres
        if (emailTutor.length() > maxLength) {
            emailTutor = emailTutor.substring(0, maxLength) + "...";  // Adiciona "..." se ultrapassar o limite
        }
        holder.listaEmailGerenciarTutor.setText(emailTutor);

        // Limitar o texto do nome para 25 caracteres
        String nomeTutor = mainModels.get(position).getListaNomeGerenciarTutor();
        int maxLength1 = 25;  // Limite de caracteres
        if (nomeTutor.length() > maxLength1) {
            nomeTutor = nomeTutor.substring(0, maxLength) + "...";  // Adiciona "..." se ultrapassar o limite
        }
        holder.listaNomeGerenciarTutor.setText(nomeTutor);
    }

    @Override
    public int getItemCount() {
        return mainModels != null ? mainModels.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView listaFotoGerenciarTutor;
        TextView listaIdGerenciarTutor, listaEmailGerenciarTutor, listaNomeGerenciarTutor;

        @SuppressLint("WrongViewCast")
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            listaIdGerenciarTutor = itemView.findViewById(R.id.listaIdGerenciar);
            listaFotoGerenciarTutor = itemView.findViewById(R.id.listaFotoGerenciar);
            listaEmailGerenciarTutor = itemView.findViewById(R.id.listaEmailGerenciar);
            listaNomeGerenciarTutor = itemView.findViewById(R.id.listaNomeGerenciar);
        }
    }

    public void atualizarLista(ArrayList<MainModelGerenciarTutor> novaLista) {
        mainModels.clear();
        mainModels.addAll(novaLista);
        notifyDataSetChanged();
    }

}


