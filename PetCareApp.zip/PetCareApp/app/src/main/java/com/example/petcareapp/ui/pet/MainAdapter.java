package com.example.petcareapp.ui.pet;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petcareapp.R;
import com.example.petcareapp.ui.admGerenciarTutor.MainModelGerenciarTutor;

import org.w3c.dom.Text;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.ViewHolder> {
    ArrayList<MainModel> mainModels;
    Context context;
    private OnItemClickListener listener;
    private MainModel model;

    // Interface para lidar com o clique do item
    public interface OnItemClickListener {
        void onItemClick(MainModel model);
    }

    // Construtor que aceita o listener
    public MainAdapter(Context context, ArrayList<MainModel> mainModels, OnItemClickListener listener) {
        this.context = context;
        this.mainModels = mainModels;
        this.listener = listener;
    }

    public MainAdapter(FragmentActivity activity, ArrayList<MainModel> mainModels) {
        this.context = context;
        this.mainModels = mainModels;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Criando view
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_item,parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.listaFotoPet.setImageBitmap(mainModels.get(position).getListaFotoPet());

        // Set nome do pet para TextView
        holder.listaNomePet.setText(mainModels.get(position).getListaNomePet());

        // Set nome do pet para TextView
        holder.listaIdPet.setText(mainModels.get(position).getListaIdPet());

        // Configura o listener de clique
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(mainModels.get(position));  // Passa o item clicado para o listener
            } else {
                Log.e("MainAdapter", "Listener is null!");  // Log para ajudar a diagnosticar
            }
        });

        // Limitar o texto do nome do pet para 15 caracteres
        String nomePet = mainModels.get(position).getListaNomePet();
        int maxLength = 10;  // Limite de caracteres
        if (nomePet.length() > maxLength) {
            nomePet = nomePet.substring(0, maxLength) + "...";  // Adiciona "..." se ultrapassar o limite
        }
        holder.listaNomePet.setText(nomePet);
    }

    @Override
    public int getItemCount() {
        return mainModels != null ? mainModels.size() : 0;  // Retorna 0 se a lista for null
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        // Inicia variável
        CircleImageView listaFotoPet;
        TextView listaIdPet;
        TextView listaNomePet;
        @SuppressLint("WrongViewCast")
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            listaFotoPet = itemView.findViewById(R.id.listaPetFoto);
            listaIdPet = itemView.findViewById(R.id.listaIdPet);
            listaNomePet = itemView.findViewById(R.id.listaNomePet);

            // Limitar o texto para 1 linha e aplicar elipse
            listaNomePet.setMaxLines(1);
            listaNomePet.setEllipsize(TextUtils.TruncateAt.END);
        }
    }
}
