package com.example.petcareapp.ui.cartaoVacina;

import android.graphics.Bitmap;

public class MainModelVacina {
    byte[] listaFotoPetVac;
    String listaNomePetVac;
    String listaIdPetVac;

    public MainModelVacina(byte[] listaFotoPetVac, String listaNomePetVac, String listaIdPetVac) {
        this.listaFotoPetVac = listaFotoPetVac;
        this.listaNomePetVac = listaNomePetVac;
        this.listaIdPetVac = listaIdPetVac;
    }

    public byte[] getListaFotoPetVac() {
        return listaFotoPetVac;
    }
    public String getListaNomePetVac() {
        return listaNomePetVac;
    }
    public String getListaIdPetVac() {
        return listaIdPetVac;
    }

}
