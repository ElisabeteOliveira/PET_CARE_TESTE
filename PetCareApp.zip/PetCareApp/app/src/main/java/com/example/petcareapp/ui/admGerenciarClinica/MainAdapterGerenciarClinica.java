package com.example.petcareapp.ui.admGerenciarClinica;

import android.content.Context;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petcareapp.R;
import com.example.petcareapp.ui.pet.MainModel;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainAdapterGerenciarClinica extends RecyclerView.Adapter<MainAdapterGerenciarClinica.ViewHolder> {

    private ArrayList<MainModelGerenciarClinica> mainModels;
    private Context context;
    private OnItemClickListener listener;

    // Interface para clique no item
    public interface OnItemClickListener {
        void onItemClick(MainModelGerenciarClinica model);
    }

    // Construtor com listener
    public MainAdapterGerenciarClinica(Context context, ArrayList<MainModelGerenciarClinica> mainModels, OnItemClickListener listener) {
        this.context = context;
        this.mainModels = mainModels;
        this.listener = listener;
    }

    public MainAdapterGerenciarClinica(FragmentActivity activity, ArrayList<MainModelGerenciarClinica> mainModels) {
        this.context = context;
        this.mainModels = mainModels;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_item_gerenciar, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MainModelGerenciarClinica item = mainModels.get(position);

        holder.listaIdGerenciarClinica.setText(String.valueOf(item.getListaIdGerenciarClinica()));

        Bitmap foto = item.getListaFotoGerenciarClinica();
        if (foto != null) {
            holder.listaFotoGerenciarClinica.setImageBitmap(foto);
        } else {
            // Usa imagem padrão do drawable
            holder.listaFotoGerenciarClinica.setImageResource(R.drawable.petshop);
        }

        holder.listaEmailGerenciarClinica.setText(item.getListaEmailGerenciarClinica());
        holder.listaNomeGerenciarClinica.setText(item.getListaNomeGerenciarClinica());

        holder.listaEmailGerenciarClinica.setMaxLines(1);
        holder.listaEmailGerenciarClinica.setEllipsize(TextUtils.TruncateAt.END);

        holder.listaNomeGerenciarClinica.setMaxLines(1);
        holder.listaNomeGerenciarClinica.setEllipsize(TextUtils.TruncateAt.END);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(item);
            } else {
                Log.e("MainAdapterLista", "Listener is null!");
            }
        });

        // Limitar o texto do email para 25 caracteres
        String emailClinica = mainModels.get(position).getListaEmailGerenciarClinica();
        int maxLength = 25;  // Limite de caracteres
        if (emailClinica.length() > maxLength) {
            emailClinica = emailClinica.substring(0, maxLength) + "...";  // Adiciona "..." se ultrapassar o limite
        }
        holder.listaEmailGerenciarClinica.setText(emailClinica);

        // Limitar o texto do nome para 25 caracteres
        String nomeClinica = mainModels.get(position).getListaNomeGerenciarClinica();
        int maxLength1 = 25;  // Limite de caracteres
        if (nomeClinica.length() > maxLength1) {
            nomeClinica = nomeClinica.substring(0, maxLength) + "...";  // Adiciona "..." se ultrapassar o limite
        }
        holder.listaNomeGerenciarClinica.setText(nomeClinica);
    }

    @Override
    public int getItemCount() {
        return mainModels != null ? mainModels.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView listaFotoGerenciarClinica;
        TextView listaIdGerenciarClinica, listaEmailGerenciarClinica, listaNomeGerenciarClinica;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            listaIdGerenciarClinica = itemView.findViewById(R.id.listaIdGerenciar);
            listaFotoGerenciarClinica = itemView.findViewById(R.id.listaFotoGerenciar);
            listaEmailGerenciarClinica = itemView.findViewById(R.id.listaEmailGerenciar);
            listaNomeGerenciarClinica = itemView.findViewById(R.id.listaNomeGerenciar);
        }
    }

    public void atualizarLista(ArrayList<MainModelGerenciarClinica> novaLista) {
        mainModels.clear();
        mainModels.addAll(novaLista);
        notifyDataSetChanged();
    }

}


