package com.example.petcareapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;

import com.example.petcareapp.ui.seguranca.segurancaFragment;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;

import com.example.petcareapp.databinding.ActivityMainAdmBinding;
import com.google.firebase.auth.FirebaseAuth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MainAdmActivity extends AppCompatActivity {

    String emailUsuarioAtual;
    Integer idUsuarioAtual;

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityMainAdmBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainAdmBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.appBarMainAdm.toolbar);
        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_perfil_adm, R.id.nav_cadastrar_adm, R.id.nav_adm_gerenciar_tutor, R.id.nav_adm_gerenciar_clinica, R.id.nav_adm_gerenciar_adm, R.id.nav_doenca, R.id.nav_campanha, R.id.nav_gallery, R.id.nav_slideshow)
                .setOpenableLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main_adm);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_adm, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) { //Ação do Menu
        // Se o item do menu for selecionado, navegue para o fragmento de configurações

        if (item.getItemId() == R.id.action_sair) {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(MainAdmActivity.this, LoginActivity.class);
            // Finaliza telas anteriores, impedindo de voltar após o logout
            //intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }

        if (item.getItemId() == R.id.action_seguranca) {
            NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main_adm); //Nav MainActivity
            // Navegue para o fragmento desejado
            navController.navigate(R.id.nav_seguranca); // Nav da Tela
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main_adm);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    @Override
    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
            }

            rs.close();
            stmt.close();
            con.close();

            // Verificação do ID
            new Thread(() -> {
                boolean isAdminMaster = idUsuarioAtual == 1;

                runOnUiThread(() -> {
                    if (!isAdminMaster) {
                        Menu menu = binding.navView.getMenu();
                        MenuItem itemCadastrarAdm = menu.findItem(R.id.nav_cadastrar_adm);
                        MenuItem itemGerenciarAdm = menu.findItem(R.id.nav_adm_gerenciar_adm);
                        if (itemCadastrarAdm != null) itemCadastrarAdm.setVisible(false);
                        if (itemGerenciarAdm != null) itemGerenciarAdm.setVisible(false);
                    }
                });
            }).start();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}