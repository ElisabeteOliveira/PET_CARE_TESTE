package com.example.petcareapp.ui.mensagem;

import android.graphics.Bitmap;

import com.example.petcareapp.ui.pet.MainModel;

import java.util.Arrays;
import java.util.Objects;

public class MainModelContato {

    String listaIdContato;
    byte[] listaFotoContato;
    String listaNomeContato;

    public MainModelContato(String listaIdContato, byte[] listaFotoContato, String listaNomeContato) {
        this.listaIdContato = listaIdContato;
        this.listaFotoContato = listaFotoContato;
        this.listaNomeContato = listaNomeContato;
    }

    public String getListaIdContato() {
        return listaIdContato;
    }

    public byte[] getListaFotoContato() {
        return listaFotoContato;
    }

    public String getListaNomeContato() {
        return listaNomeContato;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        MainModelContato mainModel = (MainModelContato) o;
        // Compara todos os campos importantes
        return Objects.equals(listaIdContato, mainModel.listaIdContato) &&
                Objects.equals(listaNomeContato, mainModel.listaNomeContato) &&
                Arrays.equals(listaFotoContato, mainModel.listaFotoContato); // 'Arrays.equals' para byte[]
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(listaIdContato, listaNomeContato);
        result = 31 * result + Arrays.hashCode(listaFotoContato);
        return result;
    }
}

