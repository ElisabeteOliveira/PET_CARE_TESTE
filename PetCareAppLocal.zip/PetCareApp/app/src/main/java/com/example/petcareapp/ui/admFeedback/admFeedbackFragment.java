package com.example.petcareapp.ui.admFeedback;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.os.Bundle;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.example.petcareapp.ui.admGerenciarAdm.AdmDiffCallback;
import com.example.petcareapp.ui.admGerenciarAdm.MainModelGerenciarAdm;
import com.example.petcareapp.ui.admGerenciarTutor.MainModelGerenciarTutor;
import com.example.petcareapp.ui.cartaoVacina.MainAdapterCartaoVacina;
import com.example.petcareapp.ui.cartaoVacina.MainAdapterVacina;
import com.example.petcareapp.ui.cartaoVacina.MainModelCartaoVacina;
import com.example.petcareapp.ui.cartaoVacina.MainModelVacina;
import com.google.firebase.auth.FirebaseAuth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import de.hdodenhof.circleimageview.CircleImageView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link admFeedbackFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class admFeedbackFragment extends Fragment {

    // Criando um Executor e um Handler para a thread principal.
    // O Executor roda a tarefa em background.
    private ExecutorService executor;
    // Handler para postar resultados de volta na thread principal da UI
    private final Handler handler = new Handler(Looper.getMainLooper());

    String emailUsuarioAtual;
    Integer idUsuarioAtual, idFeedbackClicado;

    RecyclerView listaFeedback;
    TextView tvEmailFeedback, tvMsgFeedback, tvDataFeedback;
    EditText emailFeedback, msgFeedback, etPesquisarFeedback;
    CircleImageView imgFeedback;
    ImageButton btVoltarLista;

    ProgressBar progressBar;
    ConstraintLayout mainContentLayout;

    private final ArrayList<MainModelFeedback> listaCompletaDeFeeback = new ArrayList<>();
    ArrayList<MainModelFeedback> mainModels = new ArrayList<>();
    MainAdapterFeedback mainAdapter;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public admFeedbackFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment admFeedbackFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static admFeedbackFragment newInstance(String param1, String param2) {
        admFeedbackFragment fragment = new admFeedbackFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_adm_feedback, container, false);

        etPesquisarFeedback = view.findViewById(R.id.etPesquisarFeedback);
        listaFeedback = view.findViewById(R.id.listaFeedback);
        tvEmailFeedback = view.findViewById(R.id.tvEmailFeedback);
        tvMsgFeedback = view.findViewById(R.id.tvMsgFeedback);
        tvDataFeedback = view.findViewById(R.id.tvDataFeedback);
        emailFeedback = view.findViewById(R.id.emailFeedback);
        msgFeedback = view.findViewById(R.id.msgFeedback);
        imgFeedback = view.findViewById(R.id.imgFeedback);
        btVoltarLista = view.findViewById(R.id.btVoltarLista);
        mainContentLayout = view.findViewById(R.id.mainContentLayout);
        progressBar = view.findViewById(R.id.progressBar);

        // Design Horizontal Layout
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.VERTICAL,false
        );
        listaFeedback.setLayoutManager(layoutManager);
        listaFeedback.setItemAnimator(new DefaultItemAnimator());

        mainAdapter = new MainAdapterFeedback(getActivity(), mainModels, new MainAdapterFeedback.OnItemClickListener() {
            @Override
            public void onItemClick(MainModelFeedback model) {
                idFeedbackClicado = Integer.valueOf(model.getListaIdFeedback());
                Bitmap roundedBitmap = null;

                executor.execute(() -> {
                    Connection con = null;
                    PreparedStatement stmt = null;
                    ResultSet rs = null;

                    byte[] fotoTutor = null;
                    byte[] fotoClinica = null;
                    String email = null;
                    String msg = null;
                    Timestamp timestamp = null;

                    try {
                        con = ConexaoMysql.conectar();
                        String sql = "SELECT * FROM adm_info_feedback WHERE id_feedback = ?";
                        stmt = con.prepareStatement(sql);
                        stmt.setInt(1, idFeedbackClicado);
                        rs = stmt.executeQuery();

                        if (rs.next()) {
                            fotoTutor = rs.getBytes("foto_tutor");
                            fotoClinica = rs.getBytes("foto_clinica");
                            email = rs.getString("email");
                            msg = rs.getString("feedback_mensagem");
                            timestamp = rs.getTimestamp("dt_hr_feedback");
                        }

                        final byte[] finalFotoTutor = fotoTutor;
                        final byte[] finalFotoClinica = fotoClinica;
                        final String finalEmail = email;
                        final String finalMsg = msg;
                        final Timestamp finalTimestamp = timestamp;

                        handler.post(() -> {
                            if(!isAdded()) return;

                            if (finalFotoTutor != null) {
                                // Converter a foto para Bitmap
                                Bitmap fotoBitmap = BitmapFactory.decodeByteArray(finalFotoTutor, 0, finalFotoTutor.length);
                                imgFeedback.setImageBitmap(fotoBitmap);
                            } else if (!(finalFotoClinica == null)) {
                                // Converter a foto para Bitmap
                                Bitmap fotoBitmap = BitmapFactory.decodeByteArray(finalFotoClinica, 0, finalFotoClinica.length);
                                imgFeedback.setImageBitmap(fotoBitmap);
                            } else {
                                Bitmap fotoPadrao = BitmapFactory.decodeResource(getResources(), R.drawable.user);
                                imgFeedback.setImageBitmap(fotoPadrao);
                            }

                            emailFeedback.setText(finalEmail);
                            msgFeedback.setText(finalMsg);

                            if (finalTimestamp != null) {
                                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm", new Locale("pt", "BR"));
                                String dataFormatada = sdf.format(finalTimestamp);
                                tvDataFeedback.setText(dataFormatada);
                            } else {
                                tvDataFeedback.setText("Data não disponível");
                            }

                            funMostrarFeedback();
                        });

                    } catch (Exception e) {
                        e.printStackTrace();
                        // Lança uma exceção personalizada ou trata o erro conforme necessário
                        throw new RuntimeException("Erro ao buscar detalhes do feedback", e);
                    } finally {
                        try {
                            if (rs != null) rs.close();
                            if (stmt != null) stmt.close();
                            if (con != null) con.close();
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    }
                });
            }
        });

        listaFeedback.setAdapter(mainAdapter);

        btVoltarLista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                funMostrarLayout();
            }
        });

        etPesquisarFeedback.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String termoPesquisa = s.toString().trim();
                if (termoPesquisa.isEmpty()) {
                    // Se a pesquisa está vazia, mostra a lista original completa
                    updateRecyclerView(new ArrayList<>(listaCompletaDeFeeback));
                } else {
                    // Se há texto, chama a função de pesquisa
                    funPesquisarFeedback(termoPesquisa);
                }
            }
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        // Garante que o executor está ativo.
        if (executor == null || executor.isShutdown()) {
            executor = Executors.newSingleThreadExecutor();
        }

        // 1. Mostra o ProgressBar e oculta o conteúdo principal imediatamente.
        if (progressBar != null) {
            progressBar.setVisibility(VISIBLE);
        }
        if (mainContentLayout != null) {
            mainContentLayout.setVisibility(GONE);
        }

        executor.execute(() -> {
            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT id_login FROM login WHERE email = ?;";
                stmt = con.prepareStatement(sql);
                stmt.setString(1, emailUsuarioAtual);
                rs = stmt.executeQuery();

                if (rs.next()) {
                    idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
                }

                handler.post(() -> {
                    if(!isAdded()) return;

                    funMostrarLayout();
                    funListaFeeback();

                    // Finaliza o loading, mostrando o conteúdo.
                    if (progressBar != null) progressBar.setVisibility(GONE);
                    if (mainContentLayout != null) mainContentLayout.setVisibility(VISIBLE);
                });

            } catch (Exception e) {
                Log.e("STARTUP_ERROR", "Erro ao buscar ID do usuário", e);
                progressBar.setVisibility(GONE);
                Toast.makeText(getContext(), "Erro ao iniciar. Tente novamente.", Toast.LENGTH_LONG).show();
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    @Override
    public void onStop() {
        super.onStop();
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
        }
    }

    public void funListaFeeback() {
        executor.execute(() -> {
            ArrayList<MainModelFeedback> tempModels = new ArrayList<>();

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT * FROM adm_info_feedback ORDER BY id_feedback DESC";
                stmt = con.prepareStatement(sql);
                rs = stmt.executeQuery();

                // Preencher as listas com dados do banco
                while (rs.next()) {
                    byte[] fotoTutor = rs.getBytes("foto_tutor");
                    byte[] fotoClinica = rs.getBytes("foto_clinica");

                    byte[] fotoFinal = (fotoTutor != null) ? fotoTutor : fotoClinica;

                    tempModels.add(new MainModelFeedback(
                            fotoFinal,
                            rs.getString("id_feedback"),
                            rs.getString("email"),
                            rs.getString("feedback_mensagem"),
                            rs.getString("dt_hr_feedback")
                    ));
                }

                handler.post(() -> {
                    if(!isAdded()) return;

                    // Atualiza a lista mestre com os novos dados
                    listaCompletaDeFeeback.clear();
                    listaCompletaDeFeeback.addAll(tempModels);

                    // Atualize o RecyclerView com os dados
                    updateRecyclerView(new ArrayList<>(listaCompletaDeFeeback));
                });

            } catch (Exception e) {
                Log.e("ERRO", "Erro ao buscar feedback", e);
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    Log.e("ERRO", "Erro ao buscar feedback", e);
                }
            }
        });
    }

    public void updateRecyclerView(List<MainModelFeedback> novosFeedback) {
        // 1. Cria o callback do DiffUtil, comparando a lista antiga com a nova
        FeedbackDiffCallback diffCallback = new FeedbackDiffCallback(this.mainModels, novosFeedback);

        // 2. Calcula as diferenças (isso pode ser feito em background se a lista for enorme)
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallback);

        // 3. Atualiza a lista de dados do adapter
        this.mainModels.clear();
        this.mainModels.addAll(novosFeedback);

        // 4. Envia as atualizações calculadas para o RecyclerView.
        // Ele fará as animações de forma inteligente, sem piscar!
        diffResult.dispatchUpdatesTo(mainAdapter);
    }

    public void funPesquisarFeedback(String termo) {
        ArrayList<MainModelFeedback> listaFiltrada = new ArrayList<>();
        String filtro = termo.toLowerCase().trim();

        // Itera sobre a lista mestre, que nunca muda.
        for (MainModelFeedback feed : listaCompletaDeFeeback) {
            String email = feed.getListaEmailFeedback().toLowerCase();
            String msg = feed.getListaMsgFeedback().toLowerCase();

            if (email.contains(filtro) || msg.contains(filtro)) {
                listaFiltrada.add(feed);
            }
        }
        // Usa o método padrão para atualizar a UI com a lista filtrada.
        updateRecyclerView(listaFiltrada);
    }

    public void funMostrarLayout() {
        imgFeedback.setVisibility(GONE);
        btVoltarLista.setVisibility(GONE);
        tvEmailFeedback.setVisibility(GONE);
        emailFeedback.setVisibility(GONE);
        tvMsgFeedback.setVisibility(GONE);
        msgFeedback.setVisibility(GONE);
        tvDataFeedback.setVisibility(GONE);
        etPesquisarFeedback.setVisibility(VISIBLE);
        listaFeedback.setVisibility(VISIBLE);
        etPesquisarFeedback.setText(null);
    }

    public void funMostrarFeedback() {
        etPesquisarFeedback.setVisibility(GONE);
        listaFeedback.setVisibility(GONE);
        imgFeedback.setVisibility(VISIBLE);
        btVoltarLista.setVisibility(VISIBLE);
        tvEmailFeedback.setVisibility(VISIBLE);
        emailFeedback.setVisibility(VISIBLE);
        tvMsgFeedback.setVisibility(VISIBLE);
        msgFeedback.setVisibility(VISIBLE);
        tvDataFeedback.setVisibility(VISIBLE);
        emailFeedback.setEnabled(false);
        msgFeedback.setEnabled(false);
        etPesquisarFeedback.setText(null);
    }

}