package com.example.petcareapp.ui.cartaoVacina;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static android.view.View.generateViewId;
import static android.widget.Toast.LENGTH_LONG;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.example.petcareapp.ui.pet.MainModel;
import com.example.petcareapp.ui.pet.PetDiffCallback;
import com.google.firebase.auth.FirebaseAuth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link cartaoVacinaFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class cartaoVacinaFragment extends Fragment {

    String emailUsuarioAtual, especieSelecionada, nomeVacinaClicada;
    String ultimaEspecieSelecionada = "";
    Integer idUsuarioAtual, idPetClicadoVac, idCartaoClicado, idPetClicado;

    RecyclerView listaVacina, listaCartaoVacina, listaPets;

    EditText nome_vacina, dt_vacinacao, lote_vacina, medico_vet, clinica_vet;

    Button btSalvarVacina, btAtualizarVacina, btAlterarVacina, btDeletarVacina;

    ImageView btAddNovaVacina;

    Spinner filtrarEspecieVac, spinnerFiltrarAllVacinas, spinnerFiltrarVacinasClick;

    TextView tvFiltrarEspecieVac, tvPetNull, tvVacinas, tvNovaVacina,
            tvVacina, tvNomeVacina, tvLoteVacina, tvDataVacina, tvMedicoVet, tvClinicaVet;

    ImageButton btVoltarListaPet;

    ProgressBar progressBar;
    ConstraintLayout mainContentLayout;

    boolean verificarBt;
    boolean primeiraSelecaoSpinner = true; // Flag para ignorar primeira seleção do spinner quando ele e carregado

    private ExecutorService executor;
    // Handler para postar resultados de volta na thread principal da UI
    private final Handler handler = new Handler(Looper.getMainLooper());

    ArrayList<MainModelVacina> mainModels = new ArrayList<>();
    ArrayList<MainModelCartaoVacina> mainModelsCartao = new ArrayList<>();
    ArrayList<MainModelLista> mainModelsPets = new ArrayList<>();

    MainAdapterVacina mainAdapter;
    MainAdapterCartaoVacina mainAdapterCartao;
    MainAdapterLista mainAdapterLista;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public cartaoVacinaFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment cartaoVacinaFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static cartaoVacinaFragment newInstance(String param1, String param2) {
        cartaoVacinaFragment fragment = new cartaoVacinaFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_cartao_vacina, container, false);

        tvFiltrarEspecieVac = view.findViewById(R.id.tvFiltrarEspecieVac);
        filtrarEspecieVac = view.findViewById(R.id.filtrarEspecieVac);
        nome_vacina = view.findViewById(R.id.nome_vacina);
        dt_vacinacao = view.findViewById(R.id.dt_vacinacao);
        lote_vacina = view.findViewById(R.id.lote_vacina);
        medico_vet = view.findViewById(R.id.medico_vet);
        clinica_vet = view.findViewById(R.id.clinica_vet);
        btSalvarVacina = view.findViewById(R.id.btSalvarVacina);
        btAddNovaVacina = view.findViewById(R.id.btAddNovaVacina);
        listaVacina = view.findViewById(R.id.listaVacina);
        listaCartaoVacina = view.findViewById(R.id.listaCartaoVacina);
        listaPets = view.findViewById(R.id.listaPets);
        tvVacinas = view.findViewById(R.id.tvVacinas);
        tvPetNull = view.findViewById(R.id.tvPetNull);
        tvNovaVacina = view.findViewById(R.id.tvNovaVacina);
        btAtualizarVacina = view.findViewById(R.id.btAtualizarVacina);
        btAlterarVacina = view.findViewById(R.id.btAlterarVacina);
        tvVacina = view.findViewById(R.id.tvVacina);
        btDeletarVacina = view.findViewById(R.id.btDeletarVacina);
        tvNomeVacina = view.findViewById(R.id.tvNomeVacina);
        tvLoteVacina = view.findViewById(R.id.tvLoteVacina);
        tvDataVacina = view.findViewById(R.id.tvDataVacina);
        tvMedicoVet = view.findViewById(R.id.tvMedicoVet);
        tvClinicaVet = view.findViewById(R.id.tvClinicaVet);
        spinnerFiltrarVacinasClick = view.findViewById(R.id.spinnerfiltrarVacinasClick);
        spinnerFiltrarAllVacinas = view.findViewById(R.id.spinnerfiltrarAllVacinas);
        mainContentLayout = view.findViewById(R.id.mainContentLayout);
        progressBar = view.findViewById(R.id.progressBar);
        btVoltarListaPet = view.findViewById(R.id.btVoltarListaPet);

        btVoltarListaPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //funListaPets();
                funListaPets(petsEncontrados -> {
                    funMostrarAllVacinas();
                });
            }
        });

        dt_vacinacao.addTextChangedListener(new TextWatcher() {
            private String current = "";
            private final String ddmmyyyy = "DDMMYYYY";

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().equals(current)) {
                    return; // Evita loop infinito
                }

                // Limpa o texto de tudo que não for dígito
                String clean = s.toString().replaceAll("[^\\d]", "");

                // Limita o tamanho para 8 dígitos (DDMMYYYY)
                if (clean.length() > 8) {
                    clean = clean.substring(0, 8);
                }

                StringBuilder formatted = new StringBuilder();
                int cleanLen = clean.length();
                int i = 0;

                // Constrói a string formatada
                if (cleanLen > 0) {
                    // Adiciona os dois primeiros dígitos (DD)
                    int end = Math.min(cleanLen, 2);
                    formatted.append(clean.substring(0, end));
                    i += end;

                    // Adiciona a primeira barra
                    if (cleanLen > 2) {
                        formatted.append('/');
                        end = Math.min(cleanLen, 4);
                        formatted.append(clean.substring(2, end));
                        i += (end - 2);
                    }

                    // Adiciona a segunda barra
                    if (cleanLen > 4) {
                        formatted.append('/');
                        end = Math.min(cleanLen, 8);
                        formatted.append(clean.substring(4, end));
                        i += (end - 4);
                    }
                }

                current = formatted.toString();
                dt_vacinacao.setText(current);
                dt_vacinacao.setSelection(current.length()); // Mantém o cursor no final
            }
        });

        // Cria a lista de opções spinner All Vacinas
        String[] opcoesAllVacinas = {"Selecione", "Próximas", "Aplicadas", "Todas"};

        // Cria um adapter e define no Spinner
        ArrayAdapter<String> adapterAllVacinas = new ArrayAdapter<>(
                getContext(), // ou this se for Activity
                android.R.layout.simple_spinner_item,
                opcoesAllVacinas
        );
        adapterAllVacinas.setDropDownViewResource(R.layout.spinner_text_color);
        spinnerFiltrarAllVacinas.setAdapter(adapterAllVacinas);

        // Evitar que o onItemSelected dispare logo na criação
        //spinnerFiltrarAllVacinas.setSelection(0, /* animate = */ false);

        spinnerFiltrarAllVacinas.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            private boolean firstTime = true;   // Para ignorar a primeira chamada automática spinner ListaPets

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (firstTime) {               // Ignora a primeira vez
                    firstTime = false;
                    return;
                }

                switch (position) {
                    case 1:  // "Próximas"
                        funListaCartaoProximasAll();
                        break;

                    case 2:  // "Aplicadas"
                        funListaCartaoAplicadasAll();
                        break;

                    case 3:  // "Todas"
                        funListaAllVacinas(() -> {
                            // Same as above, add specific post-load UI logic if needed
                        });
                        break;

                    // posição 0 é "Selecione" não faz nada
                    default:
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Nada a fazer aqui
            }
        });

        // Cria a lista de opções spinner Vacinas Click
        String[] opcoesClickVacinas = {"Selecione", "Próximas", "Aplicadas", "Todas"};

        // Cria um adapter e define no Spinner
        ArrayAdapter<String> adapterClickVacinas = new ArrayAdapter<>(
                getContext(), // ou this se for Activity
                android.R.layout.simple_spinner_item,
                opcoesClickVacinas
        );
        adapterClickVacinas.setDropDownViewResource(R.layout.spinner_text_color);
        spinnerFiltrarVacinasClick.setAdapter(adapterClickVacinas);

        // Evitar que o onItemSelected dispare logo na criação
        //spinnerFiltrarAllVacinas.setSelection(0, /* animate = */ false);

        spinnerFiltrarVacinasClick.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            private boolean firstTimeclick = true;   // Para ignorar a primeira chamada automática spinner ListaPets

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (firstTimeclick) {               // Ignora a primeira vez
                    firstTimeclick = false;
                    return;
                }

                switch (position) {
                    case 1:  // "Próximas"
                        funListaCartaoProximas();
                        break;

                    case 2:  // "Aplicadas"
                        funListaCartaoAplicadas();
                        break;

                    case 3:  // "Todas"
                        // funListaPets();
                       funMostrarAllVacinas();
                        break;

                    // posição 0 é "Selecione" não faz nada
                    default:
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Nada a fazer aqui
            }
        });

        // Design Horizontal Layout
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.HORIZONTAL,false
        );
        listaVacina.setLayoutManager(layoutManager);
        listaVacina.setItemAnimator(new DefaultItemAnimator());

        // Design Horizontal Layout Cartao Vacina
        LinearLayoutManager layoutManagerCartao = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.VERTICAL,false
        );
        listaCartaoVacina.setLayoutManager(layoutManagerCartao);
        listaCartaoVacina.setItemAnimator(new DefaultItemAnimator());

        // Design Horizontal Layout Lista Pets
        LinearLayoutManager layoutManagerLista = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.VERTICAL,false
        );
        listaPets.setLayoutManager(layoutManagerLista);
        listaPets.setItemAnimator(new DefaultItemAnimator());

        mainAdapter = new MainAdapterVacina(getActivity(), mainModels, new MainAdapterVacina.OnItemClickListener() {
            @Override
            public void onItemClick(MainModelVacina model) {
                // Supondo que o bug do NumberFormatException foi corrigido no seu MainModelVacina
                idPetClicadoVac = Integer.valueOf(model.getListaIdPetVac());

                // Chama a nova função assíncrona e passa o callback
                funListaCartao(vacinasEncontradas -> {
                    if (!isAdded()) return;

                    // A lógica de UI agora fica DENTRO do callback, executando no momento certo.
                    if (vacinasEncontradas) {
                        funEsconderAllVacinas();
                        funMostrarVacinas();
                    } else {
                        funVacinaNull();
                        funLimparCamposVacina();
                        funAtivarCamposVacina();
                    }
                });
            }
        }) {
            @Override
            public void onItemClick(MainAdapterVacina model) {

            }
        };

        mainAdapterCartao = new MainAdapterCartaoVacina(getActivity(), mainModelsCartao, new MainAdapterCartaoVacina.OnItemClickListener() {
            @Override
            public void onItemClick(MainModelCartaoVacina model) {
                // Capture final values for use inside the inner class/lambda
                final Integer clickedCartaoId = Integer.valueOf(model.getListaIdCartao());
                idCartaoClicado = clickedCartaoId;
                final String clickedVacinaNome = model.getListaNomeVacina();
                nomeVacinaClicada = clickedVacinaNome;

                // Show a progress indicator or disable UI interactions if necessary
                //progressBar.setVisibility(VISIBLE);

                executor.execute(() -> {
                    Connection con = null;
                    PreparedStatement stmt = null;
                    ResultSet rs = null;

                    // Variables to hold fetched data
                    String fetchedNomeVacina = null;
                    String fetchedLoteVacina = null;
                    String fetchedMedicoVet = null;
                    String fetchedClinicaVet = null;
                    String fetchedDataVacinacao = null; // Store formatted date as string

                    try {
                        con = ConexaoMysql.conectar();
                        String sql = "SELECT nome_vacina, dt_vacinacao, lote_vacina, medico_vet, clinica_vet " +
                                "FROM view_cartao_vacinacao WHERE id_cartao_vacinacao = ?";
                        stmt = con.prepareStatement(sql);
                        stmt.setInt(1, clickedCartaoId);
                        rs = stmt.executeQuery();

                        if (rs.next()) {
                            fetchedNomeVacina = rs.getString("nome_vacina");

                            Date dataUtil = rs.getDate("dt_vacinacao");
                            if (dataUtil != null) {
                                SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault());
                                fetchedDataVacinacao = formato.format(dataUtil);
                            }

                            fetchedLoteVacina = rs.getString("lote_vacina");
                            fetchedMedicoVet = rs.getString("medico_vet");
                            fetchedClinicaVet = rs.getString("clinica_vet");
                        }

                    } catch (Exception e) {
                        Log.e("DB_ERROR", "Erro ao buscar detalhes da vacina no click do item: " + e.getMessage(), e);
                        // Post an error message to the UI thread
                        handler.post(() -> {
                            if (isAdded()) { // Check if fragment is still attached
                                Toast.makeText(getContext(), "Erro ao carregar detalhes da vacina.", Toast.LENGTH_LONG).show();
                            }
                        });
                        // Do not rethrow RuntimeException here, handle gracefully
                    } finally {
                        try {
                            if (rs != null) rs.close();
                            if (stmt != null) stmt.close();
                            if (con != null) con.close();
                        } catch (Exception e) {
                            e.printStackTrace(); // Log cleanup errors
                        }
                    }

                    // Post the UI update back to the main thread
                    final String finalFetchedNomeVacina = fetchedNomeVacina;
                    final String finalFetchedDataVacinacao = fetchedDataVacinacao;
                    final String finalFetchedLoteVacina = fetchedLoteVacina;
                    final String finalFetchedMedicoVet = fetchedMedicoVet;
                    final String finalFetchedClinicaVet = fetchedClinicaVet;

                    handler.post(() -> {
                        if (!isAdded()) { // Check if fragment is still attached to avoid crashes
                            return;
                        }

                        // Hide progress indicator if it was shown
                        //progressBar.setVisibility(GONE);

                        // Update UI elements with fetched data
                        nome_vacina.setText(finalFetchedNomeVacina);
                        dt_vacinacao.setText(finalFetchedDataVacinacao);
                        lote_vacina.setText(finalFetchedLoteVacina);
                        medico_vet.setText(finalFetchedMedicoVet);
                        clinica_vet.setText(finalFetchedClinicaVet);

                        funMostrarLayoutVacina();
                        funDesativarCamposVacina();
                    });
                });
            }
        });

        mainAdapterLista = new MainAdapterLista(getActivity(), mainModelsPets, new MainAdapterLista.OnItemClickListener() {
            @Override
            public void onItemClick(MainModelLista model) {
                // Captura os valores finais para uso dentro do Executor
                final Integer clickedCartaoId = model.getListaIdCartaoVac1();
                final Integer clickedPetId = model.getListaIdPetVac1();
                final String clickedVacinaNome = model.getListaNomeVacinaVac1();

                // Opcional: Mostre um indicador de progresso
                //progressBar.setVisibility(VISIBLE);

                executor.execute(() -> {
                    Connection con = null;
                    PreparedStatement stmt = null;
                    ResultSet rs = null;

                    // Variáveis para armazenar os dados recuperados do banco
                    String fetchedNomeVacina = null;
                    String fetchedLoteVacina = null;
                    String fetchedMedicoVet = null;
                    String fetchedClinicaVet = null;
                    String fetchedDataVacinacao = null; // Armazena a data formatada como string

                    try {
                        con = ConexaoMysql.conectar();
                        String sql = "SELECT nome_vacina, dt_vacinacao, lote_vacina, medico_vet, clinica_vet " +
                                "FROM view_cartao_vacinacao WHERE id_cartao_vacinacao = ?";
                        stmt = con.prepareStatement(sql);
                        stmt.setInt(1, clickedCartaoId);
                        rs = stmt.executeQuery();

                        if (rs.next()) {
                            fetchedNomeVacina = rs.getString("nome_vacina");

                            Date dataUtil = rs.getDate("dt_vacinacao");
                            if (dataUtil != null) {
                                SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault());
                                fetchedDataVacinacao = formato.format(dataUtil);
                            }

                            fetchedLoteVacina = rs.getString("lote_vacina");
                            fetchedMedicoVet = rs.getString("medico_vet");
                            fetchedClinicaVet = rs.getString("clinica_vet");
                        }

                    } catch (Exception e) {
                        Log.e("DB_ERROR", "Erro ao buscar detalhes da vacina na lista de pets (onItemClick): " + e.getMessage(), e);
                        // Posta uma mensagem de erro para o tópico da UI
                        handler.post(() -> {
                            if (isAdded()) { // Verifica se o fragmento ainda está anexado
                                Toast.makeText(getContext(), "Erro ao carregar detalhes da vacina.", Toast.LENGTH_LONG).show();
                            }
                        });
                        // Não relance RuntimeException aqui; trate o erro de forma elegante
                    } finally {
                        // Garante que os recursos do banco de dados sejam fechados
                        try {
                            if (rs != null) rs.close();
                            if (stmt != null) stmt.close();
                            if (con != null) con.close();
                        } catch (Exception e) {
                            e.printStackTrace(); // Log de erros de limpeza
                        }
                    }

                    // Posta a atualização da UI de volta para o tópico principal
                    final String finalFetchedNomeVacina = fetchedNomeVacina;
                    final String finalFetchedDataVacinacao = fetchedDataVacinacao;
                    final String finalFetchedLoteVacina = fetchedLoteVacina;
                    final String finalFetchedMedicoVet = fetchedMedicoVet;
                    final String finalFetchedClinicaVet = fetchedClinicaVet;

                    handler.post(() -> {
                        if (!isAdded()) { // Verifica se o fragmento ainda está anexado
                            return;
                        }

                        // Opcional: Esconda o indicador de progresso
                        //progressBar.setVisibility(GONE);

                        // Atualiza os campos da UI com os dados recuperados
                        nome_vacina.setText(finalFetchedNomeVacina);
                        dt_vacinacao.setText(finalFetchedDataVacinacao);
                        lote_vacina.setText(finalFetchedLoteVacina);
                        medico_vet.setText(finalFetchedMedicoVet);
                        clinica_vet.setText(finalFetchedClinicaVet);

                        // Define os IDs para uso posterior no fragmento principal
                        idCartaoClicado = clickedCartaoId; // Atualiza a variável do fragmento
                        idPetClicadoVac = clickedPetId;     // Atualiza a variável do fragmento
                        nomeVacinaClicada = clickedVacinaNome; // Atualiza a variável do fragmento

                        // Chamadas de funções de UI
                        funListaPetsClick();
                        funEsconderAllVacinas();
                        funMostrarLayoutVacina();
                        funDesativarCamposVacina();
                    });
                });
            }
        });

        listaVacina.setAdapter(mainAdapter);
        listaCartaoVacina.setAdapter(mainAdapterCartao);
        listaPets.setAdapter(mainAdapterLista);

        filtrarEspecieVac.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (primeiraSelecaoSpinner) {
                    primeiraSelecaoSpinner = false; // Ignora a primeira seleção automática
                    return;
                }

                String especieSelecionada = filtrarEspecieVac.getSelectedItem().toString();

                // Verifica se a seleção realmente mudou para evitar buscas desnecessárias
                if (especieSelecionada.equals(ultimaEspecieSelecionada)) {
                    return;
                }
                ultimaEspecieSelecionada = especieSelecionada;

                // Executa a busca em segundo plano de forma segura e limpa
                executor.execute(() -> {
                    final ArrayList<MainModelVacina> novosModelos = new ArrayList<>();
                    Connection con = null;
                    PreparedStatement stmt = null;
                    ResultSet rs = null;

                    try {
                        con = ConexaoMysql.conectar();
                        String sql = "SELECT id_pet, nome, foto FROM pet WHERE fk_id_tutor = ? AND especie = ?";
                        stmt = con.prepareStatement(sql);
                        stmt.setInt(1, idUsuarioAtual);
                        stmt.setString(2, especieSelecionada);
                        rs = stmt.executeQuery();

                        while (rs.next()) {
                            // Cria o modelo com os parâmetros na ordem correta e passa o byte[] da foto
                            novosModelos.add(new MainModelVacina(
                                    rs.getBytes("foto"),
                                    rs.getString("nome"),
                                    rs.getString("id_pet")
                            ));
                        }

                        handler.post(() -> {
                            if (!isAdded()) return;
                            // A ÚNICA TAREFA DESTE LISTENER: atualizar a lista de pets no topo.
                            updateRecyclerViewVacina(novosModelos);
                            funMostrarAllVacinas();
                        });

                    } catch (Exception e) {
                        Log.e("DB_ERROR", "Erro ao filtrar pets por espécie", e);
                        handler.post(() -> {
                            if (isAdded()) Toast.makeText(getContext(), "Erro ao filtrar pets.", Toast.LENGTH_SHORT).show();
                        });
                    } finally {
                        try {
                            if (rs != null) rs.close();
                            if (stmt != null) stmt.close();
                            if (con != null) con.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Nada a fazer aqui
            }
        });

        btSalvarVacina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = nome_vacina.getText().toString().trim();
                String data = dt_vacinacao.getText().toString().trim();

                if (nome.isEmpty()) {
                    nome_vacina.setError("campo obrigatório");
                    return;
                }

                if (data.isEmpty()) {
                    dt_vacinacao.setError("campo obrigatório");
                    return;
                }

                funAdicionarCartao();

            }
        });

        btAddNovaVacina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funMostrarListaVacina();
                funLimparCamposVacina();
                funAtivarCamposVacina();
            }
        });

        btAlterarVacina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAtivarCamposVacina();
                btAlterarVacina.setVisibility(GONE);
                btSalvarVacina.setVisibility(GONE);
                btAtualizarVacina.setVisibility(VISIBLE);
            }
        });

        btDeletarVacina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setMessage("Confirme para excluir a vacina " +nomeVacinaClicada+".")
                        .setCancelable(false) // Não permite fechar o Dialog clicando fora dele
                        .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Ação ao clicar em "Confirmar"
                                funDeletarCartao();
                            }
                        })
                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Ação ao clicar em "Cancelar"
                            }
                        });

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        btAtualizarVacina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = nome_vacina.getText().toString().trim();
                String data = dt_vacinacao.getText().toString().trim();

                if (nome.isEmpty()) {
                    nome_vacina.setError("campo obrigatório");
                    return;
                }

                if (data.isEmpty()) {
                    dt_vacinacao.setError("campo obrigatório");
                    return;
                }

                funAtualizarCartao();

            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        // Garante que o executor está ativo.
        if (executor == null || executor.isShutdown()) {
            executor = Executors.newSingleThreadExecutor();
        }

        // 1. Mostra o ProgressBar e oculta o conteúdo principal imediatamente.
        if (progressBar != null) {
            progressBar.setVisibility(VISIBLE);
        }
        if (mainContentLayout != null) {
            mainContentLayout.setVisibility(GONE);
        }

        executor.execute(() -> {
            // Bloco para obter o ID do usuário (operação de I/O)
            String emailUsuarioAtual = (FirebaseAuth.getInstance().getCurrentUser() != null)
                    ? FirebaseAuth.getInstance().getCurrentUser().getEmail()
                    : null;

            if (emailUsuarioAtual == null) {
                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    Toast.makeText(getContext(), "Erro: Usuário não autenticado.", Toast.LENGTH_SHORT).show();
                    if (progressBar != null) progressBar.setVisibility(GONE);
                    if (mainContentLayout != null) mainContentLayout.setVisibility(VISIBLE);
                });
                return;
            }

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT id_login FROM login WHERE email = ?;";
                stmt = con.prepareStatement(sql);
                stmt.setString(1, emailUsuarioAtual);
                rs = stmt.executeQuery();

                if (rs.next()) {
                    idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
                }

                handler.post(() -> {
                    if(!isAdded()) return;

                    // Primeiro, busca os pets e espera a resposta via callback
                    funListaPets(petsEncontrados -> {
                        if (petsEncontrados) {
                            funStartLayout(); // Prepara o layout para pets existentes
                            // Chame funListaAllVacinas e passe um callback para ela também
                            // para que saibamos quando ambas as listas (pets e vacinas) terminaram de carregar
                            funListaAllVacinas(() -> { // Assumindo que funListaAllVacinas terá um callback
                                if (!isAdded()) return;
                                funFiltrarEspecie(() -> { // funFiltrarEspecie também terá um callback para indicar fim
                                    if (!isAdded()) return;
                                    // Todas as operações assíncronas de carregamento inicial terminaram.
                                    // Agora, e somente agora, esconda o ProgressBar e mostre o layout principal.
                                    if (progressBar != null) progressBar.setVisibility(GONE);
                                    if (mainContentLayout != null) mainContentLayout.setVisibility(VISIBLE);
                                });
                            });
                        } else {
                            funPetNull(); // Mostra a mensagem de "nenhum pet"
                            // Se não há pets, não há vacinas para carregar, então finalize o loading aqui
                            funFiltrarEspecie(() -> { // Ainda é bom carregar as espécies para o spinner, mesmo sem pets
                                if (!isAdded()) return;
                                if (progressBar != null) progressBar.setVisibility(GONE);
                                if (mainContentLayout != null) mainContentLayout.setVisibility(VISIBLE);
                            });
                        }
                    });
                });

            } catch (Exception e) {
                final String errorMessage = "Erro ao buscar dados do usuário: " + e.getMessage();

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    progressBar.setVisibility(GONE);
                    Toast.makeText(getContext(), errorMessage, Toast.LENGTH_LONG).show();
                });
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        });
    }

    @Override
    public void onStop() {
        super.onStop();
        if (executor != null) {
            executor.shutdown();
            //executor = null; // Força a recriação na próxima vez que onStart for chamado
        }
    }

    public static class DateValidator {

        /**
         * Verifica se a string está no formato dd/MM/yyyy e é uma data válida.
         * @param dateStr A string da data para validar.
         * @return true se a data for válida, false caso contrário.
         */
        public static boolean isValidDate(String dateStr) {
            if (dateStr == null || !dateStr.matches("\\d{2}/\\d{2}/\\d{4}")) {
                return false;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            sdf.setLenient(false); // Não aceita datas inválidas como 32/01/2025

            try {
                Date date = sdf.parse(dateStr);
                int year = Integer.parseInt(dateStr.substring(6));
                if (year < 1900 || year > 2100) {
                    return false;
                }

            } catch (ParseException | NumberFormatException e) {
                // Se a análise falhar, a data é inválida
                return false;
            }

            return true; // Se passou por tudo, a data é válida
        }
    }

    public void funListaPets(OnPetsLoadedCallback callback) {

        executor.execute(() -> {
            final ArrayList<String> tempListaIdPet = new ArrayList<>();
            final ArrayList<String> tempListaNomePet = new ArrayList<>();
            final ArrayList<byte[]> tempListaFotoPet = new ArrayList<>();

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT id_pet, nome, foto FROM pet WHERE fk_id_tutor = ?";
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, idUsuarioAtual);
                rs = stmt.executeQuery();


                // Preencher as listas com dados do banco
                while (rs.next()) {
                    String id = rs.getString("id_pet");
                    String nome = rs.getString("nome");
                    byte[] fotoBytes = rs.getBytes("foto");

                    tempListaIdPet.add(id);
                    tempListaNomePet.add(nome);
                    tempListaFotoPet.add(fotoBytes);
                }

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    // 1. Em vez de limpar as listas do fragment, crie uma nova lista de MainModel
                    ArrayList<MainModelVacina> novosModelos = new ArrayList<>();
                    for (int i = 0; i < tempListaIdPet.size(); i++) {
                        novosModelos.add(new MainModelVacina(tempListaFotoPet.get(i), tempListaNomePet.get(i), tempListaIdPet.get(i)));
                    }

                    // 2. Chame o novo updateRecyclerView com a lista recém-criada
                    updateRecyclerViewVacina(novosModelos);

                    // CHAMA O CALLBACK, informando se a lista de novos modelos está vazia ou não.
                    callback.onComplete(!novosModelos.isEmpty());
                });

            } catch (Exception e) {
                Log.d("DATABASE_ERROR", "Erro ao carregar lista de pets", e);
                // Exibe Toast de erro na UI thread se algo der errado na operação do banco de dados.

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    Toast.makeText(getContext(), "Erro ao carregar lista de pets: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    // CHAMA O CALLBACK, informando que ocorreu um erro (nenhum pet encontrado).
                    callback.onComplete(false);
                });
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

    }

    public void funListaPetsClick() {

        executor.execute(() -> {
            final ArrayList<String> tempListaIdPet = new ArrayList<>();
            final ArrayList<String> tempListaNomePet = new ArrayList<>();
            final ArrayList<byte[]> tempListaFotoPet = new ArrayList<>();

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT id_pet, nome, foto FROM pet WHERE id_pet = ?";
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, idPetClicadoVac);
                rs = stmt.executeQuery();

                // Preencher as listas com dados do banco
                while (rs.next()) {
                    String id = rs.getString("id_pet");
                    String nome = rs.getString("nome");
                    byte[] fotoBytes = rs.getBytes("foto");

                    tempListaIdPet.add(id);
                    tempListaNomePet.add(nome);
                    tempListaFotoPet.add(fotoBytes);
                }

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança

                    if (!isAdded()) return; // Segurança
                    // 1. Em vez de limpar as listas do fragment, crie uma nova lista de MainModel
                    ArrayList<MainModelVacina> novosModelos = new ArrayList<>();
                    for (int i = 0; i < tempListaIdPet.size(); i++) {
                        novosModelos.add(new MainModelVacina(tempListaFotoPet.get(i), tempListaNomePet.get(i), tempListaIdPet.get(i)));
                    }

                    // 2. Chame o novo updateRecyclerView com a lista recém-criada
                    updateRecyclerViewVacina(novosModelos);

                });

            } catch (Exception e) {
                Log.d("DATABASE_ERROR", "Erro ao carregar lista de pets", e);
                // Exibe Toast de erro na UI thread se algo der errado na operação do banco de dados.

                handler.post(() -> {
                    if (!isAdded()) return; // Segurança
                    Toast.makeText(getContext(), "Erro ao carregar lista de pets: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void updateRecyclerViewVacina(List<MainModelVacina> novosDados) {
        // 1. Cria o callback do DiffUtil, comparando a lista antiga com a nova
        CartaoDiffCallback diffCallback = new CartaoDiffCallback(this.mainModels, novosDados);

        // 2. Calcula as diferenças (isso pode ser feito em background se a lista for enorme)
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallback);

        // 3. Atualiza a lista de dados do adapter
        this.mainModels.clear();
        this.mainModels.addAll(novosDados);

        // 4. Envia as atualizações calculadas para o RecyclerView.
        // Ele fará as animações de forma inteligente, sem piscar!
        diffResult.dispatchUpdatesTo(mainAdapter);
    }

    /*
    public void updateRecyclerView() {
        // Atualizar o adapter com os novos dados
        mainModels.clear(); // Limpar a lista antiga
        for (int i = 0; i < listaIdPetVac.size(); i++) {
            MainModelVacina model = new MainModelVacina(listaFotoPetVac.get(i), listaNomePetVac.get(i), listaIdPetVac.get(i));
            mainModels.add(model);
        }

        // Notificar o adapter sobre a mudança nos dados
        mainAdapter.notifyDataSetChanged();
    }
     */

    public void updateRecyclerViewCartao(List<MainModelCartaoVacina> novaLista) {
        if (mainAdapterCartao == null) {
            // Inicializa o adapter se for a primeira vez
            mainAdapterCartao = new MainAdapterCartaoVacina(getContext(), mainModelsCartao, model -> {
                // Lógica de clique no item do cartão
            });
            listaCartaoVacina.setAdapter(mainAdapterCartao);
        }

        // Supondo que você tenha um CartaoVacinaDiffCallback
        CartaoVacinaDiffCallback diffCallback = new CartaoVacinaDiffCallback(this.mainModelsCartao, novaLista);
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallback);

        this.mainModelsCartao.clear();
        this.mainModelsCartao.addAll(novaLista);

        diffResult.dispatchUpdatesTo(mainAdapterCartao);
    }

    public void updateRecyclerViewAllVacina(List<MainModelLista> novaLista) {
        // Garante que o adapter seja criado na primeira vez
        if (mainAdapterLista == null) {
            mainAdapterLista = new MainAdapterLista(getContext(), mainModelsPets, model -> {
                // Lógica de clique no item
            });
            listaPets.setAdapter(mainAdapterLista);
        }

        ListaDiffCallback diffCallback = new ListaDiffCallback(this.mainModelsPets, novaLista);

        // Calcula as diferenças de forma inteligente
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(diffCallback);

        // ATUALIZA A LISTA PRINCIPAL do fragmento. Ela será a fonte de dados para a próxima comparação.
        this.mainModelsPets.clear();
        this.mainModelsPets.addAll(novaLista);

        // Envia as atualizações calculadas para o RecyclerView. Ele fará as animações suaves.
        diffResult.dispatchUpdatesTo(mainAdapterLista);
    }

    /*
    public void updateRecyclerAllVacina() {
        mainModelsPets.clear();

        // Verifica se todas as listas estão preenchidas e do mesmo tamanho
        if (listaIdPetVac1.isEmpty() ||
                listaNomePetVac1.isEmpty() ||
                listaNomeVacinaVac1.isEmpty() ||
                listaDtVacinaVac1.isEmpty()) {

            Toast.makeText(getActivity(), "\"Uma ou mais listas estão vazias\"", Toast.LENGTH_SHORT).show();
            return; // Sai para evitar IndexOutOfBoundsException
        }

        int size = listaIdPetVac1.size();

        // Garante que todas têm o mesmo tamanho
        if (listaNomePetVac1.size() != size ||
                listaNomeVacinaVac1.size() != size ||
                listaDtVacinaVac1.size() != size) {

            Toast.makeText(getActivity(), "\"updateRecyclerAllVacina\", \"Tamanhos das listas são diferentes!\"", Toast.LENGTH_SHORT).show();
            return;
        }

        for (int i = 0; i < size; i++) {
            MainModelLista model = new MainModelLista(
                    listaIdPetVac1.get(i),
                    listaIdCartaoVac1.get(i),
                    listaFotoPetVac1.get(i),
                    listaNomePetVac1.get(i),
                    listaNomeVacinaVac1.get(i),
                    listaDtVacinaVac1.get(i)
            );
            mainModelsPets.add(model);
        }

        if (mainAdapterLista == null) {
            mainAdapterLista = new MainAdapterLista(getContext(), mainModelsPets, new MainAdapterLista.OnItemClickListener() {
                @Override
                public void onItemClick(MainModelLista model) {
                    // clique
                }
            });
            listaPets.setAdapter(mainAdapterLista);
        } else {
            mainAdapterLista.notifyDataSetChanged();
        }
    }
     */

    public void funFiltrarEspecie(OnLoadCompleteCallback callback) {
        // Show a loading indicator if you have one, e.g.,
        //progressBar.setVisibility(VISIBLE);

        executor.execute(() -> {
            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;
            // Criar uma lista de String para o Spinner no background
            List<String> filtrarEspecieList = new ArrayList<>();

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT DISTINCT especie FROM pet WHERE fk_id_tutor = ? ORDER BY especie ASC";
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, idUsuarioAtual);
                rs = stmt.executeQuery();

                while (rs.next()) {
                    String especie = rs.getString("especie");
                    if (especie != null) { // Basic null check for the retrieved data
                        filtrarEspecieList.add(especie);
                    }
                }

            } catch (Exception e) {
                Log.e("DB_ERROR", "Erro ao filtrar espécies: " + e.getMessage(), e);
                // Post an error message to the UI thread
                handler.post(() -> {
                    if (isAdded()) {
                        Toast.makeText(getContext(), "Erro ao carregar opções de filtro de espécie.", Toast.LENGTH_LONG).show();
                        if (callback != null) { // Chame o callback mesmo em caso de erro
                            callback.onComplete();
                        }
                    }
                });
            } finally {
                // Ensure resources are closed
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace(); // Log cleanup errors
                }
            }

            // Post the UI update back to the main thread
            handler.post(() -> {
                if (!isAdded()) { // Check if fragment is still attached
                    return;
                }

                // Hide loading indicator if you showed one, e.g.,
                //progressBar.setVisibility(GONE);

                // Criar o ArrayAdapter e associar ao Spinner na thread da UI
                ArrayAdapter<String> adapter2 = new ArrayAdapter<>(requireActivity(), R.layout.spinner_text_color, filtrarEspecieList);
                adapter2.setDropDownViewResource(R.layout.spinner_text_color);
                filtrarEspecieVac.setAdapter(adapter2);
                if (callback != null) { // Chame o callback quando a UI for atualizada
                    callback.onComplete();
                }
            });
        });
    }

    public void funAdicionarCartao() {
        // 1. Captura e limpeza dos campos
        String nome = nome_vacina.getText().toString().trim();
        String dataStr = dt_vacinacao.getText().toString().trim();
        String lote = lote_vacina.getText().toString().trim(); // Capture lote
        String medico = medico_vet.getText().toString().trim(); // Capture medico
        String clinica = clinica_vet.getText().toString().trim(); // Capture clinica

        // 2. Validações de obrigatoriedade (mantidas na UI thread)
        if (nome.isEmpty()) {
            nome_vacina.setError("Campo obrigatório");
            return;
        }
        if (dataStr.isEmpty()) {
            dt_vacinacao.setError("Campo obrigatório");
            return;
        }

        // 3. Validação de formato/consistência da data (mantida na UI thread)
        if (!DateValidator.isValidDate(dataStr)) {
            dt_vacinacao.setError("Data inválida");
            return;
        }

        // 4. Conversão segura String para java.sql.Date (mantida na UI thread antes de passar para o background)
        java.sql.Date dataSql;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault());
            dataSql = new java.sql.Date(sdf.parse(dataStr).getTime());
        } catch (ParseException e) {
            dt_vacinacao.setError("Data inválida");
            if (isAdded()) {
                Toast.makeText(getContext(), "Erro ao converter a data.", Toast.LENGTH_SHORT).show();
            }
            return;
        }

        // Capture idPetClicadoVac as final for use in the lambda
        final Integer fkPetId = idPetClicadoVac;
        final java.sql.Date finalDataSql = dataSql; // Make it final for the lambda

        // Opcional: Mostre um indicador de progresso
        // progressBar.setVisibility(VISIBLE);

        // 5. Inserir no banco (executado no background)
        executor.execute(() -> {
            Connection con = null;
            PreparedStatement stmt = null;
            boolean success = false;

            try {
                con = ConexaoMysql.conectar();
                String sql = "INSERT INTO cartao_vacinacao (nome_vacina, dt_vacinacao, lote_vacina, medico_vet, clinica_vet, fk_id_pet)" +
                        "VALUES (?, ?, ?, ?, ?, ?)";
                stmt = con.prepareStatement(sql);

                stmt.setString(1, nome);      // Use the captured 'nome'
                stmt.setDate(2, finalDataSql); // Use the captured 'finalDataSql'
                stmt.setString(3, lote);      // Use the captured 'lote'
                stmt.setString(4, medico);    // Use the captured 'medico'
                stmt.setString(5, clinica);   // Use the captured 'clinica'
                stmt.setInt(6, fkPetId);
                stmt.executeUpdate();
                success = true; // Set success flag

            } catch (Exception e) {
                Log.e("DB_ERROR", "Erro ao adicionar vacina: " + e.getMessage(), e);
                // Post an error message to the UI thread
                handler.post(() -> {
                    if (isAdded()) {
                        Toast.makeText(getContext(), "Erro ao adicionar a vacina.", Toast.LENGTH_LONG).show();
                    }
                });
            } finally {
                // Garante que os recursos do banco de dados sejam fechados
                try {
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace(); // Log cleanup errors
                }
            }

            // 6. UI pós-atualização (executado no main thread)
            final boolean finalSuccess = success;
            handler.post(() -> {
                if (!isAdded()) { // Check if fragment is still attached
                    return;
                }

                // Opcional: Esconda o indicador de progresso
                // progressBar.setVisibility(GONE);

                if (finalSuccess) {
                    funListaCartao(vacinasEncontradas -> {
                        if (isAdded()) { // Check again inside callback
                            funLimparCamposVacina();
                            funEsconderListaVacina();
                            Toast.makeText(getContext(), "Vacina adicionada com sucesso!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            });
        });
    }

    public void funAtualizarCartao() {
        // 1. Captura e limpeza dos campos
        String nome = nome_vacina.getText().toString().trim();
        String dataStr = dt_vacinacao.getText().toString().trim();
        String lote = lote_vacina.getText().toString().trim();
        String medico = medico_vet.getText().toString().trim();
        String clinica = clinica_vet.getText().toString().trim();

        // 2. Validações de obrigatoriedade (mantidas na UI thread)
        if (nome.isEmpty()) {
            nome_vacina.setError("Campo obrigatório");
            return;
        }
        if (dataStr.isEmpty()) {
            dt_vacinacao.setError("Campo obrigatório");
            return;
        }

        // 3. Validação de formato/consistência da data (mantida na UI thread)
        if (!DateValidator.isValidDate(dataStr)) {
            dt_vacinacao.setError("Data inválida");
            return;
        }

        // 4. Conversão segura String para java.sql.Date (mantida na UI thread antes de passar para o background)
        java.sql.Date dataSql;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault());
            dataSql = new java.sql.Date(sdf.parse(dataStr).getTime());
        } catch (ParseException e) {
            dt_vacinacao.setError("Data inválida");
            if (isAdded()) { // Always check if fragment is added before showing Toast
                Toast.makeText(getContext(), "Erro ao converter a data.", Toast.LENGTH_SHORT).show();
            }
            return;
        }

        // Captura as variáveis finais para uso na lambda do executor
        final String finalNome = nome;
        final java.sql.Date finalDataSql = dataSql;
        final String finalLote = lote;
        final String finalMedico = medico;
        final String finalClinica = clinica;
        final Integer finalIdCartaoClicado = idCartaoClicado; // Captura idCartaoClicado

        // Opcional: Mostre um indicador de progresso (ex: progressBar.setVisibility(VISIBLE);)

        // 5. Atualiza no banco (executado no background)
        executor.execute(() -> {
            Connection con = null;
            PreparedStatement stmt = null;
            boolean success = false; // Flag para indicar sucesso da operação

            try {
                con = ConexaoMysql.conectar();
                String sql = "UPDATE cartao_vacinacao SET nome_vacina = ?, dt_vacinacao = ?, " +
                        "lote_vacina = ?, medico_vet = ?, clinica_vet = ? WHERE id_cartao_vacinacao = ?";
                stmt = con.prepareStatement(sql);

                stmt.setString(1, finalNome);
                stmt.setDate(2, finalDataSql);
                stmt.setString(3, finalLote);
                stmt.setString(4, finalMedico);
                stmt.setString(5, finalClinica);
                stmt.setInt(6, finalIdCartaoClicado);

                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    success = true; // Define sucesso se alguma linha foi afetada
                }

            } catch (Exception e) {
                Log.e("DB_ERROR", "Erro ao atualizar vacina: " + e.getMessage(), e);
                // Posta uma mensagem de erro para o tópico da UI
                handler.post(() -> {
                    if (isAdded()) {
                        Toast.makeText(getContext(), "Erro ao atualizar a vacina.", Toast.LENGTH_LONG).show();
                    }
                });
            } finally {
                // Garante que os recursos do banco de dados sejam fechados
                try {
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace(); // Log de erros de limpeza
                }
            }

            // 6. UI pós-atualização (executado no main thread)
            final boolean finalSuccess = success;
            handler.post(() -> {
                if (!isAdded()) { // Verifica se o fragmento ainda está anexado
                    return;
                }

                // Opcional: Esconda o indicador de progresso (ex: progressBar.setVisibility(GONE);)

                if (finalSuccess) {
                    funListaCartao(vacinasEncontradas -> {
                        if (isAdded()) { // Verifica novamente dentro do callback
                            funLimparCamposVacina();
                            funEsconderListaVacina();
                            Toast.makeText(getContext(), "Vacina atualizada com sucesso!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            });
        });
    }

    public void funDeletarCartao() {
        executor.execute(() -> {
            Connection con = null;
            PreparedStatement stmt = null;
            try {
                // 1. Deleta a vacina em segundo plano
                con = ConexaoMysql.conectar();
                String sql = "DELETE FROM cartao_vacinacao WHERE id_cartao_vacinacao = ?";
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, idCartaoClicado);
                stmt.executeUpdate();

                // 2. Após deletar, volta para a thread de UI para atualizar a lista
                handler.post(() -> {
                    if (!isAdded()) return;

                    // 3. Chama a função para recarregar a lista. A lógica da UI fica DENTRO do callback.
                    funListaCartao(vacinasEncontradas -> {
                        if (!isAdded()) return;

                        funLimparCamposVacina();

                        if (vacinasEncontradas) {
                            // Se ainda há vacinas, apenas esconde o formulário e mostra a lista atualizada
                            funEsconderListaVacina();
                        } else {
                            // Se não há mais vacinas, volta para o layout inicial
                            funStartLayout();
                        }
                    });
                });

            } catch (Exception e) {
                Log.e("DB_ERROR", "Erro ao deletar vacina", e);
                handler.post(() -> {
                    if(isAdded()) Toast.makeText(getContext(), "Erro ao excluir vacina.", Toast.LENGTH_SHORT).show();
                });
            } finally {
                try {
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void funListaCartao(OnCartaoLoadedCallback callback) {

        executor.execute(() -> {
            final ArrayList<MainModelCartaoVacina> novosModelos = new ArrayList<>();
            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT * FROM view_cartao_vacinacao WHERE fk_id_pet = ? ORDER BY dt_vacinacao DESC";
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, idPetClicadoVac);
                rs = stmt.executeQuery();

                while (rs.next()) {
                    Date dataUtil = rs.getDate("dt_vacinacao");
                    String dataFormatada = new SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(dataUtil);

                    novosModelos.add(new MainModelCartaoVacina(
                            rs.getString("id_cartao_vacinacao"),
                            rs.getString("nome_vacina"),
                            dataFormatada
                    ));
                }

                handler.post(() -> {
                    if (!isAdded()) return;
                    updateRecyclerViewCartao(novosModelos); // Chama a função de update com DiffUtil
                    callback.onComplete(!novosModelos.isEmpty()); // Avisa que terminou
                });

            } catch (Exception e) {
                Log.e("DB_ERROR", "Erro ao carregar cartão de vacinas", e);
                handler.post(() -> {
                    if (isAdded()) {
                        Toast.makeText(getContext(), "Erro ao carregar cartão.", Toast.LENGTH_SHORT).show();
                        callback.onComplete(false); // Avisa que deu erro
                    }
                });
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void funListaAllVacinas(OnLoadCompleteCallback callback) {

        executor.execute(() -> {
            // Crie UMA ÚNICA lista temporária para os modelos.
            final ArrayList<MainModelLista> novosModelos = new ArrayList<>();

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT * FROM view_cartao_vacinacao WHERE fk_id_tutor = ? ORDER BY dt_vacinacao DESC";
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, idUsuarioAtual);
                rs = stmt.executeQuery();

                while (rs.next()) {
                    // Formata a data
                    Date dataUtil = rs.getDate("dt_vacinacao");
                    String dataFormatada = "";
                    if (dataUtil != null) {
                        dataFormatada = new SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(dataUtil);
                    }

                    // Crie o modelo e adicione diretamente à nova lista
                    novosModelos.add(new MainModelLista(
                            rs.getInt("fk_id_pet"),
                            rs.getInt("id_cartao_vacinacao"),
                            rs.getBytes("foto"),
                            rs.getString("nome_pet"),
                            rs.getString("nome_vacina"),
                            dataFormatada // Usa a data já formatada
                    ));
                }

                // Ao final, poste a lista completa para a UI
                handler.post(() -> {
                    if(!isAdded()) return;

                    // Chama a função de update com a lista de novos modelos
                    updateRecyclerViewAllVacina(novosModelos);

                    if (callback != null) { // Chame o callback quando a UI for atualizada
                        callback.onComplete();
                    }
                });

            } catch (Exception e) {
                Log.e("DB_ERROR", "Erro ao buscar vacinas", e);
                handler.post(() -> {
                    if(isAdded()) Toast.makeText(getContext(), "Erro ao carregar vacinas.", Toast.LENGTH_SHORT).show();
                    if (callback != null) { // Chame o callback mesmo em caso de erro
                        callback.onComplete();
                    }
                });
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void funListaCartaoProximas() {

        executor.execute(() -> {
            // Crie uma única lista temporária para os modelos.
            final ArrayList<MainModelCartaoVacina> novosModelos = new ArrayList<>();

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT * FROM view_cartao_vacinacao WHERE fk_id_pet = ? AND dt_vacinacao >= CURRENT_DATE " +
                        "ORDER BY dt_vacinacao ASC"; // ASC para ver as mais próximas primeiro
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, idPetClicadoVac);
                rs = stmt.executeQuery();

                while (rs.next()) {
                    Date dataUtil = rs.getDate("dt_vacinacao");
                    String dataFormatada = new SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(dataUtil);

                    // Crie o modelo e adicione diretamente à nova lista.
                    novosModelos.add(new MainModelCartaoVacina(
                            rs.getString("id_cartao_vacinacao"),
                            rs.getString("nome_vacina"),
                            dataFormatada
                    ));
                }

                // Após a busca, envie a lista para a thread de UI para atualização.
                handler.post(() -> {
                    if (!isAdded()) return;

                    // Chame a função de atualização que já usa DiffUtil.
                    updateRecyclerViewCartao(novosModelos);

                });

            } catch (Exception e) {
                Log.e("DB_ERROR", "Erro ao carregar próximas vacinas.", e);
                handler.post(() -> {
                    if(isAdded()) Toast.makeText(getContext(), "Erro ao carregar próximas vacinas.", Toast.LENGTH_SHORT).show();
                });
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void funListaCartaoProximasAll() {
        executor.execute(() -> {

            // UMA ÚNICA lista temporária para os seus modelos.
            final ArrayList<MainModelLista> novosModelos = new ArrayList<>();

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT * FROM view_cartao_vacinacao WHERE fk_id_tutor = ? AND dt_vacinacao >= CURRENT_DATE " +
                        "ORDER BY dt_vacinacao ASC"; // ASC para ver as mais próximas primeiro
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, idUsuarioAtual);
                rs = stmt.executeQuery();

                while (rs.next()) {
                    // Formata a data corretamente aqui
                    Date dataUtil = rs.getDate("dt_vacinacao");
                    String dataFormatada = "";
                    if (dataUtil != null) {
                        dataFormatada = new SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(dataUtil);
                    }

                    novosModelos.add(new MainModelLista(
                            rs.getInt("fk_id_pet"),
                            rs.getInt("id_cartao_vacinacao"),
                            rs.getBytes("foto"), // Passe o array de bytes diretamente
                            rs.getString("nome_pet"),
                            rs.getString("nome_vacina"),
                            dataFormatada
                    ));
                }

                handler.post(() -> {
                    if (!isAdded()) return;

                    updateRecyclerViewAllVacina(novosModelos);
                });

            } catch (Exception e) {
                Log.e("DB_ERROR", "Erro ao buscar próximas vacinas", e);
                handler.post(() -> {
                    if(isAdded()) Toast.makeText(getContext(), "Erro ao carregar próximas vacinas.", Toast.LENGTH_SHORT).show();
                });
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void funListaCartaoAplicadas() {

        executor.execute(() -> {
            // 1. Crie uma única lista temporária para os modelos.
            final ArrayList<MainModelCartaoVacina> novosModelos = new ArrayList<>();

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT * FROM view_cartao_vacinacao WHERE fk_id_pet = ? AND dt_vacinacao < CURRENT_DATE " +
                        "ORDER BY dt_vacinacao DESC";
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, idPetClicadoVac);
                rs = stmt.executeQuery();

                while (rs.next()) {
                    Date dataUtil = rs.getDate("dt_vacinacao");
                    String dataFormatada = new SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(dataUtil);

                    // 2. Crie o modelo e adicione diretamente à nova lista.
                    novosModelos.add(new MainModelCartaoVacina(
                            rs.getString("id_cartao_vacinacao"),
                            rs.getString("nome_vacina"),
                            dataFormatada
                    ));
                }

                // 3. Após a busca, envie a lista para a thread de UI para atualização.
                handler.post(() -> {
                    if (!isAdded()) return;

                    // Chame a função de atualização que já usa DiffUtil.
                    updateRecyclerViewCartao(novosModelos);

                });

            } catch (Exception e) {
                Log.e("DB_ERROR", "Erro ao carregar vacinas aplicadas.", e);
                handler.post(() -> {
                    if(isAdded()) Toast.makeText(getContext(), "Erro ao carregar vacinas aplicadas.", Toast.LENGTH_SHORT).show();
                });
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void funListaCartaoAplicadasAll() {
        executor.execute(() -> {

            final ArrayList<MainModelLista> novosModelos = new ArrayList<>();

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT * FROM view_cartao_vacinacao WHERE fk_id_tutor = ? AND dt_vacinacao < CURRENT_DATE " +
                        "ORDER BY dt_vacinacao DESC";
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, idUsuarioAtual);
                rs = stmt.executeQuery();

                while (rs.next()) {
                    // Formata a data
                    Date dataUtil = rs.getDate("dt_vacinacao");
                    String dataFormatada = "";
                    if (dataUtil != null) {
                        dataFormatada = new SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(dataUtil);
                    }

                    novosModelos.add(new MainModelLista(
                            rs.getInt("fk_id_pet"),
                            rs.getInt("id_cartao_vacinacao"),
                            rs.getBytes("foto"), // Passe o byte[] bruto
                            rs.getString("nome_pet"),
                            rs.getString("nome_vacina"),
                            dataFormatada
                    ));
                }

                handler.post(() -> {
                    if (!isAdded()) return;

                    // Chame a função de atualização que usa DiffUtil.
                    updateRecyclerViewAllVacina(novosModelos);

                });

            } catch (Exception e) {
                Log.e("DB_ERROR", "Erro ao buscar vacinas aplicadas", e);
                handler.post(() -> {
                    if(isAdded()) Toast.makeText(getContext(), "Erro ao carregar vacinas aplicadas.", Toast.LENGTH_SHORT).show();
                });
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void funAtivarCamposVacina() {
        nome_vacina.setEnabled(true);
        lote_vacina.setEnabled(true);
        dt_vacinacao.setEnabled(true);
        medico_vet.setEnabled(true);
        clinica_vet.setEnabled(true);
    }

    public void funDesativarCamposVacina() {
        nome_vacina.setEnabled(false);
        lote_vacina.setEnabled(false);
        dt_vacinacao.setEnabled(false);
        medico_vet.setEnabled(false);
        clinica_vet.setEnabled(false);

        nome_vacina.setError(null);
        dt_vacinacao.setError(null);
    }

    public void funEsconderListaVacina() {
        tvVacina.setVisibility(GONE);
        tvNovaVacina.setVisibility(GONE);
        nome_vacina.setVisibility(GONE);
        lote_vacina.setVisibility(GONE);
        dt_vacinacao.setVisibility(GONE);
        medico_vet.setVisibility(GONE);
        clinica_vet.setVisibility(GONE);
        btSalvarVacina.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        tvNomeVacina.setVisibility(GONE);
        tvLoteVacina.setVisibility(GONE);
        tvDataVacina.setVisibility(GONE);
        tvMedicoVet.setVisibility(GONE);
        tvClinicaVet.setVisibility(GONE);
        spinnerFiltrarAllVacinas.setVisibility(GONE);
        spinnerFiltrarVacinasClick.setVisibility(VISIBLE);
        btVoltarListaPet.setVisibility(VISIBLE);
        tvVacinas.setVisibility(VISIBLE);
        btAddNovaVacina.setVisibility(VISIBLE);
        listaCartaoVacina.setVisibility(VISIBLE);
    }

    public void funMostrarListaVacina() {
        spinnerFiltrarVacinasClick.setVisibility(GONE);
        btAddNovaVacina.setVisibility(GONE);
        listaCartaoVacina.setVisibility(GONE);
        tvVacinas.setVisibility(GONE);
        tvVacina.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        spinnerFiltrarAllVacinas.setVisibility(GONE);
        tvNovaVacina.setVisibility(VISIBLE);
        nome_vacina.setVisibility(VISIBLE);
        lote_vacina.setVisibility(VISIBLE);
        dt_vacinacao.setVisibility(VISIBLE);
        medico_vet.setVisibility(VISIBLE);
        clinica_vet.setVisibility(VISIBLE);
        btSalvarVacina.setVisibility(VISIBLE);
        tvNomeVacina.setVisibility(VISIBLE);
        tvLoteVacina.setVisibility(VISIBLE);
        tvDataVacina.setVisibility(VISIBLE);
        tvMedicoVet.setVisibility(VISIBLE);
        tvClinicaVet.setVisibility(VISIBLE);

        tvFiltrarEspecieVac.setVisibility(VISIBLE);
        btVoltarListaPet.setVisibility(VISIBLE);
        filtrarEspecieVac.setVisibility(VISIBLE);
        listaVacina.setVisibility(VISIBLE);
    }

    public void funLimparCamposVacina() {
        nome_vacina.setText(null);
        lote_vacina.setText(null);
        dt_vacinacao.setText(null);
        medico_vet.setText(null);
        clinica_vet.setText(null);
        nome_vacina.setError(null);
        dt_vacinacao.setError(null);
    }

    public void funPetNull() {
        btAddNovaVacina.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        tvVacina.setVisibility(GONE);
        tvNovaVacina.setVisibility(GONE);
        tvVacinas.setVisibility(GONE);
        nome_vacina.setVisibility(GONE);
        dt_vacinacao.setVisibility(GONE);
        lote_vacina.setVisibility(GONE);
        medico_vet.setVisibility(GONE);
        clinica_vet.setVisibility(GONE);
        btSalvarVacina.setVisibility(GONE);
        tvNomeVacina.setVisibility(GONE);
        tvLoteVacina.setVisibility(GONE);
        tvDataVacina.setVisibility(GONE);
        tvMedicoVet.setVisibility(GONE);
        tvClinicaVet.setVisibility(GONE);
        spinnerFiltrarVacinasClick.setVisibility(GONE);
        spinnerFiltrarAllVacinas.setVisibility(GONE);
        btVoltarListaPet.setVisibility(GONE);

        // Oculta o RecyclerView de pets e cartões de vacina
        listaVacina.setVisibility(GONE);
        listaCartaoVacina.setVisibility(GONE);

        // Oculta spinner
        if (filtrarEspecieVac != null) {
            filtrarEspecieVac.setVisibility(GONE);
        }
        tvFiltrarEspecieVac.setVisibility(GONE);

        // Mostra uma mensagem informando que o usuário não tem pets cadastrados
        tvPetNull.setVisibility(VISIBLE);
        tvPetNull.setText("Você ainda não cadastrou nenhum PET.");
    }

    public void funVacinaNull() {
        spinnerFiltrarVacinasClick.setVisibility(GONE);
        tvVacina.setVisibility(GONE);
        tvPetNull.setVisibility(GONE);
        btAddNovaVacina.setVisibility(GONE);
        listaCartaoVacina.setVisibility(GONE);
        listaPets.setVisibility(GONE);
        tvVacinas.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        spinnerFiltrarAllVacinas.setVisibility(GONE);
        tvNovaVacina.setVisibility(VISIBLE);
        nome_vacina.setVisibility(VISIBLE);
        dt_vacinacao.setVisibility(VISIBLE);
        lote_vacina.setVisibility(VISIBLE);
        medico_vet.setVisibility(VISIBLE);
        clinica_vet.setVisibility(VISIBLE);
        btSalvarVacina.setVisibility(VISIBLE);
        tvNomeVacina.setVisibility(VISIBLE);
        tvLoteVacina.setVisibility(VISIBLE);
        tvDataVacina.setVisibility(VISIBLE);
        tvMedicoVet.setVisibility(VISIBLE);
        tvClinicaVet.setVisibility(VISIBLE);
        btVoltarListaPet.setVisibility(VISIBLE);
    }

    public void funStartLayout() {
        spinnerFiltrarVacinasClick.setVisibility(GONE);
        tvVacina.setVisibility(GONE);
        nome_vacina.setVisibility(GONE);
        lote_vacina.setVisibility(GONE);
        dt_vacinacao.setVisibility(GONE);
        medico_vet.setVisibility(GONE);
        clinica_vet.setVisibility(GONE);
        btSalvarVacina.setVisibility(GONE);
        btAddNovaVacina.setVisibility(GONE);
        listaCartaoVacina.setVisibility(GONE);
        tvNovaVacina.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        tvNomeVacina.setVisibility(GONE);
        tvLoteVacina.setVisibility(GONE);
        tvDataVacina.setVisibility(GONE);
        tvMedicoVet.setVisibility(GONE);
        tvClinicaVet.setVisibility(GONE);
        btVoltarListaPet.setVisibility(VISIBLE);
    }

    public void funMostrarVacinas() {
        tvVacina.setVisibility(GONE);
        tvNovaVacina.setVisibility(GONE);
        nome_vacina.setVisibility(GONE);
        lote_vacina.setVisibility(GONE);
        dt_vacinacao.setVisibility(GONE);
        medico_vet.setVisibility(GONE);
        clinica_vet.setVisibility(GONE);
        btSalvarVacina.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        tvNomeVacina.setVisibility(GONE);
        tvLoteVacina.setVisibility(GONE);
        tvDataVacina.setVisibility(GONE);
        tvMedicoVet.setVisibility(GONE);
        tvClinicaVet.setVisibility(GONE);
        spinnerFiltrarAllVacinas.setVisibility(GONE);
        spinnerFiltrarVacinasClick.setVisibility(VISIBLE);
        spinnerFiltrarVacinasClick.setSelection(0);
        tvVacinas.setVisibility(VISIBLE);
        btAddNovaVacina.setVisibility(VISIBLE);
        listaCartaoVacina.setVisibility(VISIBLE);
        btVoltarListaPet.setVisibility(VISIBLE);
    }

    public void funMostrarLayoutVacina() {
        btSalvarVacina.setVisibility(GONE);
        tvPetNull.setVisibility(GONE);
        btAddNovaVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        listaCartaoVacina.setVisibility(GONE);
        tvVacinas.setVisibility(GONE);
        tvNovaVacina.setVisibility(GONE);
        spinnerFiltrarVacinasClick.setVisibility(GONE);
        spinnerFiltrarAllVacinas.setVisibility(GONE);
        tvVacina.setVisibility(VISIBLE);
        nome_vacina.setVisibility(VISIBLE);
        dt_vacinacao.setVisibility(VISIBLE);
        lote_vacina.setVisibility(VISIBLE);
        medico_vet.setVisibility(VISIBLE);
        clinica_vet.setVisibility(VISIBLE);
        tvNomeVacina.setVisibility(VISIBLE);
        tvLoteVacina.setVisibility(VISIBLE);
        tvDataVacina.setVisibility(VISIBLE);
        tvMedicoVet.setVisibility(VISIBLE);
        tvClinicaVet.setVisibility(VISIBLE);
        btAlterarVacina.setVisibility(VISIBLE);
        btDeletarVacina.setVisibility(VISIBLE);
        btVoltarListaPet.setVisibility(VISIBLE);
    }

    public void funMostrarAllVacinas() {
        spinnerFiltrarVacinasClick.setVisibility(GONE);
        tvVacina.setVisibility(GONE);
        nome_vacina.setVisibility(GONE);
        lote_vacina.setVisibility(GONE);
        dt_vacinacao.setVisibility(GONE);
        medico_vet.setVisibility(GONE);
        clinica_vet.setVisibility(GONE);
        btSalvarVacina.setVisibility(GONE);
        btAddNovaVacina.setVisibility(GONE);
        listaCartaoVacina.setVisibility(GONE);
        tvNovaVacina.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        tvNomeVacina.setVisibility(GONE);
        tvLoteVacina.setVisibility(GONE);
        tvDataVacina.setVisibility(GONE);
        tvMedicoVet.setVisibility(GONE);
        tvClinicaVet.setVisibility(GONE);
        listaPets.setVisibility(VISIBLE);
        tvVacinas.setVisibility(VISIBLE);
        btVoltarListaPet.setVisibility(VISIBLE);
        spinnerFiltrarAllVacinas.setVisibility(VISIBLE);
        spinnerFiltrarAllVacinas.setSelection(0);
        funListaAllVacinas(() -> {
            // Same as above, add specific post-load UI logic if needed
        });
    }

    public void funEsconderAllVacinasNull() {
        spinnerFiltrarVacinasClick.setVisibility(GONE);
        tvVacina.setVisibility(GONE);
        nome_vacina.setVisibility(GONE);
        lote_vacina.setVisibility(GONE);
        dt_vacinacao.setVisibility(GONE);
        medico_vet.setVisibility(GONE);
        clinica_vet.setVisibility(GONE);
        btSalvarVacina.setVisibility(GONE);
        btAddNovaVacina.setVisibility(GONE);
        listaCartaoVacina.setVisibility(GONE);
        tvNovaVacina.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        tvNomeVacina.setVisibility(GONE);
        tvLoteVacina.setVisibility(GONE);
        tvDataVacina.setVisibility(GONE);
        tvMedicoVet.setVisibility(GONE);
        tvClinicaVet.setVisibility(GONE);
        listaPets.setVisibility(GONE);
        tvVacinas.setVisibility(GONE);
        spinnerFiltrarAllVacinas.setVisibility(GONE);
        spinnerFiltrarAllVacinas.setSelection(0);
    }

    public void funEsconderAllVacinas() {
        listaPets.setVisibility(GONE);
        tvVacinas.setVisibility(GONE);
        spinnerFiltrarAllVacinas.setVisibility(GONE);
        btVoltarListaPet.setVisibility(GONE);
    }

    interface OnPetsLoadedCallback {
        void onComplete(boolean petsEncontrados);
    }

    interface OnCartaoLoadedCallback {
        void onComplete(boolean vacinasEncontradas);
    }

    interface OnLoadCompleteCallback {
        void onComplete();
    }

}