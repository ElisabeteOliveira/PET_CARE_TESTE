package com.example.petcareapp.ui.cartaoVacina;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.petcareapp.R;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainAdapterLista extends RecyclerView.Adapter<MainAdapterLista.ViewHolder> {

    private ArrayList<MainModelLista> mainModels;
    private Context context;
    private OnItemClickListener listener;

    // Interface para clique no item
    public interface OnItemClickListener {
        void onItemClick(MainModelLista model);
    }

    // Construtor com listener
    public MainAdapterLista(Context context, ArrayList<MainModelLista> mainModels, OnItemClickListener listener) {
        this.context = context;
        this.mainModels = mainModels;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_item_lista, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        MainModelLista item = mainModels.get(position);

        holder.listaIdPetVac1.setText(String.valueOf(item.getListaIdPetVac1()));
        holder.listaIdCartaoVac1.setText(String.valueOf(item.getListaIdCartaoVac1()));

        // Load image using Glide
        if (item.getListaFotoPetVac1() != null && item.getListaFotoPetVac1().length > 0) {
            Glide.with(holder.itemView.getContext())
                    .asBitmap() // Specify that you expect a Bitmap
                    .load(item.getListaFotoPetVac1()) // Load the byte array
                    .circleCrop() // Apply circular cropping
                    .diskCacheStrategy(DiskCacheStrategy.ALL) // Cache the image
                    .error(R.drawable.patas) // Optional: error image
                    .into(holder.listaFotoPetVac1); // Your ImageView
        } else {
            // If no image, set a default or hide the ImageView
            holder.listaFotoPetVac1.setImageResource(R.drawable.patas); // Or set to null/GONE
        }

        holder.listaNomePetVac1.setText(item.getListaNomePetVac1());
        holder.listaNomeVacinaVac1.setText(item.getListaNomeVacinaVac1());
        holder.listaDtVacinaVac1.setText(item.getListaDtVacinaVac1());

        holder.listaNomePetVac1.setMaxLines(1);
        holder.listaNomePetVac1.setEllipsize(TextUtils.TruncateAt.END);

        holder.listaNomeVacinaVac1.setMaxLines(1);
        holder.listaNomeVacinaVac1.setEllipsize(TextUtils.TruncateAt.END);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(item);
            } else {
                Log.e("MainAdapterLista", "Listener is null!");
            }
        });

        // Limitar o texto do nome PET para 15 caracteres
        String nomePet = mainModels.get(position).getListaNomePetVac1();
        int maxLength = 15;  // Limite de caracteres
        if (nomePet.length() > maxLength) {
            nomePet = nomePet.substring(0, maxLength) + "...";  // Adiciona "..." se ultrapassar o limite
        }
        holder.listaNomePetVac1.setText(nomePet);

        // Limitar o texto do nome vacina para 15 caracteres
        String nomeVacina = mainModels.get(position).getListaNomeVacinaVac1();
        int maxLength1 = 15;  // Limite de caracteres
        if (nomeVacina.length() > maxLength1) {
            nomeVacina = nomeVacina.substring(0, maxLength) + "...";  // Adiciona "..." se ultrapassar o limite
        }
        holder.listaNomeVacinaVac1.setText(nomeVacina);
    }

    @Override
    public int getItemCount() {
        return mainModels != null ? mainModels.size() : 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView listaFotoPetVac1;
        TextView listaIdPetVac1, listaIdCartaoVac1, listaNomePetVac1, listaNomeVacinaVac1, listaDtVacinaVac1;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            listaIdPetVac1 = itemView.findViewById(R.id.listaIdPetVac1);
            listaIdCartaoVac1 = itemView.findViewById(R.id.listaIdCartaoVac1);
            listaFotoPetVac1 = itemView.findViewById(R.id.listaFotoPetVac1);
            listaNomePetVac1 = itemView.findViewById(R.id.listaNomePetVac1);
            listaNomeVacinaVac1 = itemView.findViewById(R.id.listaNomeVacinaVac1);
            listaDtVacinaVac1 = itemView.findViewById(R.id.listaDtVacinaVac1);
        }
    }
}
