package com.example.petcareapp.ui.perfilAdm;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CircleCrop;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.google.firebase.auth.FirebaseAuth;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link perfilAdmFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class perfilAdmFragment extends Fragment {

    private ExecutorService executor;
    private final Handler handler = new Handler(Looper.getMainLooper());

    byte[] fotoAtual = null;

    String emailUsuarioAtual, idAdm;
    Integer idUsuarioAtual;

    private boolean dadosForamCarregados = false;

    EditText etNomeAdm;
    Button btSalvarAdm, btnSelecionarFoto;
    ImageView imagemAdm;

    ProgressBar progressBarAdm;
    ConstraintLayout mainContentLayoutAdm;


    Bitmap imgOriginalBitmap;
    Bitmap selectedBitmap = null;
    boolean imageChanged = false; // Flag para indicar se a imagem foi alterada

    // Definindo o ActivityResultLauncher para capturar o resultado da seleção de foto
    private ActivityResultLauncher<Intent> selectPhotoLauncher;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public perfilAdmFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment perfilAdmFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static perfilAdmFragment newInstance(String param1, String param2) {
        perfilAdmFragment fragment = new perfilAdmFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }


        // Inicializando o ActivityResultLauncher para a seleção de foto
        selectPhotoLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == getActivity().RESULT_OK && result.getData() != null) {
                        Uri imageUri = result.getData().getData();
                        if (imageUri != null) {
                            // Use CustomTarget para obter o Bitmap e atualizar a UI
                            Glide.with(perfilAdmFragment.this)
                                    .asBitmap()
                                    .load(imageUri)
                                    .circleCrop()
                                    .into(new CustomTarget<Bitmap>() {
                                        @Override
                                        public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                                            // Exibe a imagem na ImageView
                                            imagemAdm.setImageBitmap(resource);

                                            // GUARDA o Bitmap para poder salvar depois
                                            selectedBitmap = resource;

                                            // Atualiza suas flags e outros componentes
                                            imageChanged = true;
                                            btnSelecionarFoto.setAlpha(0);
                                        }

                                        @Override
                                        public void onLoadCleared(@Nullable Drawable placeholder) {
                                            // Pode ser deixado em branco
                                        }
                                    });
                        }
                    }
                }
        );

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_perfil_adm, container, false);

        etNomeAdm = view.findViewById(R.id.etNomeAdm);
        btSalvarAdm = view.findViewById(R.id.btSalvarAdm);
        btnSelecionarFoto = view.findViewById(R.id.btnSelecionarFoto);
        imagemAdm = view.findViewById(R.id.imagemAdm);
        mainContentLayoutAdm = view.findViewById(R.id.mainContentLayoutAdm);
        progressBarAdm = view.findViewById(R.id.progressBarAdm);

        btSalvarAdm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nomeAdm = etNomeAdm.getText().toString().trim();

                if(nomeAdm.isEmpty()) {
                    etNomeAdm.setError("campo obrigatório");
                } else {
                    funAtualizarAdm();
                }

            }
        });

        btnSelecionarFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funSelecionarFoto();
            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        // Garante que temos um executor ativo sempre que o fragmento está visível.
        if (executor == null || executor.isShutdown()) {
            executor = Executors.newSingleThreadExecutor();
        }

        if (!dadosForamCarregados) {
            // 1. Mostra o ProgressBar e oculta o conteúdo principal imediatamente.
            if (progressBarAdm != null) {
                progressBarAdm.setVisibility(VISIBLE);
            }
            if (mainContentLayoutAdm != null) {
                mainContentLayoutAdm.setVisibility(GONE);
            }

            executor.execute(() -> {
                Connection con = null;
                PreparedStatement stmtId = null;
                ResultSet rsId = null;

                PreparedStatement stmtAdm = null;
                ResultSet rsAdm = null;

                try {
                    emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

                    con = ConexaoMysql.conectar();
                    String sqlId = "SELECT id_login FROM login WHERE email = ?;";
                    stmtId = con.prepareStatement(sqlId);
                    stmtId.setString(1, emailUsuarioAtual);
                    rsId = stmtId.executeQuery();

                    if (rsId.next()) {
                        idUsuarioAtual = rsId.getInt("id_login");
                    }

                    String sqlAdm = "SELECT nome, foto FROM adm WHERE fk_id_login = ?";
                    stmtAdm = con.prepareStatement(sqlAdm);
                    stmtAdm.setInt(1, idUsuarioAtual);
                    rsAdm = stmtAdm.executeQuery();

                    // Variáveis para passar para a Thread Principal
                    final String nomeAdmFinal;
                    final byte[] fotoBytesFinal;

                    if (rsAdm.next()) {
                        nomeAdmFinal = rsAdm.getString("nome");
                        fotoBytesFinal = rsAdm.getBytes("foto");
                        fotoAtual = rsAdm.getBytes("foto");
                    } else {
                        nomeAdmFinal = null;
                        fotoBytesFinal = null;
                    }

                    // Volta para a Thread Principal para atualizar a TELA
                    handler.post(() -> {
                        if (!isAdded()) return; // Segurança

                        // Atualiza o nome
                        etNomeAdm.setText(nomeAdmFinal);
                        etNomeAdm.setError(null);

                        // Atualiza a foto com Glide
                        if (fotoBytesFinal != null) {
                            btnSelecionarFoto.setAlpha(0);

                            Glide.with(this) // ou SeuFragment.this, ou getContext()
                                    .load(fotoBytesFinal) // Fonte dos dados: nosso array de bytes
                                    .transform(new CircleCrop()) // Transforma a imagem em um círculo
                                    .error(R.drawable.user) // (Opcional) Imagem se der erro
                                    .into(imagemAdm); // A ImageView de destino
                        } else {
                            // (Opcional) O que fazer se não houver foto no banco
                            Glide.with(this).load(R.drawable.user).into(imagemAdm);
                        }

                        dadosForamCarregados = true;

                        // Finaliza o loading, mostrando o conteúdo.
                        if (progressBarAdm != null) progressBarAdm.setVisibility(GONE);
                        if (mainContentLayoutAdm != null)
                            mainContentLayoutAdm.setVisibility(VISIBLE);
                    });

                } catch (Exception e) {
                    Log.e("LOAD_PROFILE", "Erro ao carregar perfil do ADM", e);
                    // Opcional: postar no handler para mostrar uma mensagem de erro na tela
                    handler.post(() -> {
                        if (!isAdded()) return; // Segurança
                        progressBarAdm.setVisibility(GONE);
                        Toast.makeText(getContext(), "Erro ao carregar perfil.", Toast.LENGTH_SHORT).show();
                    });
                } finally {
                    try {
                        if(rsId!=null) rsId.close();
                        if(stmtId!=null) stmtId.close();
                        if(rsAdm!=null) rsAdm.close();
                        if(stmtAdm!=null) stmtAdm.close();
                        if(con!=null) con.close();
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            });
        } else {
            // Se os dados JÁ foram carregados, apenas ajusta a visibilidade.
            // Isso acontece quando o usuário volta para o fragmento.

            progressBarAdm.setVisibility(GONE);
            mainContentLayoutAdm.setVisibility(VISIBLE);

            if (fotoAtual != null) {
                btnSelecionarFoto.setAlpha(0);

                Glide.with(this) // ou SeuFragment.this, ou getContext()
                        .load(fotoAtual) // Fonte dos dados: nosso array de bytes
                        .transform(new CircleCrop()) // Transforma a imagem em um círculo
                        .error(R.drawable.user) // (Opcional) Imagem se der erro
                        .into(imagemAdm); // A ImageView de destino
            } else {
                // (Opcional) O que fazer se não houver foto no banco
                Glide.with(this).load(R.drawable.user).into(imagemAdm);
            }
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d("LIFECYCLE", "onDestroyView chamado, dadosIniciaisCarregados resetado para false.");
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
        }
    }

    public void funBuscarAdm() {

        executor.execute(() -> {
            final byte[][] fotoBytes = {null};
            final String[] nomeAdm = {null};

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT * FROM adm WHERE fk_id_login = ?";
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, idUsuarioAtual);
                rs = stmt.executeQuery();

                Drawable drawable = imagemAdm.getDrawable();

                while(rs.next()) {
                    nomeAdm[0] = rs.getString("nome");
                    fotoBytes[0] = rs.getBytes("foto");
                }

            } catch (Exception e) {
                throw new RuntimeException(e);
            } finally {
                try {
                    if(rs!=null) rs.close();
                    if(stmt!=null) stmt.close();
                    if(con!=null) con.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

            handler.post(() -> {
                if (!isAdded()) return; // Segurança
                // Atualiza a UI com os dados do banco de dados
                if (nomeAdm[0] != null) {
                    etNomeAdm.setText(nomeAdm[0]);
                }

                if (fotoBytes[0] != null ) {
                    btnSelecionarFoto.setAlpha(0);

                    Glide.with(this) // ou SeuFragment.this, ou getContext()
                            .load(fotoBytes[0]) // Fonte dos dados: nosso array de bytes
                            .transform(new CircleCrop()) // Transforma a imagem em um círculo
                            .placeholder(R.drawable.user) // (Opcional) Imagem enquanto carrega
                            .error(R.drawable.user) // (Opcional) Imagem se der erro
                            .into(imagemAdm); // A ImageView de destino
                } else {
                    // (Opcional) O que fazer se não houver foto no banco
                    Glide.with(this).load(R.drawable.user).into(imagemAdm);
                }
            }) ;
        });

    }

    public void funSelecionarFoto() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        // ActivityResultLauncher para iniciar a atividade e capturar o resultado
        selectPhotoLauncher.launch(intent);
    }

    // Este método é chamado quando a foto é carregada (na seleção da foto)
    public void setImgOriginal(Bitmap bitmap) {
        imgOriginalBitmap = bitmap; // Armazena a imagem original para comparação posterior
        imageChanged = true; // Marca que a imagem foi alterada
    }

    // Método para recuperar a imagem do banco de dados
    private byte[] getImgBytesFromDatabase(String idAdm) {
        byte[] imgBytesAtual = null;

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            con = ConexaoMysql.conectar();
            String sql = "SELECT foto FROM adm WHERE id_adm = ?";
            stmt = con.prepareStatement(sql);
            stmt.setInt(1,idUsuarioAtual);
            rs = stmt.executeQuery();

            if (rs.next()) {
                imgBytesAtual = rs.getBytes("foto");
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        return imgBytesAtual;
    }

    public void funAtualizarAdm() {
        String nome = etNomeAdm.getText().toString().trim();

        executor.execute(() -> {
            byte[] imgBytesParaSalvar = null;
            boolean sucesso = false;

            Connection con = null;
            PreparedStatement stmt = null;

            try {
                // Lógica para preparar os bytes da imagem
                if (imageChanged && selectedBitmap != null) {
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    selectedBitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
                    imgBytesParaSalvar = byteArrayOutputStream.toByteArray();
                }

                con = ConexaoMysql.conectar();
                String sql;

                // Se a imagem foi alterada, atualize nome e foto
                if (imageChanged && imgBytesParaSalvar != null) {
                    sql = "UPDATE adm SET nome = ?, foto = ? WHERE fk_id_login = ?;";
                    stmt = con.prepareStatement(sql);
                    stmt.setString(1, nome);
                    stmt.setBytes(2, imgBytesParaSalvar);
                    stmt.setInt(3, idUsuarioAtual);

                    fotoAtual = imgBytesParaSalvar;
                } else {
                    // Se não, atualize apenas o nome
                    sql = "UPDATE adm SET nome = ? WHERE fk_id_login = ?;";
                    stmt = con.prepareStatement(sql);
                    stmt.setString(1, nome);
                    stmt.setInt(2, idUsuarioAtual);
                }

                stmt.executeUpdate();

                imageChanged = false; // Reseta a flag após o sucesso
                sucesso = true;

            } catch (Exception e) {
                Log.e("UPDATE_ADM", "Erro ao atualizar perfil", e);
                sucesso = false;
            } finally {
                try {
                    if(stmt!=null) stmt.close();
                    if(con!=null) con.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }

            // Volta para a thread principal
            final boolean finalSucesso = sucesso;
            handler.post(() -> {
                if (!isAdded()) return; // Segurança
                if (finalSucesso) {
                    Toast.makeText(getContext(), "Perfil atualizado com sucesso!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getContext(), "Erro ao atualizar o perfil.", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

}