package com.example.petcareapp.ui.perfilTutor;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;


import static android.app.ProgressDialog.show;
import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static android.widget.Toast.LENGTH_LONG;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.example.petcareapp.ui.pet.petFragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class perfilTutorFragment extends Fragment {

    EditText  nomeTutor, descricaoTutor, telefoneTutor, dataNascimentoTutor;

    Button btnSalvar, btnEditar, btnSelecionarFoto;

    TextView countTextDescTutor;

    String idTutor;

    ImageView imagemTutor;

    String emailUsuarioAtual;

    Integer idUsuarioAtual;

    private Uri selectedImageUri = null;

    ProgressBar progressBar;
    ConstraintLayout mainContentLayout;
    boolean imageChanged = false; // Flag para indicar se a imagem foi alterada

    private ExecutorService executor;
    // Handler para postar resultados de volta na thread principal da UI
    private final Handler handler = new Handler(Looper.getMainLooper());

    // Definindo o ActivityResultLauncher para capturar o resultado da seleção de foto
    private ActivityResultLauncher<Intent> selectPhotoLauncher;


    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private static final int REQUEST_CODE_IMAGEM = 1;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private Intent Intent;

    public perfilTutorFragment() {
        // Required empty public constructor
    }

    public static perfilTutorFragment newInstance(String param1, String param2) {
        perfilTutorFragment fragment = new perfilTutorFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        // Inicializando o ActivityResultLauncher para a seleção de foto
        selectPhotoLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == getActivity().RESULT_OK && result.getData() != null) {
                        // Recupera o URI da imagem selecionada
                        Intent data = result.getData();
                        Uri imageUri = data.getData();

                        if (imageUri != null) {
                            selectedImageUri = imageUri; // Guarda a Uri da imagem selecionada
                            imageChanged = true;

                            // Glide é assíncrono, então usamos um listener para atualizar a UI no momento certo.
                            Glide.with(this)
                                    .load(selectedImageUri) // Carrega diretamente da Uri
                                    .circleCrop() // Transforma em círculo
                                    .listener(new com.bumptech.glide.request.RequestListener<android.graphics.drawable.Drawable>() {
                                        @Override
                                        public boolean onLoadFailed(@Nullable com.bumptech.glide.load.engine.GlideException e, Object model, com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> target, boolean isFirstResource) {
                                            // Opcional: Tratar erro no carregamento da imagem
                                            Toast.makeText(getContext(), "Falha ao carregar imagem", Toast.LENGTH_SHORT).show();
                                            return false; // Permite que o Glide exiba uma imagem de erro, se configurada.
                                        }

                                        @Override
                                        public boolean onResourceReady(android.graphics.drawable.Drawable resource, Object model, com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> target, com.bumptech.glide.load.DataSource dataSource, boolean isFirstResource) {
                                            // atualizamos a UI.
                                            btnSelecionarFoto.setAlpha(0);
                                            btnSalvar.setVisibility(View.VISIBLE);
                                            btnEditar.setVisibility(View.GONE);

                                            // Retornar 'false' é importante para que o Glide continue seu trabalho
                                            // e exiba a imagem no 'imagemTutor'.
                                            return false;
                                        }
                                    })
                                    .into(imagemTutor);
                        }
                    }
                }
        );
    }

    @SuppressLint({"MissingInflatedId", "WrongViewCast"})
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_perfil_tutor, container, false);
        CalendarView meuCalendario;
        String dia, mes, ano;

        imagemTutor = view.findViewById(R.id.imagemTutor);

        nomeTutor = view.findViewById(R.id.nomeTutor);
        descricaoTutor = view.findViewById(R.id.descricaoTutor);
        telefoneTutor = view.findViewById(R.id.telefoneTutor);
        dataNascimentoTutor = view.findViewById(R.id.dataNascimentoTutor);

        btnSalvar = view.findViewById(R.id.btnSalvar);
        btnSalvar.setVisibility(GONE);
        btnEditar = view.findViewById(R.id.btnEditar);
        btnSelecionarFoto = view.findViewById(R.id.btnSelecionarFoto);

        countTextDescTutor = view.findViewById(R.id.countTextDescTutor);

        mainContentLayout = view.findViewById(R.id.mainContentLayout);
        progressBar = view.findViewById(R.id.progressBar);

        funDesativarCampos();

        dataNascimentoTutor.addTextChangedListener(new TextWatcher() {
            private String current = "";

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().equals(current)) {
                    return; // Evita loop infinito
                }

                String clean = s.toString().replaceAll("[^\\d]", "");
                String formatted;

                if (clean.length() < 3) {
                    formatted = clean;
                } else if (clean.length() < 5) {
                    formatted = clean.substring(0, 2) + "/" + clean.substring(2);
                } else {
                    // Limita a 8 dígitos (DDMMYYYY)
                    if (clean.length() > 8) {
                        clean = clean.substring(0, 8);
                    }
                    formatted = clean.substring(0, 2) + "/" + clean.substring(2, 4) + "/" + clean.substring(4);
                }

                current = formatted;
                dataNascimentoTutor.setText(current);
                dataNascimentoTutor.setSelection(current.length());
            }
        });

        // Contador de caracteres
        descricaoTutor.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int currentLength = s.length();
                countTextDescTutor.setText(currentLength + "/300");
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        btnEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAtivarCampos();
            }
        });

        btnSelecionarFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funSelecionarFoto();
                funAtivarCampos();
            }
        });

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAtualizarTutor();
            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        // Garante que o executor está ativo.
        if (executor == null || executor.isShutdown()) {
            executor = Executors.newSingleThreadExecutor();
        }

        // 1. Mostra o ProgressBar e oculta o conteúdo principal imediatamente.
        if (progressBar != null) {
            progressBar.setVisibility(VISIBLE);
        }
        if (mainContentLayout != null) {
            mainContentLayout.setVisibility(GONE);
        }

        executor.execute(() -> {
            emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "SELECT id_login FROM login WHERE email = ?;";
                stmt = con.prepareStatement(sql);
                stmt.setString(1, emailUsuarioAtual);
                rs = stmt.executeQuery();

                if (rs.next()) {
                    idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
                }

                handler.post(() -> {
                    if (!isAdded()) return;
                    Drawable drawable = imagemTutor.getDrawable();

                    if (!(drawable == null)) {
                        btnEditar.setVisibility(GONE);
                        btnSalvar.setVisibility(VISIBLE);
                    }

                    if (btnEditar.getVisibility() == VISIBLE) {
                        funBuscarTutor();
                    }

                    nomeTutor.setError(null);
                    dataNascimentoTutor.setError(null);

                    // Finaliza o loading, mostrando o conteúdo.
                    if (progressBar != null) progressBar.setVisibility(GONE);
                    if (mainContentLayout != null) mainContentLayout.setVisibility(VISIBLE);
                });

            } catch (Exception e) {
                Log.e("STARTUP_ERROR", "Erro ao buscar ID do usuário", e);
                handler.post(() -> {
                    if (!isAdded()) return;
                    progressBar.setVisibility(GONE);
                    Toast.makeText(getContext(), "Erro ao iniciar. Tente novamente.", LENGTH_LONG).show();
                });
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }

    @Override
    public void onStop() {
        super.onStop();
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
        }
    }

    public static class DateValidator {

        public static boolean isValidDate(String dateStr) {
            // 1. Checagem de formato inicial
            if (dateStr == null || !dateStr.matches("\\d{2}/\\d{2}/\\d{4}")) {
                return false;
            }

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            sdf.setLenient(false); // Impede datas como 32/01/2025

            try {
                // 2. Tenta converter a string em data
                Date date = sdf.parse(dateStr);
                Date today = new Date(); // Pega a data e hora atuais

                // 3. VERIFICAÇÃO PRINCIPAL: A data de nascimento não pode ser no futuro
                if (date.after(today)) {
                    return false; // A data inserida é posterior a hoje
                }

                // 4. Checagem opcional de ano mínimo para evitar datas muito antigas
                Calendar cal = Calendar.getInstance();
                cal.setTime(date);
                int year = cal.get(Calendar.YEAR);
                if (year < 1900) { // Ex: Rejeita anos antes de 1900
                    return false;
                }

            } catch (ParseException e) {
                // Se a conversão falhar (ex: "30/02/2025"), é inválida
                return false;
            }

            // Se passou por todas as verificações, a data é válida
            return true;
        }
    }

    public void funBuscarTutor() {
        executor.execute(() -> {
            Connection con = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;

            byte[] foto = null;
            String nome = null;
            String descricao = null;
            String telefone = null;
            Date data = null;

            try {
                con = ConexaoMysql.conectar();
                String sql = "select * from tutor where id_tutor = ?";
                stmt = con.prepareStatement(sql);
                stmt.setInt(1, idUsuarioAtual);
                rs = stmt.executeQuery();

                if (rs.next()) {
                    foto = rs.getBytes("foto");
                    nome = rs.getString("nome");
                    descricao = rs.getString("descricao");
                    telefone = rs.getString("telefone");
                    data = rs.getDate("dt_nascimento");
                }

                final byte[] finalFoto = foto;
                final String finalNome = nome;
                final String finalDescricao = descricao;
                final String finalTelefone = telefone;
                final Date finalData = data;

                handler.post(() -> {
                    if (!isAdded()) return;

                    if (finalFoto != null) {
                        Glide.with(perfilTutorFragment.this) // Usar 'this' do fragment
                                .load(finalFoto)
                                .circleCrop()
                                .error(R.drawable.user)
                                .listener(new com.bumptech.glide.request.RequestListener<android.graphics.drawable.Drawable>() {
                                    @Override
                                    public boolean onLoadFailed(@Nullable com.bumptech.glide.load.engine.GlideException e, Object model, com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> target, boolean isFirstResource) {
                                        return false; // Deixa o Glide lidar com a imagem de erro.
                                    }

                                    @Override
                                    public boolean onResourceReady(android.graphics.drawable.Drawable resource, Object model, com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> target, com.bumptech.glide.load.DataSource dataSource, boolean isFirstResource) {
                                        // A imagem do banco está pronta, escondemos o botão.
                                        btnSelecionarFoto.setAlpha(0);
                                        return false; // Importante: deixa o Glide exibir a imagem.
                                    }
                                })
                                .into(imagemTutor);
                    }

                    nomeTutor.setText(finalNome);
                    descricaoTutor.setText(finalDescricao);
                    telefoneTutor.setText(finalTelefone);

                    if (finalData != null) {
                        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                        String dataFormatada = formato.format(finalData);
                        dataNascimentoTutor.setText(dataFormatada);
                    }
                });

            } catch (Exception e) {
                Log.d("perfilTutorFragment", "Erro ao buscar dados do tutor", e);
                handler.post(() -> {
                    if (!isAdded()) return;
                    Toast.makeText(getContext(), "Erro ao buscar dados do tutor", Toast.LENGTH_SHORT).show();
                });
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    Log.e("DB_CLOSE_ERROR", "Erro ao fechar recursos", e);
                }
            }
        });
    }

    public void funSelecionarFoto() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        // ActivityResultLauncher para iniciar a atividade e capturar o resultado
        selectPhotoLauncher.launch(intent);
    }

    // Metodo para recuperar a imagem do banco de dados
    private byte[] getImgBytesFromDatabase(String idTutor) {
        byte[] imgBytesAtual = null;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT foto FROM tutor WHERE id_tutor = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1,idUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                imgBytesAtual = rs.getBytes("foto");
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return imgBytesAtual;
    }

    public void funAtualizarTutor() {
        // VALIDAÇÃO COMPLETA NA THREAD DE UI

        String nome = nomeTutor.getText().toString().trim();
        final String dataStr = dataNascimentoTutor.getText().toString().trim();
        Drawable drawable = imagemTutor.getDrawable();

        // Validação da Imagem
        if (drawable == null && !imageChanged) {
            Toast.makeText(getContext(), "Adicione uma imagem do tutor", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validação do Nome
        if (nome.isEmpty()) {
            nomeTutor.setError("campo obrigatório.");
            nomeTutor.requestFocus();
            return;
        }

        // Validação da Data (formato e conteúdo)
        if (dataStr.isEmpty()) {
            dataNascimentoTutor.setError("campo obrigatório.");
            dataNascimentoTutor.requestFocus();
            return;
        }
        if (!dataStr.matches("\\d{2}/\\d{2}/\\d{4}")) {
            dataNascimentoTutor.setError("Formato inválido. Use DD/MM/AAAA.");
            dataNascimentoTutor.requestFocus();
            return;
        }

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);
        final java.sql.Date dataSql; // Precisa ser 'final' para ser usado dentro do executor

        try {
            Date dataUtil = sdf.parse(dataStr);
            Date hoje = new Date();

            if (dataUtil.after(hoje)) {
                dataNascimentoTutor.setError("A data não pode ser no futuro.");
                dataNascimentoTutor.requestFocus();
                return; // Para a função aqui
            }
            dataSql = new java.sql.Date(dataUtil.getTime());

        } catch (ParseException e) {
            dataNascimentoTutor.setError("data inválida.");
            dataNascimentoTutor.requestFocus();
            return; // Para a função aqui
        }

        // SE TUDO FOI VALIDADO, EXECUTE A GRAVAÇÃO NO BANCO

        // Pegar os outros dados que não precisam de validação complexa
        String descricao = descricaoTutor.getText().toString().trim();
        String telefone = telefoneTutor.getText().toString().trim();

        executor.execute(() -> {
            byte[] imgBytes = null;
            if (imageChanged && selectedImageUri != null) {
                // Se uma nova imagem foi selecionada, converte a Uri para bytes
                try (InputStream inputStream = getContext().getContentResolver().openInputStream(selectedImageUri)) {
                    if (inputStream == null) throw new IOException("InputStream nulo para a Uri da imagem");

                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    byte[] buffer = new byte[1024];
                    int len;
                    while ((len = inputStream.read(buffer)) != -1) {
                        byteArrayOutputStream.write(buffer, 0, len);
                    }
                    imgBytes = byteArrayOutputStream.toByteArray();
                } catch (IOException e) {
                    e.printStackTrace();
                    // Você pode querer notificar o usuário aqui que a conversão da imagem falhou
                }
            } else {
                imgBytes = getImgBytesFromDatabase(idTutor);
            }

            // Conexão e gravação no banco
            Connection con = null;
            PreparedStatement stmt = null;
            try {
                con = ConexaoMysql.conectar();
                String sql;

                if (imageChanged) {
                    sql = "update tutor set foto = ?, nome = ?, descricao = ? , telefone = ? , dt_nascimento = ? where id_tutor = ?;";
                    stmt = con.prepareStatement(sql);
                    stmt.setBytes(1, imgBytes);
                    stmt.setString(2, nome);
                    stmt.setString(3, descricao);
                    stmt.setString(4, telefone);
                    stmt.setDate(5, dataSql);
                    stmt.setInt(6, idUsuarioAtual);
                } else {
                    sql = "update tutor set nome = ?, descricao = ? , telefone = ? , dt_nascimento = ? where id_tutor = ?;";
                    stmt = con.prepareStatement(sql);
                    stmt.setString(1, nome);
                    stmt.setString(2, descricao);
                    stmt.setString(3, telefone);
                    stmt.setDate(4, dataSql);
                    stmt.setInt(5, idUsuarioAtual);
                }
                stmt.executeUpdate();

                handler.post(() -> {
                    if(!isAdded()) return;
                    imageChanged = false;
                    funDesativarCampos();
                    Toast.makeText(getContext(), "Dados atualizados com sucesso.", Toast.LENGTH_SHORT).show();
                });

            } catch (Exception e) {
                e.printStackTrace();
                handler.post(() -> Toast.makeText(getContext(), "Erro ao atualizar os dados.", Toast.LENGTH_SHORT).show());
            } finally {
                try {
                    if (stmt != null) stmt.close();
                    if (con != null) con.close();
                } catch (Exception e) {
                    // Log o erro, mas não trave o app
                    Log.e("DB_CLOSE_ERROR", "Erro ao fechar conexão", e);
                }
            }
        });
    }

    public void funDesativarCampos(){
        nomeTutor.setFocusable(false);
        nomeTutor.setFocusableInTouchMode(false);
        nomeTutor.setCursorVisible(false);
        nomeTutor.setLongClickable(false);

        descricaoTutor.setFocusable(false);
        descricaoTutor.setFocusableInTouchMode(false);
        descricaoTutor.setCursorVisible(false);
        descricaoTutor.setLongClickable(false);

        telefoneTutor.setFocusable(false);
        telefoneTutor.setFocusableInTouchMode(false);
        telefoneTutor.setCursorVisible(false);
        telefoneTutor.setLongClickable(false);

        dataNascimentoTutor.setFocusable(false);
        dataNascimentoTutor.setFocusableInTouchMode(false);
        dataNascimentoTutor.setCursorVisible(false);
        dataNascimentoTutor.setLongClickable(false);

        btnSelecionarFoto.setEnabled(false);
        btnEditar.setVisibility(VISIBLE);
        btnSalvar.setVisibility(GONE);

        nomeTutor.setError(null);
        dataNascimentoTutor.setError(null);
    }

    public void funAtivarCampos(){
        nomeTutor.setFocusable(true);
        nomeTutor.setFocusableInTouchMode(true);
        nomeTutor.setCursorVisible(true);
        nomeTutor.setLongClickable(true);

        descricaoTutor.setFocusable(true);
        descricaoTutor.setFocusableInTouchMode(true);
        descricaoTutor.setCursorVisible(true);
        descricaoTutor.setLongClickable(true);

        telefoneTutor.setFocusable(true);
        telefoneTutor.setFocusableInTouchMode(true);
        telefoneTutor.setCursorVisible(true);
        telefoneTutor.setLongClickable(true);

        dataNascimentoTutor.setFocusable(true);
        dataNascimentoTutor.setFocusableInTouchMode(true);
        dataNascimentoTutor.setCursorVisible(true);
        dataNascimentoTutor.setLongClickable(true);

        btnSelecionarFoto.setEnabled(true);
        btnEditar.setVisibility(GONE);
        btnSalvar.setVisibility(VISIBLE);
    }

    public void funMostrarLayout() {
        nomeTutor.setVisibility(VISIBLE);
        descricaoTutor.setVisibility(VISIBLE);
        telefoneTutor.setVisibility(VISIBLE);
        btnSelecionarFoto.setVisibility(VISIBLE);
        btnSalvar.setVisibility(VISIBLE);
        imagemTutor.setVisibility(VISIBLE);
        dataNascimentoTutor.setVisibility(VISIBLE);
        countTextDescTutor.setVisibility(VISIBLE);
    }

}